#!/usr/bin/env node
/* =========================================================================
 * server.js — 本地启动器（零依赖）
 *  1) 静态服务：把本目录作为网站根目录
 *  2) /ollama/*  ->  转发到本机 Ollama（解决浏览器跨域 / 私有网络限制）
 *  3) /proxy?url= ->  转发任意 OpenAI 兼容接口（可用可不用）
 *
 * 用法：node server.js [--port 8787] [--ollama http://127.0.0.1:11434] [--no-open]
 * ========================================================================= */
'use strict';

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { exec, spawn } = require('child_process');

const ROOT = __dirname;
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};

function arg(name, fallback) {
  const i = process.argv.indexOf(name);
  if (i > 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--')) return process.argv[i + 1];
  return fallback;
}

const START_PORT = Number(arg('--port', process.env.PORT || 8787));
const OLLAMA_BASE = (arg('--ollama', process.env.OLLAMA_HOST || 'http://127.0.0.1:11434')).replace(/\/+$/, '');
const NO_OPEN = process.argv.includes('--no-open');

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'content-type,authorization,x-api-key,anthropic-version,anthropic-beta,accept,origin');
  res.setHeader('Access-Control-Expose-Headers', '*');
}

function json(res, status, obj) {
  const body = JSON.stringify(obj, null, 2);
  cors(res);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.join(ROOT, path.normalize(rel).replace(/^(\.\.[\/\\])+/, ''));
  if (!file.startsWith(ROOT)) return json(res, 403, { error: 'forbidden' });

  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      cors(res);
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404 ' + rel);
    }
    cors(res);
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': 'no-cache'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

const agentHttp = new http.Agent({ keepAlive: true, maxSockets: 64 });
const agentHttps = new https.Agent({ keepAlive: true, maxSockets: 64 });

function forward(req, res, targetUrl, rewritePath) {
  let target;
  try {
    target = new URL(targetUrl);
  } catch (e) {
    return json(res, 400, { error: '无效的目标地址：' + targetUrl });
  }
  if (!/^https?:$/.test(target.protocol)) {
    return json(res, 400, { error: '只支持 http / https' });
  }

  const mod = target.protocol === 'https:' ? https : http;
  const headers = Object.assign({}, req.headers);
  delete headers.host;
  delete headers.connection;
  headers.host = target.host;

  const opts = {
    protocol: target.protocol,
    hostname: target.hostname,
    port: target.port || (target.protocol === 'https:' ? 443 : 80),
    path: (rewritePath || target.pathname) + (target.search || ''),
    method: req.method,
    headers: headers,
    agent: target.protocol === 'https:' ? agentHttps : agentHttp
  };

  const upstream = mod.request(opts, (up) => {
    const outHeaders = Object.assign({}, up.headers);
    ['connection', 'keep-alive', 'transfer-encoding', 'access-control-allow-origin'].forEach((h) => delete outHeaders[h]);
    cors(res);
    res.writeHead(up.statusCode || 502, outHeaders);
    up.pipe(res);            // 流式直通，Ollama 的 NDJSON 不会被缓冲
    up.on('error', () => { try { res.end(); } catch (e) { } });
  });

  upstream.on('error', (err) => {
    if (res.headersSent) { try { res.end(); } catch (e) { } return; }
    json(res, 502, {
      error: '上游不可达：' + err.message,
      target: target.href,
      hint: 'Ollama 没启动？执行 ollama serve；或检查地址是否正确。'
    });
  });

  upstream.setTimeout(180000, () => upstream.destroy(new Error('上游超时')));
  req.pipe(upstream);
}

function checkOllama(cb) {
  const req = http.get(OLLAMA_BASE + '/api/version', (r) => {
    let body = '';
    r.on('data', (d) => { body += d; });
    r.on('end', () => {
      try { cb(true, JSON.parse(body)); } catch (e) { cb(true, {}); }
    });
  });
  req.on('error', () => cb(false, null));
  req.setTimeout(3000, () => { req.destroy(); cb(false, null); });
}

function startOllama(done) {
  let child;
  try {
    child = spawn('ollama', ['serve'], {
      detached: true,
      stdio: 'ignore',
      env: Object.assign({}, process.env, { OLLAMA_ORIGINS: '*' })
    });
    child.unref();
  } catch (e) {
    return done(false, e.message);
  }
  let tries = 0;
  const timer = setInterval(() => {
    tries++;
    checkOllama((ok, info) => {
      if (ok) { clearInterval(timer); done(true, info); }
      else if (tries > 20) { clearInterval(timer); done(false, 'ollama serve 启动超时'); }
    });
  }, 700);
}

function openBrowser(url) {
  if (NO_OPEN) return;
  const cmd = process.platform === 'win32' ? `start "" "${url}"`
    : process.platform === 'darwin' ? `open "${url}"` : `xdg-open "${url}"`;
  exec(cmd, () => { });
}

/* ------------------------------- 路由 ------------------------------- */

function handler(req, res) {
  const parsed = new URL(req.url, 'http://localhost');
  const p = parsed.pathname;

  if (req.method === 'OPTIONS') {
    cors(res);
    res.writeHead(204);
    return res.end();
  }

  if (p === '/api/health') {
    return checkOllama((ok, info) => {
      json(res, 200, {
        ok: true,
        server: 'chat-demo-v0.2.0',
        ollama: { reachable: ok, base: OLLAMA_BASE, version: (info && info.version) || null }
      });
    });
  }

  if (p.startsWith('/ollama/')) {
    const rest = p.slice('/ollama'.length);
    return forward(req, res, OLLAMA_BASE + rest + parsed.search, rest + parsed.search);
  }

  if (p === '/proxy' || p === '/proxy/') {
    const target = parsed.searchParams.get('url');
    if (!target) return json(res, 400, { error: '缺少 url 参数' });
    return forward(req, res, target, null);
  }

  if (req.method === 'GET' || req.method === 'HEAD') {
    return serveStatic(req, res, p);
  }

  json(res, 405, { error: 'method not allowed' });
}

function listen(port, attempt) {
  const server = http.createServer(handler);
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE' && attempt < 8) {
      listen(port + 1, attempt + 1);
    } else {
      console.error('[启动失败]', err.message);
      process.exit(1);
    }
  });
  server.listen(port, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${port}/`;
    console.log('');
    console.log('  Chat v0.2 已启动');
    console.log('  --------------------------------------------');
    console.log('  页面      ' + url);
    console.log('  Ollama    ' + OLLAMA_BASE + ' (代理路径 /ollama)');
    console.log('  停止      Ctrl+C');
    console.log('');

    checkOllama((ok, info) => {
      if (ok) {
        console.log('  Ollama 已连通，版本 ' + ((info && info.version) || '未知'));
        console.log('');
        openBrowser(url);
      } else {
        console.log('  Ollama 没在运行，正在尝试自动启动 …');
        startOllama((started, detail) => {
          if (started) {
            console.log('  Ollama 已启动，版本 ' + ((detail && detail.version) || '未知'));
          } else {
            console.log('  ⚠ 自动启动失败：' + detail);
            console.log('  请手动执行：ollama serve');
          }
          console.log('');
          openBrowser(url);
        });
      }
    });
  });
}

listen(START_PORT, 0);
