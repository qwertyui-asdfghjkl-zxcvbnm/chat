/* =========================================================================
 * tests/proxy.js — 验证本地启动器的静态服务 / Ollama 转发 / 通用转发
 *   node tests/proxy.js 8788
 * ========================================================================= */
'use strict';

const assert = require('assert');
const base = 'http://127.0.0.1:' + (process.argv[2] || 8787);
let passed = 0;
const ok = (n) => { passed++; console.log('  ✓ ' + n); };

(async () => {
  const html = await (await fetch(base + '/')).text();
  assert(html.includes('assets/app.js'), 'index.html');
  ok('静态服务：index.html');

  const js = await fetch(base + '/assets/app.js');
  assert.equal(js.status, 200);
  assert(String(js.headers.get('content-type')).includes('javascript') || /javascript/.test(String(js.headers.get('content-type'))), 'js content-type');
  ok('静态服务：assets/app.js 200 + MIME');

  const tagsRes = await fetch(base + '/ollama/api/tags');
  assert.equal(tagsRes.status, 200);
  const tags = await tagsRes.json();
  assert(Array.isArray(tags.models) && tags.models.length > 0, 'tags models');
  ok('Ollama 转发：/ollama/api/tags 返回 ' + tags.models.length + ' 个模型');

  // 流式：第一段应在几秒内到达，且能收到多段
  const t0 = Date.now();
  const res = await fetch(base + '/ollama/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: tags.models.find((m) => m.size < 1e9)?.name || tags.models[0].name,
      messages: [{ role: 'user', content: '从 1 数到 5，只输出数字和逗号' }],
      stream: true
    })
  });
  assert.equal(res.status, 200);
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let first = 0, chunks = 0, text = '';
  while (true) {
    const step = await reader.read();
    if (step.done) break;
    chunks++;
    if (!first) first = Date.now() - t0;
    const piece = dec.decode(step.value, { stream: true });
    try {
      for (const line of piece.split('\n')) {
        if (!line.trim()) continue;
        const j = JSON.parse(line);
        if (j.message?.content) text += j.message.content;
      }
    } catch (e) { /* 半个 JSON，忽略 */ }
  }
  assert(first > 0 && first < 8000, '首段及时到达：' + first + 'ms');
  assert(chunks > 2, '收到多段数据：' + chunks);
  assert(text.length > 0, '拼接出内容');
  ok('Ollama 转发：流式未被缓冲（首段 ' + first + 'ms / ' + chunks + ' 段 / ' + (Date.now() - t0) + 'ms）');

  // 通用转发：DeepSeek 无 Key 应返回 401，证明请求确实被转发到上游
  const target = encodeURIComponent('https://api.deepseek.com/v1/models');
  try {
    const r = await fetch(base + '/proxy?url=' + target);
    assert(r.status === 401 || r.status === 403 || r.status === 200, 'forwarded status=' + r.status);
    ok('通用转发：/proxy 到达 api.deepseek.com（HTTP ' + r.status + '）');
  } catch (e) {
    console.log('  ! 通用转发跳过（网络不可达）：' + e.message);
  }

  console.log('\n代理测试通过：' + passed + ' 项\n');
})().catch((e) => {
  console.error('\n✗ 代理测试失败：', e.message);
  process.exit(1);
});
