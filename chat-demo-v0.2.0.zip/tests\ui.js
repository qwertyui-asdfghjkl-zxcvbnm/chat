/* =========================================================================
 * tests/ui.js — 界面链路集成测试（jsdom + 真实 Ollama + 本地转发）
 *
 * 需要 jsdom（不装进项目，装到临时目录即可）：
 *   npm i jsdom --prefix %TEMP%\jsdomtest
 *   set NODE_PATH=%TEMP%\jsdomtest\node_modules
 *   node tests/ui.js http://127.0.0.1:8788/ qwen3_0.6b:latest
 * ========================================================================= */
'use strict';

const assert = require('assert');
const { JSDOM } = require('jsdom');

const URLBASE = process.argv[2] || 'http://127.0.0.1:8788/';
const MODEL = process.argv[3] || 'qwen3_0.6b:latest';
let passed = 0;
const ok = (n) => { passed++; console.log('  ✓ ' + n); };

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let W = null, D = null;

async function waitFor(fn, timeout, label) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    let v;
    try { v = fn(); } catch (e) { v = false; }
    if (v) return v;
    await sleep(150);
  }
  if (D) {
    const node = D.querySelector('.msg-assistant');
    console.error('\n[诊断] ' + (label || '?') + ' 超时');
    console.error('  assistant 节点：' + (node ? node.outerHTML.replace(/\s+/g, ' ').slice(0, 900) : '无'));
    console.error('  sendBtn class：' + D.getElementById('sendBtn').className);
    console.error('  输入区状态：' + D.getElementById('connText').textContent);
  }
  throw new Error('等待超时：' + (label || '未命名步骤'));
}

(async () => {
  const dom = await JSDOM.fromURL(URLBASE, {
    runScripts: 'dangerously',
    resources: 'usable',
    pretendToBeVisual: true,
    beforeParse(window) {
      window.matchMedia = () => ({
        matches: false,
        media: '',
        addEventListener() { }, removeEventListener() { }, addListener() { }, removeListener() { }
      });
      window.fetch = (input, init) => {
        const url = typeof input === 'string' ? new URL(input, URLBASE).toString() : input;
        return globalThis.fetch(url, init);
      };
      window.confirm = () => true;
    }
  });

  const w = dom.window;
  const d = w.document;
  W = w; D = d;
  const $ = (id) => d.getElementById(id);

  // 1. 启动 + 自动接入 Ollama
  await waitFor(() => d.querySelectorAll('.suggest').length > 0, 15000, '欢迎页渲染');
  ok('启动：欢迎页与建议卡片渲染');

  const chipText = $('connText').textContent;
  await waitFor(() => /Ollama/.test($('connText').textContent) && $('connText').textContent.indexOf('检测中') < 0, 12000, 'Ollama 探测');
  assert(/Ollama/.test(chipText) || true);
  assert($('connText').textContent.indexOf('未连接') < 0, '应已连接：' + $('connText').textContent);
  ok('一键接入：' + $('connText').textContent.trim());

  const modelLabel = $('modelBtnLabel').textContent;
  assert.equal(modelLabel, MODEL, '默认模型应为最小尺寸的思考模型');
  ok('默认模型：' + modelLabel);

  // 2. 深度思考开关
  const toggle = $('thinkToggle');
  const before = toggle.dataset.on;
  toggle.click();
  assert.notEqual(toggle.dataset.on, before, '开关状态应翻转');
  if (toggle.dataset.on !== 'true') toggle.click();   // 确保开启
  assert.equal(toggle.dataset.on, 'true');
  ok('深度思考：开关可切换并保持开启');

  // 3. 模型选择浮层
  $('modelBtn').click();
  await waitFor(() => !$('modelPopover').hidden, 3000, '浮层打开');
  await waitFor(() => d.querySelectorAll('.model-item').length >= 1, 5000, '模型列表');
  const items = Array.from(d.querySelectorAll('.model-item')).map((el) => el.dataset.model);
  assert(items.length >= 2, '模型列表至少 2 个：' + items.join(','));
  ok('模型切换：浮层列出 ' + items.length + ' 个模型（' + items.join(' / ') + '）');

  const other = items.find((n) => n !== MODEL);
  d.querySelector('.model-item[data-model="' + other + '"]').click();
  await waitFor(() => $('modelBtnLabel').textContent === other, 3000, '切换模型');
  ok('模型切换：已切到 ' + other + ' 并同步输入区');
  // 切回小模型，避免大模型占内存
  $('modelBtn').click();
  await waitFor(() => !$('modelPopover').hidden, 3000, '浮层再次打开');
  d.querySelector('.model-item[data-model="' + MODEL + '"]').click();
  await waitFor(() => $('modelBtnLabel').textContent === MODEL, 3000, '切回小模型');
  ok('模型切换：已切回 ' + MODEL + '（避免加载大模型）');

  // 4. 发送消息（真实推理）
  const input = $('input');
  input.value = '用一句话说明：为什么 9.9 比 9.11 大？';
  input.dispatchEvent(new w.Event('input', { bubbles: true }));
  assert.equal($('sendBtn').disabled, false, '发送按钮应可用');

  const t0 = Date.now();
  $('sendBtn').click();
  ok('发送：已提交，开始流式生成');

  await waitFor(() => d.querySelectorAll('.msg-assistant').length === 1, 5000, '助手气泡');
  await waitFor(() => {
    const el = d.querySelector('.msg-assistant .content');
    return el && el.textContent.trim().length > 0;
  }, 45000, '首段内容');

  await waitFor(() => {
    const el = d.querySelector('.msg-assistant .content');
    const typing = d.querySelector('.msg-assistant .typing');
    const streamingBtn = $('sendBtn').classList.contains('stop');
    return el && el.textContent.trim().length > 10 && !typing && !streamingBtn;
  }, 90000, '流式生成完成');
  ok('流式生成完成：' + (Date.now() - t0) + 'ms');

  const answer = d.querySelector('.msg-assistant .content').textContent.trim();
  console.log('    · 回答：' + JSON.stringify(answer.slice(0, 70)));
  assert(answer.length > 5, '回答非空');

  // 5. 思考块
  const think = d.querySelector('.msg-assistant .think');
  assert(think && !think.hidden, '深度思考块应显示');
  const thinkText = d.querySelector('.msg-assistant .think-text').textContent.trim();
  assert(thinkText.length > 0, '思考内容应非空');
  ok('思考块：已展示 ' + thinkText.length + ' 字思考，标题「' + d.querySelector('.think-label').textContent + '」');

  // 6. 元信息 / 侧栏 / 标题
  const meta = d.querySelector('.msg-assistant .msg-meta').textContent;
  assert(meta.indexOf(MODEL) >= 0, 'meta 应包含模型名：' + meta);
  assert(d.querySelectorAll('.conv-item').length === 1, '侧栏应出现 1 条对话');
  assert($('topbarTitle').textContent.length > 3, '标题应自动生成');
  ok('元信息：' + meta + ' / 标题：' + $('topbarTitle').textContent);

  // 7. 思考块折叠交互 + 聊天记录持久化
  const thinkHead = d.querySelector('.think-head');
  const openBefore = think.classList.contains('open');
  thinkHead.click();
  assert.equal(think.classList.contains('open'), !openBefore, '折叠可切换');
  ok('思考块：可折叠展开');

  const saved = JSON.parse(w.localStorage.getItem('chat-demo.v0.2'));
  assert(saved.conversations.length === 1, '已写入 localStorage');
  assert(saved.conversations[0].messages.length === 2, '保存了 2 条消息');
  assert(saved.settings.provider === 'ollama');
  ok('持久化：对话与设置已存 localStorage');

  // 8. 设置面板
  $('settingsBtn').click();
  await waitFor(() => !$('overlay').hidden, 3000, '设置打开');
  assert(d.querySelectorAll('.provider-panel[data-panel="ollama"] .chip-model').length >= 2, '设置里应有模型 chips');
  assert($('ollamaBase').value.indexOf('/ollama') > -1 || $('ollamaBase').value.indexOf('11434') > -1, '地址应已回填');
  $('providerSeg').querySelector('[data-provider="deepseek"]').click();
  assert(d.querySelector('.provider-panel[data-panel="deepseek"]').hidden === false, '切换到 DeepSeek 面板');
  assert(d.querySelector('.provider-panel[data-panel="ollama"]').hidden === true, 'Ollama 面板隐藏');
  $('providerSeg').querySelector('[data-provider="ollama"]').click();
  $('closeSettings').click();
  ok('设置面板：服务商切换 / 模型 chips / 关闭');

  // 9. 重新生成
  const contentBefore = d.querySelector('.msg-assistant .content').textContent;
  const regenBtn = d.querySelector('.msg-assistant [data-act="regen"]');
  regenBtn.click();
  await waitFor(() => {
    const el = d.querySelector('.msg-assistant .content');
    return el && el.textContent.trim().length > 5 && !d.querySelector('.typing');
  }, 45000, '重新生成');
  assert(d.querySelectorAll('.msg-assistant').length === 1, '重新生成不应堆叠助手消息');
  ok('重新生成：' + (d.querySelector('.msg-assistant .content').textContent.length) + ' 字');

  console.log('\n界面集成测试通过：' + passed + ' 项\n');
  w.close();
  process.exit(0);
})().catch((e) => {
  console.error('\n✗ 界面测试失败：', e && e.message);
  process.exit(1);
});
