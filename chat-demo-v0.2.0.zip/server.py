#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
server.py — 本地启动器（Python 标准库版，Node 不可用时的兜底）

  1) 静态服务：把本目录作为网站根目录
  2) /ollama/*  ->  转发到本机 Ollama（解决浏览器跨域 / 私有网络限制）
  3) /proxy?url= ->  转发任意 OpenAI 兼容接口
  4) /api/health ->  自检

用法：python server.py [--port 8787] [--ollama http://127.0.0.1:11434] [--no-open]
"""

import argparse
import json
import mimetypes
import os
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
MIME = {
    ".html": "text/html; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".md": "text/markdown; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
}

OLLAMA_BASE = "http://127.0.0.1:11434"


def ollama_alive():
    try:
        with urllib.request.urlopen(OLLAMA_BASE + "/api/version", timeout=3) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def try_start_ollama():
    env = dict(os.environ, OLLAMA_ORIGINS="*")
    try:
        kw = {}
        if os.name == "nt":
            kw["creationflags"] = 0x00000008  # DETACHED_PROCESS
        else:
            kw["start_new_session"] = True
        subprocess.Popen(["ollama", "serve"], env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
    except Exception as e:
        return False, str(e)
    for _ in range(20):
        time.sleep(1)
        info = ollama_alive()
        if info:
            return True, info
    return False, "ollama serve 启动超时"


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ChatDemo/0.2"

    # ---------- 工具 ----------
    def cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers",
                         "content-type,authorization,x-api-key,anthropic-version,anthropic-beta,accept,origin")
        self.send_header("Access-Control-Expose-Headers", "*")

    def send_json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.cors()
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        pass  # 静默，保持终端干净

    # ---------- 路由 ----------
    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_HEAD(self):
        self.route()

    def do_GET(self):
        self.route()

    def do_POST(self):
        self.route()

    def do_PUT(self):
        self.route()

    def do_DELETE(self):
        self.route()

    def route(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/health":
            info = ollama_alive()
            return self.send_json(200, {
                "ok": True,
                "server": "chat-demo-v0.2.0-py",
                "ollama": {"reachable": bool(info), "base": OLLAMA_BASE, "version": (info or {}).get("version")}
            })

        if path.startswith("/ollama/"):
            rest = path[len("/ollama"):]
            target = OLLAMA_BASE + rest + (("?" + parsed.query) if parsed.query else "")
            return self.raw_forward(target, rewrite_path=rest + (("?" + parsed.query) if parsed.query else ""))

        if path in ("/proxy", "/proxy/"):
            qs = parse_qs(parsed.query)
            target = (qs.get("url") or [""])[0]
            if not target:
                return self.send_json(400, {"error": "缺少 url 参数"})
            return self.raw_forward(target, rewrite_path=None)

        if self.command in ("GET", "HEAD"):
            return self.static(path)

        self.send_json(405, {"error": "method not allowed"})

    # ---------- 静态文件 ----------
    def static(self, path):
        rel = unquote(path)
        if rel in ("/", ""):
            rel = "/index.html"
        full = os.path.normpath(os.path.join(ROOT, rel.lstrip("/\\")))
        if not full.startswith(ROOT):
            return self.send_json(403, {"error": "forbidden"})
        if not os.path.isfile(full):
            return self.send_json(404, {"error": "not found", "path": rel})
        ctype = MIME.get(os.path.splitext(full)[1].lower()) or mimetypes.guess_type(full)[0] or "application/octet-stream"
        with open(full, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.cors()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    # ---------- 原始转发（保留流式） ----------
    def raw_forward(self, target_url, rewrite_path=None):
        u = urlparse(target_url)
        if u.scheme not in ("http", "https") or not u.hostname:
            return self.send_json(400, {"error": "只支持 http / https 地址", "target": target_url})

        body = b""
        if self.command in ("POST", "PUT", "PATCH", "DELETE"):
            length = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(length) if length else b""

        port = u.port or (443 if u.scheme == "https" else 80)
        try:
            sock = socket.create_connection((u.hostname, port), timeout=30)
            if u.scheme == "https":
                sock = ssl.create_default_context().wrap_socket(sock, server_hostname=u.hostname)
        except Exception as e:
            return self.send_json(502, {
                "error": "上游不可达：%s" % e, "target": target_url,
                "hint": "Ollama 没启动？执行 ollama serve；或检查地址是否正确。"
            })

        path = rewrite_path if rewrite_path else (u.path or "/") + (("?" + u.query) if u.query else "")

        lines = ["%s %s HTTP/1.1" % (self.command, path), "Host: %s" % u.netloc, "Connection: close"]
        for k, v in self.headers.items():
            lk = k.lower()
            if lk in ("host", "connection", "proxy-connection", "content-length", "transfer-encoding"):
                continue
            lines.append("%s: %s" % (k, v))
        if body:
            lines.append("Content-Length: %d" % len(body))
        head = ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1")
        try:
            sock.sendall(head + body)
        except Exception as e:
            sock.close()
            return self.send_json(502, {"error": "发送请求失败：%s" % e})

        # 读取响应头
        header_bytes = b""
        while b"\r\n\r\n" not in header_bytes:
            chunk = sock.recv(4096)
            if not chunk:
                break
            header_bytes += chunk
            if len(header_bytes) > 65536:
                break

        if b"\r\n\r\n" not in header_bytes:
            sock.close()
            return self.send_json(502, {"error": "上游返回不完整"})

        raw_head, rest = header_bytes.split(b"\r\n\r\n", 1)
        hl = raw_head.decode("latin-1").split("\r\n")
        status_line = hl[0]
        try:
            status = int(status_line.split(" ")[1])
        except Exception:
            status = 502
        headers = []
        for line in hl[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers.append((k.strip(), v.strip()))

        self.send_response(status)
        drop = {"connection", "keep-alive", "transfer-encoding", "access-control-allow-origin"}
        for k, v in headers:
            if k.lower() in drop:
                continue
            self.send_header(k, v)
        self.cors()
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

        try:
            if self.command != "HEAD":
                if rest:
                    self.wfile.write(rest)
                    self.wfile.flush()
                while True:
                    chunk = sock.recv(8192)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    self.wfile.flush()
        except Exception:
            pass
        finally:
            try:
                sock.close()
            except Exception:
                pass


def main():
    global OLLAMA_BASE
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8787)))
    ap.add_argument("--ollama", default=os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434"))
    ap.add_argument("--no-open", action="store_true")
    args = ap.parse_args()
    OLLAMA_BASE = args.ollama.rstrip("/")

    port = args.port
    httpd = None
    for i in range(8):
        try:
            httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            port += 1
    if httpd is None:
        print("端口都被占用了，换个端口：python server.py --port 8899")
        sys.exit(1)

    url = "http://127.0.0.1:%d/" % port
    print("")
    print("  Chat v0.2 已启动")
    print("  --------------------------------------------")
    print("  页面      " + url)
    print("  Ollama    " + OLLAMA_BASE + " (代理路径 /ollama)")
    print("  停止      Ctrl+C")
    print("")

    info = ollama_alive()
    if info:
        print("  Ollama 已连通，版本 " + str(info.get("version")))
    else:
        print("  Ollama 没在运行，正在尝试自动启动 …")
        started, detail = try_start_ollama()
        if started:
            print("  Ollama 已启动，版本 " + str((detail or {}).get("version")))
        else:
            print("  ⚠ 自动启动失败：" + str(detail))
            print("  请手动执行：ollama serve")
    print("")

    if not args.no_open:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  已停止")


if __name__ == "__main__":
    main()
