# Chat v0.2 — 更顺手的本地大模型对话前端

> 基于 `chat-demo-v0.1.3` 重写。原包只有编译后的压缩产物（`main.*.js` 477KB / `index.html`），没有源码，无法在其上继续加功能，所以按原版风格重做成可维护的源码工程，并补上「一键接入 Ollama、深度思考开关、模型切换」。

![浅色](docs/preview-light.png)

![深色](docs/preview-dark.png)

## 三步用起来

1. 双击 **`启动.bat`**（macOS 用 `启动.command`）。
2. 浏览器自动打开 `http://127.0.0.1:8787`。
3. 首次进入自动探测 Ollama，直接选好本地模型就能聊。

启动脚本会做四件事：

- 起一个本地静态服务 + 转发服务（`server.js`，无 Node 时回退 `server.py`）
- 检测 Ollama；**没在运行就自动 `ollama serve`**
- 用 `/ollama/*` 把请求转发到 `127.0.0.1:11434`，**彻底绕开浏览器跨域 / 私有网络限制**
- 自动打开浏览器

> 直接双击 `index.html` 也能打开，但浏览器会对 `file://` → `localhost` 的请求做跨域拦截，此时页面会提示你改用启动脚本。

## 这一版新增什么

| 能力 | 说明 |
| --- | --- |
| **一键接入 Ollama** | 自动按 `页面代理 → 已存地址 → 127.0.0.1:11434 → localhost:11434` 依次探测，成功后载入全部本地模型并选好默认模型；失败直接给出四条排查步骤和可复制的命令 |
| **深度思考一键开关** | 输入框左侧常驻开关，`Ctrl/Cmd+Shift+D` 也能切。开启后思考过程以可折叠的「已深度思考（用时 x 秒）」块实时流式展示，生成结束自动收起 |
| **模型随时切换** | 输入框内的模型胶囊 → 浮层支持搜索、刷新、能力标签（思考 / 视觉 / 参数量 / 体积），点一下立即生效，下一句就用新模型 |
| 三种服务商 | Ollama 本地、DeepSeek 官方、任意 OpenAI 兼容接口（vLLM / LM Studio / One API / 中转站） |
| Markdown 渲染 | 标题、表格、列表、引用、链接、代码高亮（js/ts/py/json/bash/sql/html/css）+ 一键复制代码 |
| 会话管理 | 侧边栏历史、自动标题、重命名前的预览、删除、导出 Markdown |
| 消息操作 | 复制、重新生成、编辑用户消息并重发、删除 |
| 流式体验 | 停止生成（保留已生成内容）、自动贴底、手动上滑后不打断阅读、回到底部按钮 |
| 细节 | 深浅色主题 / 跟随系统、温度与上下文条数、系统提示词、字数提示、错误卡片带原因和建议 |

### 快捷键

| 快捷键 | 作用 |
| --- | --- |
| `Enter` / `Shift+Enter` | 发送 / 换行 |
| `Ctrl/Cmd+N` | 新建对话 |
| `Ctrl/Cmd+K` | 聚焦输入框 |
| `Ctrl/Cmd+Shift+D` | 开关深度思考 |
| `Ctrl/Cmd+B` | 收起 / 展开侧边栏 |
| `Esc` | 停止生成、关闭浮层或设置 |

## 深度思考在各服务商上的行为

- **Ollama**：直接下发 `think: true/false`，这是 Ollama 的原生参数，思考内容从 `message.thinking` 流式返回。
- **Ollama 模型不支持思考**：服务端返回 400 时自动去掉 `think` 参数重试一次，不会卡住对话；模型胶囊上也会标注是否声明了 `thinking` 能力。
- **DeepSeek**：`deepseek-reasoner` 天然输出 `reasoning_content`；用 `deepseek-chat` 时按开关尝试 `thinking: {type: enabled}`。
- **其他 OpenAI 兼容接口**：开启深度思考时带 `reasoning_effort: high`，被服务端拒绝（400）会自动降级重试，兼容性优先。
- 所有思考内容只用于展示，不进入后续上下文，避免把推理过程污染成对话历史。

## 模型默认选择策略

自动选模型时按「**优先支持思考 + 体积最小**」排序。这样做是因为大模型首次加载会吃掉大量内存/显存：

- `qwen3_0.6b:latest`（0.55GB）→ 默认首选
- `dsqwen3.5-9b:latest`（7.6GB）、`qwen3.6:latest`（14.5GB）→ 需要足够内存才能跑，列表里会显示体积，按需手动切换

## 文件结构

```
chat-demo-v0.2.0/
├─ index.html            页面骨架
├─ assets/
│  ├─ app.css            全部样式（浅色 / 深色 / 移动端）
│  ├─ app.js             界面与交互（发送、流式、浮层、设置、快捷键）
│  ├─ providers.js       服务适配层（Ollama / OpenAI 兼容 + 降级重试）
│  ├─ md.js              零依赖 Markdown 渲染 + 代码高亮
│  └─ store.js           状态与 localStorage 持久化
├─ server.js             启动器：静态服务 + /ollama 转发 + /proxy 通用转发
├─ server.py             同上，Python 标准库版（无 Node 时使用）
├─ 启动.bat / 启动.command
├─ tests/                冒烟测试与截图用示例数据
└─ README.md
```

## 设置面板

- **服务商**：Ollama / DeepSeek / OpenAI 兼容，三者配置各自独立保存，随时切换。
- **Ollama**：地址可改（默认 `http://127.0.0.1:11434`），「一键连接」重新探测，模型 chips 点一下即切换。
- **对话设置**：系统提示词、温度（0–1.5）、上下文条数（0 = 全部）、流式开关、主题。

配置和对话都存在浏览器 `localStorage`（键名 `chat-demo.v0.2`），不上传任何服务器。

## 常见问题

| 现象 | 处理 |
| --- | --- |
| 提示「连不上模型服务」 | 先确认 `ollama --version` 可用，再执行 `ollama serve`；或直接用 `启动.bat` 打开 |
| 提示跨域 / `Failed to fetch` | 你可能是双击 `index.html` 打开的，改用启动脚本；或设置 `$env:OLLAMA_ORIGINS="*"` 后重启 `ollama serve` |
| 连上但模型列表为空 | 终端执行 `ollama list`，没有模型就先 `ollama pull qwen3:0.6b` |
| DeepSeek 返回 401 | API Key 无效，设置里重新填 |
| 端口被占用 | 启动器会自动顺延端口（8787 → 8788 …）；也可 `node server.js --port 8899` |
| 27B 模型很慢 / 内存报警 | 换成小模型，模型列表里标着体积 |

## 自测

```bash
# 适配层 + Markdown + 存储（模拟服务，约 1 秒）
node tests/smoke.js

# 再加一轮真实 Ollama 推理（用最小的模型）
node tests/smoke.js --real

# 启动器：静态服务 / Ollama 转发 / 流式不被缓冲 / 通用转发
node server.js --no-open --port 8788 &
node tests/proxy.js 8788

# 界面链路：jsdom 驱动真实点击 + 真实推理
npm i jsdom --prefix %TEMP%\jsdomtest
set NODE_PATH=%TEMP%\jsdomtest\node_modules
node tests/ui.js http://127.0.0.1:8788/ qwen3_0.6b:latest
```

已验证：Markdown 渲染与注入拦截、NDJSON/SSE 流式、不支持思考时降级、中止生成、模型列表、深度思考开关、模型切换、重新生成、localStorage 持久化、启动器流式转发（首段 92–203ms）。

## 说明

- `server.js` / `server.py` 只监听 `127.0.0.1`，转发服务仅本机可用。
- `/proxy?url=` 只转发 `http(s)` 地址，是为浏览器跨域兜底用的，不需要可以不管。
- API Key 存在浏览器本地，公共电脑上请用完清理。
- 本项目为独立重写实现，遵循 MIT 许可。
