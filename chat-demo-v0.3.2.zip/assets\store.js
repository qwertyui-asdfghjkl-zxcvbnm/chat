/* =========================================================================
 * store.js — 状态管理与本地持久化
 * 纯浏览器脚本（非模块），同时兼容 node 环境做单元测试。
 * ========================================================================= */
(function (global) {
  'use strict';

  var KEY = 'chat-demo.v0.2';

  var memory = {};

  function safeGet(key) {
    try {
      if (typeof localStorage !== 'undefined') return localStorage.getItem(key);
    } catch (e) { /* 隐私模式等 */ }
    return memory[key] === undefined ? null : memory[key];
  }

  function safeSet(key, value) {
    try {
      if (typeof localStorage !== 'undefined') {
        if (value === null) localStorage.removeItem(key);
        else localStorage.setItem(key, value);
        return;
      }
    } catch (e) { /* 忽略 */ }
    if (value === null) delete memory[key];
    else memory[key] = value;
  }

  function uid(prefix) {
    return (prefix || 'id') + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
  }

  function defaults() {
    return {
      version: 2,
      settings: {
        provider: 'ollama',
        providers: {
          ollama: {
            base: 'http://127.0.0.1:11434',
            model: '',
            models: [],
            caps: {},          // { modelName: ['completion', 'thinking', ...] }
            autoConnect: true
          },
          deepseek: {
            base: 'https://api.deepseek.com/v1',
            apiKey: '',
            model: 'deepseek-chat',
            models: []
          },
          custom: {
            base: '',
            apiKey: '',
            model: '',
            models: []
          }
        },
        systemPrompt: '',
        temperature: 0.7,
        contextMessages: 12,
        stream: true,
        theme: 'light',
        deepThink: false,
        effort: 'off',       // 思考等级：off | low | medium | high | max
        typing: 'normal',    // 打字机：off | fast | normal
        fontSize: 'md'       // 消息字号：sm | md | lg
      },
      conversations: [],
      currentId: null,
      uiCollapsed: false
    };
  }

  function deepMerge(base, patch) {
    if (Array.isArray(base)) {
      return Array.isArray(patch) ? patch.slice() : base.slice();
    }
    if (base && typeof base === 'object') {
      var out = {};
      var k;
      for (k in base) if (Object.prototype.hasOwnProperty.call(base, k)) out[k] = base[k];
      if (patch && typeof patch === 'object') {
        for (k in patch) {
          if (!Object.prototype.hasOwnProperty.call(patch, k)) continue;
          out[k] = deepMerge(base[k], patch[k]);
        }
      }
      return out;
    }
    return patch === undefined ? base : patch;
  }

  var pendingSave = null;

  var Store = {
    state: defaults(),
    _subs: [],

    /* ---- 载入 / 保存 ---- */
    load: function () {
      var raw = safeGet(KEY);
      var loaded = null;
      if (raw) {
        try { loaded = JSON.parse(raw); } catch (e) { loaded = null; }
      }
      this.state = deepMerge(defaults(), loaded || {});
      this.normalize();
      return this.state;
    },

    // 修正历史数据里可能出现的不一致
    normalize: function () {
      var s = this.state;
      if (!Array.isArray(s.conversations)) s.conversations = [];
      s.conversations.forEach(function (c) {
        if (!Array.isArray(c.messages)) c.messages = [];
        if (!c.id) c.id = uid('c');
        if (!c.title) c.title = '未命名对话';
        if (!c.createdAt) c.createdAt = Date.now();
        if (!c.updatedAt) c.updatedAt = c.createdAt;
        c.messages.forEach(function (m) {
          if (m.streaming) {
            m.streaming = false;
            if (!m.content && !m.thinking && !m.error) m.content = '（上次生成被中断）';
          }
        });
      });
      if (Array.isArray(s.settings.providers.ollama.models) === false) s.settings.providers.ollama.models = [];
      if (!s.settings.providers.ollama.caps) s.settings.providers.ollama.caps = {};
      if (!['ollama', 'deepseek', 'custom'].includes(s.settings.provider)) s.settings.provider = 'ollama';
      if (!['light', 'dark', 'system'].includes(s.settings.theme)) s.settings.theme = 'light';
      if (!['off', 'fast', 'normal'].includes(s.settings.typing)) s.settings.typing = 'normal';
      if (!['off', 'low', 'medium', 'high', 'max'].includes(s.settings.effort)) s.settings.effort = 'off';
      // 老数据只有 deepThink 布尔：开着但等级缺失/为 off，按「高」补齐
      if (s.settings.effort === 'off' && s.settings.deepThink === true) s.settings.effort = 'high';
      // 等级是唯一真相，开关由它派生，避免两处打架
      s.settings.deepThink = s.settings.effort !== 'off';
      if (!['sm', 'md', 'lg'].includes(s.settings.fontSize)) s.settings.fontSize = 'md';
      var cur = s.conversations.filter(function (c) { return c.id === s.currentId; })[0];
      if (!cur) s.currentId = s.conversations.length ? s.conversations[0].id : null;
      return s;
    },

    save: function (immediate) {
      var self = this;
      var write = function () {
        pendingSave = null;
        try { safeSet(KEY, JSON.stringify(self.state)); } catch (e) { /* 配额满 */ }
      };
      if (immediate) {
        if (pendingSave) { clearTimeout(pendingSave); pendingSave = null; }
        write();
        return;
      }
      if (pendingSave) return;
      pendingSave = setTimeout(write, 180);
      if (pendingSave && pendingSave.unref) pendingSave.unref();
    },

    /* ---- 订阅 ---- */
    subscribe: function (fn) {
      this._subs.push(fn);
      return function () {
        var i = Store._subs.indexOf(fn);
        if (i >= 0) Store._subs.splice(i, 1);
      };
    },

    emit: function (reason) {
      this._subs.slice().forEach(function (fn) {
        try { fn(reason); } catch (e) { /* 单个订阅失败不影响其它 */ }
      });
    },

    update: function (mutator, reason) {
      mutator(this.state);
      this.save();
      if (reason !== false) this.emit(reason || 'update');
    },

    /* ---- 便捷读取 ---- */
    settings: function () { return this.state.settings; },

    providerConfig: function (id) {
      var s = this.state.settings;
      return s.providers[id || s.provider];
    },

    /* ---- 对话 ---- */
    current: function () {
      var s = this.state;
      for (var i = 0; i < s.conversations.length; i++) {
        if (s.conversations[i].id === s.currentId) return s.conversations[i];
      }
      return null;
    },

    createConversation: function (title) {
      var conv = {
        id: uid('c'),
        title: title || '新对话',
        createdAt: Date.now(),
        updatedAt: Date.now(),
        messages: []
      };
      this.state.conversations.unshift(conv);
      this.state.currentId = conv.id;
      this.save();
      this.emit('conversation');
      return conv;
    },

    ensureCurrent: function () {
      return this.current() || this.createConversation();
    },

    selectConversation: function (id) {
      this.state.currentId = id;
      this.save();
      this.emit('conversation');
    },

    deleteConversation: function (id) {
      var s = this.state;
      s.conversations = s.conversations.filter(function (c) { return c.id !== id; });
      if (s.currentId === id) s.currentId = s.conversations.length ? s.conversations[0].id : null;
      this.save();
      this.emit('conversation');
    },

    renameConversation: function (id, title) {
      var c = this.state.conversations.filter(function (x) { return x.id === id; })[0];
      if (!c) return;
      c.title = (title || '').trim() || '未命名对话';
      c.updatedAt = Date.now();
      this.save();
      this.emit('conversation');
    },

    newMessage: function (role, content, extra) {
      return Object.assign({
        id: uid('m'),
        role: role,
        content: content || '',
        ts: Date.now()
      }, extra || {});
    },

    appendMessage: function (conv, msg) {
      conv.messages.push(msg);
      conv.updatedAt = Date.now();
      if (conv.title === '新对话' && msg.role === 'user' && msg.content) {
        conv.title = autoTitle(msg.content);
      }
      this.save();
      return msg;
    },

    clearAll: function () {
      this.state.conversations = [];
      this.state.currentId = null;
      this.save();
      this.emit('conversation');
    },

    exportJSON: function () {
      return JSON.stringify(this.state, null, 2);
    }
  };

  function autoTitle(text) {
    var t = String(text).replace(/\s+/g, ' ').trim();
    if (!t) return '新对话';
    return t.length > 28 ? t.slice(0, 28) + '…' : t;
  }

  Store.autoTitle = autoTitle;
  Store.uid = uid;

  global.ChatStore = Store;

  if (typeof module !== 'undefined' && module.exports) module.exports = Store;
})(typeof window !== 'undefined' ? window : globalThis);
