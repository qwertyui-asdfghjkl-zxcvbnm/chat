/* =========================================================================
 * tests/update.js — 更新检查逻辑（GitHub / Cloudflare 静态清单 / 双源切换）
 *   node tests/update.js
 * ========================================================================= */
'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let passed = 0;
const ok = (n) => { passed++; console.log('  ✓ ' + n); };

const CODE = fs.readFileSync(path.join(__dirname, '..', 'assets', 'updater.js'), 'utf8');

function load(releases, opts) {
  opts = opts || {};
  const ctx = {
    console,
    setTimeout,
    document: {
      createElement: () => ({ click() { }, remove() { }, style: {}, setAttribute() { } }),
      body: { appendChild() { } }
    },
    fetch: async (url) => {
      ctx.lastUrl = url;
      ctx.urls.push(url);
      if (ctx.ChatUpdater) ctx.ChatUpdater.lastUrl = url;
      if (opts.fetch) return opts.fetch(url, ctx);
      return { status: 200, ok: true, json: async () => releases };
    }
  };
  ctx.urls = [];
  ctx.window = ctx;
  vm.createContext(ctx);
  ctx.CHAT_VERSION = { version: opts.version || '0.3.1', build: '', channel: 'stable' };
  ctx.CHAT_UPDATE = Object.assign({
    enabled: true,
    source: 'github',
    github: { owner: 'qwertyui', repo: 'chat', apiBase: 'https://api.test', assetPattern: 'chat-demo-.*\\.zip' },
    channel: 'stable'
  }, opts.config || {});
  vm.runInContext(CODE, ctx);
  ctx.ChatUpdater.ctx = ctx;
  return ctx.ChatUpdater;
}

const jsonRes = (data, status) => ({
  status: status || 200,
  ok: (status || 200) === 200,
  json: async () => data
});

const ASSET = (name, size, digest) => ({
  name,
  size,
  digest: 'sha256:' + (digest || 'abc123'),
  browser_download_url: 'https://github.com/o/r/releases/download/v0.3.2/' + name
});

const release = (tag, opts) => Object.assign({
  tag_name: tag,
  name: 'Chat ' + tag,
  draft: false,
  prerelease: false,
  published_at: '2026-11-21T10:00:00Z',
  body: '## 更新\n- 思考等级滑条\n- 更新走 GitHub',
  assets: [ASSET('chat-demo-' + tag.replace(/^v/, '') + '.zip', 409600)]
}, opts || {});

(async () => {
  console.log('\n[GitHub Releases]');

  {
    const U = load([release('v0.3.2')]);
    const r = await U.check();
    assert.equal(r.ok, true, '检查成功');
    assert.equal(r.hasUpdate, true, '0.3.2 > 0.3.1，应发现更新');
    assert.equal(r.manifest.version, '0.3.2', '去掉 v 前缀');
    assert.equal(r.manifest.assetName, 'chat-demo-0.3.2.zip', '挑中 zip');
    assert.equal(r.manifest.sha256, 'abc123', '解出 sha256:');
    assert.equal(r.manifest.notes.indexOf('思考等级') > -1, true, '带更新说明');
    assert(U.lastUrl.indexOf('/repos/qwertyui/chat/releases') > -1, '走 releases 接口');
    ok('版本比较 / 附件挑选 / sha256 / 说明');
  }

  {
    const U = load([release('v0.3.1')]);
    const r = await U.check();
    assert.equal(r.ok, true);
    assert.equal(r.hasUpdate, false, '同版本不算更新');
    ok('同版本：已是最新');
  }

  {
    const U = load([
      release('v0.4.0-beta', { prerelease: true }),
      release('v0.3.2')
    ]);
    const r = await U.check();
    assert.equal(r.manifest.version, '0.3.2', 'stable 通道跳过预发布');
    ok('stable 通道跳过预发布');
  }

  {
    const U = load([release('v0.4.0-beta', { prerelease: true })], { config: { channel: 'beta' } });
    const r = await U.check();
    assert.equal(r.manifest.version, '0.4.0-beta', 'beta 通道收预发布');
    assert.equal(r.manifest.channel, 'beta');
    ok('beta 通道包含预发布');
  }

  {
    const U = load([release('v0.3.2', { assets: [ASSET('source.tar.gz', 1000)] })]);
    const r = await U.check();
    assert.equal(r.ok, false, '没有 zip 应报错');
    assert(r.error.indexOf('zip') > -1, '错误信息提到 zip');
    ok('Release 缺少 zip 时明确报错');
  }

  {
    const U = load([]);
    const r = await U.check();
    assert.equal(r.ok, true);
    assert.equal(r.hasUpdate, false, '一个 Release 都没有 = 最新');
    assert.equal(r.manifest, null);
    ok('空 Release 列表不报错');
  }

  {
    const U = load([], { config: { github: { owner: '', repo: '' } } });
    assert.equal(U.enabled(), false, '没配仓库时不可用');
    ok('未配置仓库时禁用');
  }

  {
    const manifest = {
      version: '0.3.2',
      channel: 'stable',
      publishedAt: '2026-11-21',
      notes: ['思考等级滑条', '更新走 Cloudflare'],
      downloadUrl: 'chat-demo-v0.3.2.zip',
      sha256: 'deadbeef'
    };
    const U = load(manifest, { config: { source: 'static', static: { base: 'https://chat-demo.pages.dev', manifestPath: 'manifest.json' } } });
    assert.equal(U.enabled(), true, '配了地址就可用');
    const r = await U.check();
    assert.equal(r.ok, true);
    assert.equal(r.hasUpdate, true);
    assert.equal(r.manifest.version, '0.3.2');
    assert.equal(r.manifest.downloadUrl, 'https://chat-demo.pages.dev/chat-demo-v0.3.2.zip', '相对地址按清单目录解析');
    assert.equal(r.manifest.sha256, 'deadbeef');
    assert(U.lastUrl.indexOf('https://chat-demo.pages.dev/manifest.json') === 0, '读静态清单');
    ok('Cloudflare 静态清单：相对下载地址 / sha256 / 说明');
  }

  {
    const U = load({}, { config: { source: 'static', static: { base: '', manifestPath: 'manifest.json' } } });
    assert.equal(U.enabled(), false, '地址为空时禁用');
    ok('静态源未填地址时禁用');
  }

  console.log('\n[双源自动切换]');

  const AUTO = {
    source: 'auto',
    sources: ['github', 'static'],
    github: { owner: 'qwertyui', repo: 'chat', apiBase: 'https://api.test', assetPattern: 'chat-demo-.*\\.zip' },
    static: { base: 'https://chat-demo.pages.dev', manifestPath: 'manifest.json' }
  };
  const MANIFEST = {
    version: '0.3.2',
    channel: 'stable',
    notes: ['Cloudflare 侧更新'],
    downloadUrl: './chat-demo-v0.3.2.zip'
  };

  {
    // GitHub 正常：不应再去请求 Cloudflare
    const U = load(null, {
      config: AUTO,
      fetch: async (url) => url.indexOf('/repos/') > -1 ? jsonRes([release('v0.3.2')]) : jsonRes(MANIFEST)
    });
    const r = await U.check();
    assert.equal(r.ok, true);
    assert.equal(r.via, 'github', 'GitHub 成功就用 GitHub');
    assert.equal(r.manifest.assetName, 'chat-demo-0.3.2.zip');
    assert.equal(U.ctx.urls.some((u) => u.indexOf('chat-demo.pages.dev') > -1), false, '拿到 GitHub 结果就不再查 Cloudflare（省流量）');
    assert.equal(U.ctx.urls.length, 1);
    ok('GitHub 优先：成功则不请求 Cloudflare');
  }

  {
    // GitHub 404（还没发 Release）→ 自动换 Cloudflare
    const U = load(null, {
      config: AUTO,
      fetch: async (url) => url.indexOf('/repos/') > -1 ? jsonRes({ message: 'Not Found' }, 404) : jsonRes(MANIFEST)
    });
    const r = await U.check();
    assert.equal(r.ok, true, 'GitHub 失败不算整体失败');
    assert.equal(r.via, 'static', '自动切到 Cloudflare');
    assert.equal(r.hasUpdate, true);
    assert.equal(r.manifest.downloadUrl, 'https://chat-demo.pages.dev/chat-demo-v0.3.2.zip');
    assert.equal(U.ctx.urls.length, 2, '先 GitHub 后 Cloudflare');
    ok('GitHub 不可用：自动切 Cloudflare');
  }

  {
    // 两个都挂：报出两边的错
    const U = load(null, {
      config: AUTO,
      fetch: async (url) => url.indexOf('/repos/') > -1 ? jsonRes({}, 403) : jsonRes({}, 500)
    });
    const r = await U.check();
    assert.equal(r.ok, false);
    assert(r.error.indexOf('GitHub') > -1 && r.error.indexOf('Cloudflare') > -1, '错误信息包含两个源');
    ok('双源都失败：分别说明原因');
  }

  {
    // Cloudflare 只有清单没有 zip 字段 → 落到报错，不会假装成功
    const U = load(null, {
      config: AUTO,
      fetch: async (url) => url.indexOf('/repos/') > -1 ? jsonRes({}, 404) : jsonRes({ version: '0.3.2' })
    });
    const r = await U.check();
    assert.equal(r.ok, false);
    assert(r.error.indexOf('downloadUrl') > -1, '缺 downloadUrl 要报错');
    ok('静态清单缺字段时报错');
  }

  {
    const U = load([release('v0.3.2')], { config: { source: 'server', enabled: true } });
    assert.equal(U.source(), 'server', '可切回服务器模式');
    ok('保留自建服务器模式');
  }

  console.log('\n全部通过：' + passed + ' 项\n');
})().catch((e) => {
  console.error('\n✗ 测试失败：', e.message, '\n');
  process.exit(1);
});
