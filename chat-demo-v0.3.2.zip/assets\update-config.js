/* =========================================================================
 * update-config.js — 更新来源
 *
 * 默认走 GitHub Releases：每次发版在仓库里建一个 Release，附上 chat-demo-vX.Y.Z.zip。
 * 页面检查时读公开的 releases 列表，比较版本号；点「立即更新」就是下载那个 zip。
 * 浏览器没有权限替换程序文件，所以下载完仍需解压覆盖（设置与对话不会丢）。
 *
 * 也可以换回自建更新服务器：把 source 改成 'server'，并配好 endpoint / UPDATE_SERVER。
 * 接口契约见 docs/update-protocol.md
 * ========================================================================= */
window.CHAT_UPDATE = {
  enabled: true,

  // 'auto' 会按 sources 顺序尝试，拿到一个能用的清单就停，不通才换下一个（省流量）
  // 也可写死：'static'（Cloudflare）| 'github' | 'server'
  source: 'auto',
  // GitHub 优先（国内也能通，失败再走 Cloudflare）
  sources: ['github', 'static'],

  // 静态清单：把 manifest.json 和 zip 放在同一个目录，上传到 Cloudflare Pages
  static: {
    base: 'https://chat.deepseek-coder.kdns.fr',
    manifestPath: 'manifest.json'
  },

  github: {
    owner: 'qwertyui-asdfghjkl-zxcvbnm',
    repo: 'chat',
    // 只挑 zip 附件，避免把源码包之类的东西当成更新包
    assetPattern: 'chat-demo-.*\\.zip'
  },

  // stable = 只要正式版；beta = 预发布也算
  channel: 'stable',

  // ---- 自建服务器模式才用得到 ----
  endpoint: '/api/update',
  manifestPath: '/manifest.json',
  applyEndpoint: '/api/update/apply',

  // 服务器模式失败时，退回浏览器直接下载
  fallbackToDownload: true
};
