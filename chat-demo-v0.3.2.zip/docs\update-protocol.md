# 更新协议（v0.3.2）

v0.3.2 起更新默认走**双源自动**，不再依赖自建服务器：

```
① GitHub Releases   有 zip 附件 → 用它，后面的源不再请求（省流量）
② Cloudflare Pages  <static.base>/manifest.json → 用清单里的 zip
③ 自建更新服务      只有把 source 写成 'server' 才会走
```

`assets/update-config.js` 控制顺序与地址：

```js
window.CHAT_UPDATE = {
  enabled: true,
  source: 'auto',                    // 'auto' | 'github' | 'static' | 'server'
  sources: ['github', 'static'],     // auto 模式的尝试顺序
  github: {
    owner: 'qwertyui-asdfghjkl-zxcvbnm',
    repo: 'chat',
    assetPattern: 'chat-demo-.*\\.zip'   // 只认 zip，源码包不会被当成更新包
  },
  static: {
    base: 'https://chat.deepseek-coder.kdns.fr', // Cloudflare Pages 域名
    manifestPath: 'manifest.json'
  },
  channel: 'stable'
};
```

## 1. 参与的文件

| 文件 | 作用 |
| --- | --- |
| `assets/version.js` | 当前版本号（`CHAT_VERSION`），发布时改这里 |
| `assets/update-config.js` | 更新来源与地址（`CHAT_UPDATE`） |
| `assets/updater.js` | 检查 / 下载逻辑（`ChatUpdater`） |
| `cloudflare/` | 上传到 Cloudflare Pages 的目录：`manifest.json` + zip |
| `docs/update-protocol.md` | 本文档 |

## 2. GitHub Releases 源

`GET https://api.github.com/repos/<owner>/<repo>/releases?per_page=10`

- 过滤 `draft`，`stable` 通道再过滤 `prerelease`；
- tag 去掉 `v` 前缀当版本号；
- 附件里挑第一个匹配 `assetPattern` 的 `.zip`；
- `asset.digest`（形如 `sha256:...`）存在时解析成 `sha256`；
- 仓库不存在、限流（403/429）、没有附件都会报出具体原因。

发版：`Releases → Draft a new release`，tag 写 `v0.3.2`，附件上传 `chat-demo-v0.3.2.zip`。

## 3. Cloudflare 静态清单（manifest.json）

```json
{
  "version": "0.3.2",
  "channel": "stable",
  "publishedAt": "2026-11-21",
  "notes": ["思考等级滑条", "更新改走 GitHub + Cloudflare"],
  "downloadUrl": "chat-demo-v0.3.2.zip",
  "sha256": "zip 的 sha256（hex）",
  "size": 409600,
  "minVersion": "0.2.0"
}
```

字段说明：

- `version`（必填）：语义化版本，逐段数字比较，`0.3.10 > 0.3.9`。
- `channel`：`stable` / `beta`，缺省沿用配置。
- `publishedAt`：`YYYY-MM-DD`，弹窗里显示。
- `notes`：字符串数组，也可以是一段用换行分隔的字符串。
- `downloadUrl`（必填）：zip 地址。**可以写相对路径**（如 `chat-demo-v0.3.2.zip`），
  前端会按 `static.base` 拼成绝对地址；换 CDN 域名不用改清单。
- `sha256`：zip 的 sha256（hex），弹窗里展示，方便手动核对。
- `size`：字节数，弹窗里显示大小。
- `minVersion`：可选，低于它时提示「请先手动升级到 minVersion」。

上传：Cloudflare 后台 **Workers & Pages → Create → Pages → Upload assets**，
把 `cloudflare/` 目录整个拖进去（里面只有 `manifest.json` 和 zip），
项目名建议 `chat-demo`，部署完把实际域名填回 `static.base`。

## 4. 双源切换规则

- 按 `sources` 顺序逐个尝试；
- **第一个拿到有效清单的源就停**，不再请求后面的源（省流量）；
- GitHub 还没发 Release（404）、限流、没 zip 附件，都会自动落到 Cloudflare；
- 两个都失败时，错误信息分别带上「GitHub：…；Cloudflare：…」；
- 版本比较始终以本地 `assets/version.js` 为准，只有更新的版本才会提示。

## 5. 自建服务器模式（保留）

把 `source` 写成 `'server'` 时行为与旧版一致：

### GET `/api/update/manifest.json?channel=stable`

由本地启动器（`server.js` / `server.py`）转发到 `<UPDATE_SERVER>/manifest.json`；
没配置 `--update-server` 时返回 `501`：

```json
{ "error": "更新服务器未配置", "hint": "...", "version": "0.3.2" }
```

### POST `/api/update/apply`

请求体：

```json
{
  "version": "0.3.2",
  "downloadUrl": "https://你的服务器/releases/chat-demo-v0.3.2.zip",
  "sha256": "……",
  "channel": "stable"
}
```

本版仍是占位接口，固定返回 `501`。前端收到 `404 / 501`（或网络失败）且
`fallbackToDownload: true` 时，会退化为浏览器直接下载 zip。

启动器若实现 apply，建议顺序：校验版本 → 下载到临时目录（限大小/超时）→
校验 `sha256` → 备份 → 解压并检查关键文件 → 原子替换（失败回滚）→ 返回
`200 { "ok": true, "message": "更新完成，刷新页面后生效" }`。

## 6. 设计取舍

- **浏览器不做文件替换**：网页没有权限改程序目录，所以 GitHub / Cloudflare 两个源
  都只负责「发现 + 下载」，替换仍是解压覆盖；将来启动器实现 apply 再接管。
- **先 GitHub 后 Cloudflare**：GitHub 接口小、响应快，国内多数网络能通；
  通不了才发第二个请求，避免每次都查两遍。
- **清单可相对路径**：Pages 域名可能带随机后缀，清单里写相对路径最省事。

