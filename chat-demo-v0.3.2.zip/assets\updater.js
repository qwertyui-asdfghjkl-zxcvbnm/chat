/* =========================================================================
 * updater.js — 更新检查 / 下载
 *
 * 两种来源：
 *  - github：读仓库的 Releases（公开接口，不需要登录），比较 tag 版本号，
 *            zip 附件就是更新包；浏览器只能下载，替换仍由用户解压覆盖。
 *  - server：自建更新服务器模式，交给本地启动器下载/校验/替换。
 *
 * enabled=false 时所有入口都不可点（设置页用遮罩挡住）。
 * ========================================================================= */
(function (global) {
  'use strict';

  var CFG = Object.assign({
    enabled: false,
    source: 'static',
    static: { base: '', manifestPath: 'manifest.json' },
    github: { owner: '', repo: '', apiBase: 'https://api.github.com', assetPattern: '.*\\.zip' },
    endpoint: '/api/update',
    channel: 'stable',
    manifestPath: '/manifest.json',
    applyEndpoint: '/api/update/apply',
    fallbackToDownload: true
  }, global.CHAT_UPDATE || {});

  var LOCAL = global.CHAT_VERSION || { name: 'chat-demo', version: '0.0.0', build: '' };

  function parse(v) {
    return String(v || '0').replace(/^v/i, '').split(/[.\-+]/).map(function (s) {
      var n = parseInt(s, 10);
      return isNaN(n) ? 0 : n;
    });
  }

  function compare(a, b) {
    var pa = parse(a), pb = parse(b);
    var len = Math.max(pa.length, pb.length);
    for (var i = 0; i < len; i++) {
      var x = pa[i] || 0, y = pb[i] || 0;
      if (x > y) return 1;
      if (x < y) return -1;
    }
    return 0;
  }

  function openDownload(url) {
    var a = document.createElement('a');
    a.href = url;
    a.rel = 'noopener noreferrer';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { a.remove(); }, 300);
  }

  var Updater = {
    config: CFG,
    local: LOCAL,
    status: 'idle',        // idle | checking | latest | available | applying | error | disabled
    manifest: null,
    error: null,

    source: function () {
      if (CFG.source === 'server') return 'server';
      if (CFG.source === 'github') return 'github';
      if (CFG.source === 'static') return 'static';
      return 'auto';
    },

    /** auto 模式下要尝试的来源（按顺序，前面的优先）。 */
    sources: function () {
      var mode = this.source();
      if (mode !== 'auto') return [mode];
      var list = Array.isArray(CFG.sources) && CFG.sources.length ? CFG.sources : ['static', 'github'];
      return list.filter(function (s) { return s === 'static' || s === 'github' || s === 'server'; });
    },

    /** 某个来源是否具备可用配置。 */
    canUse: function (src) {
      if (src === 'github') return !!this.repo();
      if (src === 'static') return !!this.staticBase();
      if (src === 'server') return !!CFG.enabled;
      return false;
    },

    staticBase: function () {
      return String((CFG.static && CFG.static.base) || '').replace(/\/+$/, '');
    },

    repo: function (options) {
      var g = Object.assign({}, CFG.github || {}, (options && options.github) || {});
      var owner = String(g.owner || '').trim();
      var repo = String(g.repo || '').trim();
      if (!owner || !repo) return null;
      return { owner: owner, repo: repo, apiBase: String(g.apiBase || 'https://api.github.com').replace(/\/+$/, '') };
    },

    enabled: function () {
      var self = this;
      return this.sources().some(function (s) { return self.canUse(s); });
    },

    url: function (path) {
      return String(CFG.endpoint || '').replace(/\/+$/, '') + path;
    },

    /**
     * 检查更新
     * @returns {{ok:boolean, hasUpdate:boolean, manifest?:object, error?:string}}
     */
    check: async function (options) {
      options = options || {};
      if (!this.enabled()) {
        this.status = 'disabled';
        return { ok: false, hasUpdate: false, error: '还没配置任何更新来源' };
      }
      this.status = 'checking';
      this.error = null;

      var list = this.sources();
      var attempts = [];
      var errors = [];
      var best = null;

      for (var i = 0; i < list.length; i++) {
        var src = list[i];
        if (!this.canUse(src)) continue;
        try {
          var m = await this.fetchFrom(src, options);
          attempts.push({ source: src, ok: true, version: m ? m.version : '' });
          if (m) {
            // 拿到第一个能用的清单就停，不再请求后面的源（省流量）
            best = { manifest: m, source: src };
            break;
          }
        } catch (err) {
          var msg = err && err.message ? err.message : String(err);
          attempts.push({ source: src, ok: false, error: msg });
          errors.push((src === 'github' ? 'GitHub' : src === 'static' ? 'Cloudflare' : '更新服务') + '：' + msg);
        }
      }

      this.sourcesTried = attempts;

      if (!best) {
        if (errors.length) {
          this.status = 'error';
          this.error = errors.join('；');
          return { ok: false, hasUpdate: false, error: this.error, attempts: attempts };
        }
        this.manifest = null;
        this.status = 'latest';
        return { ok: true, hasUpdate: false, manifest: null, attempts: attempts };
      }

      this.manifest = best.manifest;
      this.via = best.source;
      var has = compare(best.manifest.version, LOCAL.version) > 0;
      this.status = has ? 'available' : 'latest';
      return { ok: true, hasUpdate: has, manifest: best.manifest, via: best.source, attempts: attempts };
    },

    fetchFrom: async function (src, options) {
      if (src === 'github') return await this.checkGithub(options);
      if (src === 'server') return await this.checkServer();
      return await this.checkStatic();
    },

    checkGithub: async function (options) {
      var r = this.repo(options);
      if (!r) throw new Error('还没配置 GitHub 仓库（owner/repo）');
      var url = r.apiBase + '/repos/' + encodeURIComponent(r.owner) + '/' + encodeURIComponent(r.repo) +
        '/releases?per_page=10&t=' + Date.now();
      var res = await fetch(url, {
        cache: 'no-store',
        headers: { Accept: 'application/vnd.github+json' }
      });
      if (res.status === 404) throw new Error('仓库不存在，或还没有发布过 Release');
      if (res.status === 403 || res.status === 429) throw new Error('GitHub 接口限流了，过几分钟再试');
      if (!res.ok) throw new Error('GitHub 返回 HTTP ' + res.status);

      var list = await res.json();
      if (!Array.isArray(list) || list.length === 0) return null;

      var wantBeta = CFG.channel === 'beta';
      var picked = null;
      for (var i = 0; i < list.length; i++) {
        var rel = list[i];
        if (!rel || rel.draft) continue;
        if (!wantBeta && rel.prerelease) continue;
        picked = rel;
        break;
      }
      if (!picked) return null;

      var version = String(picked.tag_name || picked.name || '').replace(/^v/i, '').trim();
      if (!version) throw new Error('Release 没有版本号（tag 不能为空）');

      var pattern = new RegExp(CFG.github && CFG.github.assetPattern ? CFG.github.assetPattern : '.*\\.zip', 'i');
      var assets = (picked.assets || []).filter(function (a) { return pattern.test(a.name || '') && /\.zip$/i.test(a.name || ''); });
      if (!assets.length) {
        assets = (picked.assets || []).filter(function (a) { return /\.zip$/i.test(a.name || ''); });
      }
      var asset = assets[0] || null;
      if (!asset) throw new Error('这个 Release 没有上传 zip 附件');

      var sha = '';
      if (asset.digest && /^sha256:/i.test(asset.digest)) sha = asset.digest.split(':')[1];

      return {
        version: version,
        tag: picked.tag_name,
        channel: picked.prerelease ? 'beta' : 'stable',
        publishedAt: picked.published_at || picked.created_at || '',
        notes: picked.body || '',
        downloadUrl: asset.browser_download_url,
        assetName: asset.name,
        size: asset.size || 0,
        sha256: sha,
        htmlUrl: picked.html_url || ''
      };
    },

    checkStatic: async function () {
      var base = this.staticBase();
      if (!base) throw new Error('还没配置更新地址');
      var p = String((CFG.static && CFG.static.manifestPath) || 'manifest.json').replace(/^\/+/, '');
      var url = base + '/' + p + '?t=' + Date.now();
      var res = await fetch(url, { cache: 'no-store', headers: { Accept: 'application/json' } });
      if (!res.ok) {
        if (res.status === 404) throw new Error('更新清单不存在（404），检查上传目录里有没有 ' + p);
        throw new Error('更新清单返回 HTTP ' + res.status);
      }
      var m = await res.json();
      if (!m || !m.version) throw new Error('更新清单缺少 version 字段');
      var dl = String(m.downloadUrl || '').trim();
      if (!dl) throw new Error('更新清单缺少 downloadUrl 字段');
      if (!/^https?:\/\//i.test(dl)) {
        // 相对路径按清单所在目录解析，换 CDN 域名不用改清单
        dl = base + '/' + dl.replace(/^\.?\//, '');
      }
      return Object.assign({}, m, {
        downloadUrl: dl,
        channel: m.channel || CFG.channel,
        publishedAt: m.publishedAt || m.published_at || '',
        size: m.size || 0,
        sha256: m.sha256 || ''
      });
    },

    checkServer: async function () {
      var url = this.url(CFG.manifestPath) + '?channel=' + encodeURIComponent(CFG.channel) + '&t=' + Date.now();
      var res = await fetch(url, { cache: 'no-store', headers: { Accept: 'application/json' } });
      if (!res.ok) {
        var body = '';
        try { body = await res.text(); } catch (e) { }
        throw new Error('HTTP ' + res.status + (body ? '：' + body.slice(0, 160) : ''));
      }
      var m = await res.json();
      if (!m || !m.version) throw new Error('清单缺少 version 字段');
      return m;
    },

    /**
     * 应用更新
     * GitHub 模式：浏览器只能下载 zip，提示解压覆盖；服务器模式交给启动器。
     * @returns {{ok:boolean, mode?:string, message?:string, url?:string}}
     */
    apply: async function (onProgress) {
      if (!this.enabled()) throw new Error('更新未启用');
      if (!this.manifest) throw new Error('还没有可用的更新清单');
      var m = this.manifest;

      var via = this.via || (this.source() === 'auto' ? 'static' : this.source());
      if (via === 'github' || via === 'static') {
        this.status = 'available';
        if (onProgress) onProgress({ phase: 'download', percent: 100, message: '已开始下载 ' + (m.assetName || 'zip') });
        openDownload(m.downloadUrl);
        return { ok: true, mode: 'download', url: m.downloadUrl, message: '已开始下载' };
      }

      this.status = 'applying';
      try {
        if (onProgress) onProgress({ phase: 'request', percent: 5, message: '正在交给本地启动器…' });
        var res = await fetch(CFG.applyEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            version: m.version,
            downloadUrl: m.downloadUrl,
            sha256: m.sha256,
            channel: CFG.channel
          })
        });

        if (res.status === 404 || res.status === 501) throw new Error('启动器未实现应用接口');

        var data = null;
        try { data = await res.json(); } catch (e) { }
        if (!res.ok) throw new Error((data && (data.error || data.message)) || ('HTTP ' + res.status));

        this.status = 'latest';
        if (onProgress) onProgress({ phase: 'done', percent: 100, message: (data && data.message) || '更新完成，刷新页面后生效' });
        return { ok: true, mode: 'server', data: data };
      } catch (err) {
        if (CFG.fallbackToDownload && m.downloadUrl) {
          openDownload(m.downloadUrl);
          this.status = 'available';
          if (onProgress) onProgress({ phase: 'download', percent: 100, message: '已开始下载，解压覆盖后刷新页面即可' });
          return { ok: true, mode: 'download', url: m.downloadUrl, message: '已开始下载' };
        }
        this.status = 'error';
        this.error = err && err.message ? err.message : String(err);
        throw err;
      }
    },

    describe: function () {
      var map = {
        idle: ['', ''],
        disabled: ['', this.source() === 'github' ? '还没配置 GitHub 仓库'
          : this.source() === 'server' ? '更新服务未启用' : '还没配置更新地址'],
        checking: ['', '正在检查…'],
        latest: ['ok', '已是最新版本'],
        available: ['ok', '发现新版本 v' + (this.manifest ? this.manifest.version : '')],
        applying: ['', '正在更新…'],
        error: ['err', '检查失败：' + (this.error || '未知原因')]
      };
      var item = map[this.status] || map.idle;
      return { kind: item[0], text: item[1] };
    }
  };

  Updater.compare = compare;
  global.ChatUpdater = Updater;
})(window);
