# Chat v0.3.2 — 更顺手的本地大模型对话前端

> 基于 `chat-demo-v0.1.3` 重写。原包只有编译后的压缩产物（`main.*.js` 477KB / `index.html`），没有源码，无法在其上继续加功能，所以按原版风格重做成可维护的源码工程，并补上「一键接入 Ollama、深度思考开关、模型切换」。
>
> v0.3 在 v0.2 上继续打磨：回复**打字机效果**、界面细节优化、可发布版本号，以及一套**自更新模板**（更新服务器由你自己接，默认带遮罩不可点）。
>
> v0.3.1 把**设置面板拆成分栏导航**（普通设置 / 个性化 / API 设置 / 更新 / 关于），新增消息字号、打字机速度、默认深度思考与「关于」页。
>
> v0.3.2 把「深度思考」开关升级成**五档思考等级滑条**（关闭 / 低 / 中 / 高 / 最高，真正下发到 Ollama 的 `think` 档位），并把自更新从模板做成**真能用**：GitHub Releases 优先、Cloudflare 静态清单兜底，一个不通自动换另一个。

![浅色](docs/preview-light.png)

![深色](docs/preview-dark.png)

## 三步用起来

1. 双击 **`启动.bat`**（macOS 用 `启动.command`）。
2. 浏览器自动打开 `http://127.0.0.1:8787`。
3. 首次进入自动探测 Ollama，直接选好本地模型就能聊。

启动脚本会做四件事：

- 起一个本地静态服务 + 转发服务（`server.js`，无 Node 时回退 `server.py`）
- 检测 Ollama；**没在运行就自动 `ollama serve`**
- 用 `/ollama/*` 把请求转发到 `127.0.0.1:11434`，**彻底绕开浏览器跨域 / 私有网络限制**
- 自动打开浏览器

> 直接双击 `index.html` 也能打开，但浏览器会对 `file://` → `localhost` 的请求做跨域拦截，此时页面会提示你改用启动脚本。

## v0.3.2 新增什么

| 能力 | 说明 |
| --- | --- |
| **思考等级滑条** | 普通设置里五档：关闭 / 低 / 中 / 高 / 最高。轨道按档位连续渐变（蓝 `#3f8cff` → 靛 `#7c6cf6` → 紫 `#a855f7`），过 1/3 后叠加星云与星尘，档位名按能量着色，关闭档保持灰色。支持拖动与方向键 / Home / End |
| **真正下发档位** | Ollama 的 `think` 直接收 `low/medium/high/max`（老版本或模型不认档位时自动退回 `true`，不会把思考关掉）；OpenAI 兼容接口用 `reasoning_effort`，最高档发 `xhigh`，被 400 拒绝会自动去参数重试 |
| **输入区联动** | 输入框「深度思考」开关与滑条同一份状态：关掉记住最后一档，再打开恢复；生成时按当前档位请求 |
| **双源自动更新** | 先查 GitHub Releases，拿不到再查 Cloudflare 静态清单，哪个通用哪个；只查一个能用的就停，不多发请求。检查结果里带版本、说明、大小、sha256，下载后解压覆盖即可 |

### v0.3.1 新增什么

| 能力 | 说明 |
| --- | --- |
| **设置改成分栏导航** | 设置弹窗左侧竖排五个分组，右侧独立面板，不再是一个长滚动页。切分组不再重排表单，改完即存 |
| **普通设置** | 对话行为集中在这里：系统提示词、温度、上下文条数、流式输出，以及新增的「**默认开启深度思考**」（下次新对话按此初始状态） |
| **个性化** | 主题（浅色 / 深色 / 跟随系统）、**消息字号**（紧凑 / 标准 / 较大，只影响回答正文）、**打字机速度**（标准 / 快速 / 关闭；关闭时直接整段出现） |
| **API 设置** | 服务商切换 + 各服务商地址与密钥，从侧栏连接状态、模型浮层「添加更多模型」点进来会直接落到这里 |
| **更新** | 原「版本与更新」整段迁入；自更新未接入时导航项右侧有小圆点提示 |
| **关于** | Logo、版本徽章、版本 / 构建 / 通道 / 许可四宫格、数据存放位置、能力范围、快捷键、相关文件，以及「复制版本信息」按钮 |
| 版本入口联动 | 左上角版本号点开直接落「更新」，设置按钮恢复上次停留的分组 |

### v0.3 及以前

| 能力 | 说明 |
| --- | --- |
| **打字机效果** | 回复按字符逐步显现（约 26ms 一帧，按积压长度自适应步长），带闪烁光标；流结束后自动加速追平，追平才去掉光标并整块重排 Markdown。系统开启「减少动态效果」时自动关闭，直接整段显示。正文始终保存完整文本，打字只是显示层，复制/导出/刷新都不受影响 |
| **界面优化** | 会话列表按「今天 / 昨天 / 更早」分组，当前会话左侧加色条；生成中实时显示耗时、结束后显示 `用时 x.xs · tok/s`；版本号可点开设置；代码块、标题、列表排版收紧，圆角/描边/过渡统一 |
| **可发布版本** | 版本号集中在 `assets/version.js`（页面、设置面板、启动器 `/api/health` 三处一致），补了 favicon 与 `description`，方便挂到自己的站点或打包分发 |
| **自更新模板** | 前端、启动器接口、协议文档全部写好，默认 `enabled: false`：设置里「版本与更新」盖一层遮罩，按钮禁用，不会产生半成品行为 |
| 一键接入 Ollama | 自动按 `页面代理 → 已存地址 → 127.0.0.1:11434 → localhost:11434` 依次探测，成功后载入全部本地模型并选好默认模型 |
| 深度思考一键开关 | 输入框左侧常驻开关，`Ctrl/Cmd+Shift+D` 也能切；思考过程以可折叠块实时流式展示，结束自动收起 |
| 模型随时切换 | 模型胶囊 → 浮层支持搜索、刷新、能力标签（思考 / 视觉 / 参数量 / 体积），点一下立即生效 |
| 三种服务商 | Ollama 本地、DeepSeek 官方、任意 OpenAI 兼容接口（vLLM / LM Studio / One API / 中转站） |
| Markdown 渲染 | 标题、表格、列表、引用、链接、代码高亮（js/ts/py/json/bash/sql/html/css）+ 一键复制代码 |
| 会话管理 | 侧边栏历史、自动标题、预览、删除、导出 Markdown |
| 消息操作 | 复制、重新生成、编辑用户消息并重发、删除 |
| 流式体验 | 停止生成（保留已生成内容）、自动贴底、手动上滑后不打断阅读、回到底部按钮 |

### 快捷键

| 快捷键 | 作用 |
| --- | --- |
| `Enter` / `Shift+Enter` | 发送 / 换行 |
| `Ctrl/Cmd+N` | 新建对话 |
| `Ctrl/Cmd+K` | 聚焦输入框 |
| `Ctrl/Cmd+Shift+D` | 开关深度思考 |
| `Ctrl/Cmd+B` | 收起 / 展开侧边栏 |
| `Esc` | 关闭更新弹窗 / 设置 / 浮层，或停止生成 |

## 自动更新（GitHub 优先，Cloudflare 兜底）

```
浏览器 ──① api.github.com/repos/<owner>/<repo>/releases──▶ 有 zip 附件就用它
        └─② 失败 / 还没发 Release ──▶ <static.base>/manifest.json ──▶ 用清单里的 zip
```

- 版本号：`assets/version.js` → `CHAT_VERSION = { version: '0.3.2', build: '2026-11-21', channel: 'stable' }`
- 配置：`assets/update-config.js`
  - `source: 'auto'`、`sources: ['github', 'static']`：按顺序试，拿到一个能用的清单就停（省流量）
  - `github.owner` / `github.repo`：`qwertyui-asdfghjkl-zxcvbnm` / `chat`
  - `static.base`：Cloudflare Pages 地址（默认 `https://chat.deepseek-coder.kdns.fr`，以你实际部署的域名为准）
- 逻辑：`assets/updater.js` → `ChatUpdater.check()`（版本比较、挑 zip、解析 sha256、下载）
- 清单格式：**[`docs/update-protocol.md`](docs/update-protocol.md)**

发布一个版本（两条路，任选其一即可，建议都做）：

**A. Cloudflare Pages（国内快，主用）**

1. 把 `cloudflare/` 目录整个上传成一个 Pages 项目（项目名建议 `chat-demo`）；
2. 目录里就两样东西：`manifest.json` + `chat-demo-v0.3.2.zip`；
3. 发新版时改 `manifest.json` 的 `version` / `downloadUrl` / `sha256` / `size`，连同新 zip 一起重新上传（Pages 支持覆盖部署）。

**B. GitHub Releases（备份 / 源码归档）**

1. 在仓库 `Releases → Draft a new release`；
2. Tag 写 `v0.3.2`，把 `chat-demo-v0.3.2.zip` 拖进附件；
3. 发布即可，前端会自己挑 `chat-demo-*.zip`。

现在的行为：

- 设置「更新」分组能看到当前版本 / build / 通道和双源地址；
- 点「检查更新」→ 有新版弹出对比弹窗（版本、说明、大小、sha256），点「下载新版本」直接下 zip；
- 两个源都连不上时，弹窗里会分别写出 GitHub 和 Cloudflare 的错误，不会只剩一句「检查失败」。

![更新面板](docs/preview-update.png)

> 设计取舍：浏览器没有权限替换程序文件，所以下载 / `sha256` 校验 / 备份 / 替换都交给本地启动器；启动器没实现 apply 时，前端会退化为浏览器直接下载 zip，手动解压覆盖即可。

## 思考等级在各服务商上的行为

- **Ollama**：`think` 支持布尔也支持档位，请求体按选中的档位发 `low / medium / high / max`（关闭时发 `false`）。模型或服务端不认档位、返回 `invalid think value` 时，自动改成 `think: true` 重试一次，思考不会丢。思考内容从 `message.thinking` 流式返回。
- **Ollama 模型不支持思考**：服务端返回 400 时自动去掉 `think` 重试一次，不会卡住对话；模型胶囊上会标注是否声明了 `thinking` 能力。
- **DeepSeek**：`deepseek-reasoner` 天然输出 `reasoning_content`；用 `deepseek-chat` 时按开关尝试 `thinking: {type: enabled}`（只有开 / 关，档位不起作用，界面会写明）。
- **其他 OpenAI 兼容接口**：`reasoning_effort` 用 `low / medium / high`，最高档发 `xhigh`；被拒绝（400）会自动去参数重试。
- 思考内容只用于展示，不进入后续上下文。

## 模型默认选择策略

自动选模型时按「**优先支持思考 + 体积最小**」排序。大模型首次加载会吃掉大量内存/显存：

- `qwen3_0.6b:latest`（0.55GB）→ 默认首选
- `dsqwen3.5-9b:latest`（7.6GB）、`qwen3.6:latest`（14.5GB）→ 需要足够内存才能跑，列表里标了体积，按需手动切换

## 文件结构

```
chat-demo-v0.2.0/
├─ index.html            页面骨架
├─ assets/
│  ├─ app.css            全部样式（浅色 / 深色 / 移动端）
│  ├─ app.js             界面与交互（发送、流式、打字机、浮层、设置、快捷键）
│  ├─ providers.js       服务适配层（Ollama / OpenAI 兼容 + 降级重试）
│  ├─ md.js              零依赖 Markdown 渲染 + 代码高亮
│  ├─ store.js           状态与 localStorage 持久化
│  ├─ version.js         版本号（发布时改这里）
│  ├─ update-config.js   更新来源（GitHub / Cloudflare / 自建服务）
│  └─ updater.js         更新检查与下载（ChatUpdater）
├─ cloudflare/           Cloudflare Pages 上传目录（manifest.json + zip）
├─ server.js             启动器：静态服务 + /ollama 转发 + /proxy + /api/update
├─ server.py             同上，Python 标准库版（无 Node 时使用）
├─ 启动.bat / 启动.command
├─ docs/
│  ├─ update-protocol.md     更新清单 / 双源契约
│  └─ preview-*.png          预览截图
├─ tests/                冒烟 / 代理 / 界面链路测试
└─ README.md
```

## 设置面板

![设置 · 普通设置](docs/preview-settings.png)

设置弹窗左侧五个分组，点一下切面板：

- **普通设置**：对话行为——系统提示词、温度（0–1.5）、上下文条数（0 = 全部）、流式输出，以及**思考等级五档滑条**（关闭 / 低 / 中 / 高 / 最高，下面有按服务商变化的说明）。
- **个性化**：主题（浅色 / 深色 / 跟随系统）、消息字号（紧凑 / 标准 / 较大）、打字机速度（标准 / 快速 / 关闭）。
- **API 设置**：Ollama / DeepSeek / OpenAI 兼容，配置各自独立保存；Ollama 地址可改（默认 `http://127.0.0.1:11434`），「一键连接」重新探测，模型 chips 点一下即切换。
- **更新**：当前版本、build、通道，双源地址与「检查更新」入口。
- **关于**：版本信息四宫格、数据存放位置、能力范围、快捷键、相关文件、复制版本信息。

分组会记住上次停留的位置；左上角版本号直接跳「更新」，侧栏连接状态和模型浮层「添加更多模型」直接跳「API 设置」。

配置和对话都存在浏览器 `localStorage`（键名 `chat-demo.v0.2`），不上传任何服务器。

![设置 · 关于](docs/preview-about.png)

## 常见问题

| 现象 | 处理 |
| --- | --- |
| 提示「连不上模型服务」 | 先确认 `ollama --version` 可用，再执行 `ollama serve`；或直接用 `启动.bat` 打开 |
| 提示跨域 / `Failed to fetch` | 你可能是双击 `index.html` 打开的，改用启动脚本；或设置 `$env:OLLAMA_ORIGINS="*"` 后重启 `ollama serve` |
| 连上但模型列表为空 | 终端执行 `ollama list`，没有模型就先 `ollama pull qwen3:0.6b` |
| DeepSeek 返回 401 | API Key 无效，设置里重新填 |
| 端口被占用 | 启动器会自动顺延端口（8787 → 8788 …）；也可 `node server.js --port 8899` |
| 点「检查更新」提示两个源都连不上 | 国内 GitHub 偶尔抽风、Cloudflare 也可能没部署好；弹窗里会分别写原因。先确认 Pages 上 `manifest.json` 能直接打开，或给仓库发一个 Release |
| 27B 模型很慢 / 内存报警 | 换成小模型，模型列表里标着体积 |

## 自测

```bash
# 适配层 + Markdown + 存储（模拟服务，约 1 秒）
node tests/smoke.js

# 再加一轮真实 Ollama 推理（用最小的模型，别用大家伙）
node tests/smoke.js --real

# 更新检查：GitHub / Cloudflare / 双源切换（14 项，纯离线）
node tests/update.js

# 启动器：静态服务 / Ollama 转发 / 流式不被缓冲 / 通用转发 / 更新接口 501
node server.js --no-open --port 8792 &
node tests/proxy.js 8792

# 界面链路：jsdom 驱动真实点击 + 真实推理 + 设置分栏 / 思考等级 / 双源更新断言（22 项）
npm i jsdom --prefix %TEMP%\jsdomtest
set NODE_PATH=%TEMP%\jsdomtest\node_modules
node tests/ui.js http://127.0.0.1:8792/ qwen3_0.6b:latest
```

已验证：Markdown 渲染与注入拦截、NDJSON/SSE 流式、思考等级按 low/max 真正下发、模型不认档位时降级为布尔、不支持思考时降级、中止生成、模型列表、模型切换、重新生成、localStorage 持久化、启动器流式转发（首段 92–203ms）、更新接口在未配置时返回 501、GitHub 无 Release 时自动切 Cloudflare 且不再多发请求、双源都挂时分别报错、设置五个分组与默认分组、分组切换、字号与打字机速度落盘并生效、版本号入口直达「更新」。

## 说明

- `server.js` / `server.py` 只监听 `127.0.0.1`，转发服务仅本机可用。
- `/proxy?url=` 只转发 `http(s)` 地址，是为浏览器跨域兜底用的，不需要可以不管。
- API Key 存在浏览器本地，公共电脑上请用完清理。
- 更新只读公开清单：GitHub 走公开 Releases 接口，Cloudflare 读 `manifest.json`，不登录、不携带任何本地数据。
- 本项目为独立重写实现，遵循 MIT 许可。

