#!/bin/bash
cd "$(dirname "$0")" || exit 1
if command -v node >/dev/null 2>&1; then
  exec node server.js "$@"
fi
if command -v python3 >/dev/null 2>&1; then
  exec python3 server.py "$@"
fi
echo "需要 Node.js 或 Python3，装好再运行本脚本。"
read -r -p "按回车退出"
