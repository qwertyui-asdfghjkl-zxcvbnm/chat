/* =========================================================================
 * tests/smoke.js — 零依赖冒烟测试
 *   node tests/smoke.js            仅跑模拟服务
 *   node tests/smoke.js --real     额外连本机真实 Ollama 跑一轮推理
 * ========================================================================= */
'use strict';

const assert = require('assert');
const http = require('http');
const ChatMD = require('../assets/md.js');
const ChatProviders = require('../assets/providers.js');
const Store = require('../assets/store.js');

let passed = 0;
function ok(name) { passed++; console.log('  ✓ ' + name); }

/* ------------------------------ 1. Markdown ------------------------------ */

function testMarkdown() {
  const html = ChatMD.render([
    '# 标题',
    '',
    '一段**加粗**、`代码`、[链接](https://example.com) 和 ~~删除~~。',
    '',
    '- 第一项',
    '- 第二项',
    '  - 子项',
    '',
    '| 列A | 列B |',
    '| --- | :-: |',
    '| 1 | 2 |',
    '',
    '> 引用一行',
    '',
    '```python',
    'def hello(name):',
    '    return "hi " + name',
    '```',
    ''
  ].join('\n'));

  assert(html.includes('<h1 class="md-h">标题</h1>'), 'heading');
  assert(html.includes('<strong>加粗</strong>'), 'bold');
  assert(html.includes('<code>代码</code>'), 'inline code');
  assert(html.includes('<a href="https://example.com"'), 'link');
  assert(html.includes('<del>删除</del>'), 'strike');
  assert(html.includes('<li>第一项</li>'), 'list');
  assert(html.includes('<ol>') === false && html.includes('<ul>'), 'ul only');
  assert(html.includes('<table>'), 'table');
  assert(html.includes('text-align:center'), 'table align');
  assert(html.includes('<blockquote>'), 'quote');
  assert(html.includes('class="code-block"'), 'code block');
  assert(html.includes('tok-kw'), 'highlight keyword');
  ok('Markdown：标题/强调/列表/表格/引用/代码高亮');

  const xss = ChatMD.render('<img src=x onerror=alert(1)> [点我](javascript:alert(1))');
  assert(xss.indexOf('<img src=x') < 0, 'raw html escaped');
  assert(xss.indexOf('javascript:alert') < 0 || xss.indexOf('href="javascript') < 0, 'js url blocked');
  ok('Markdown：HTML 注入与 javascript: 链接被拦截');

  const fence = ChatMD.render('```js\nconst a = "<b>";\n```');
  assert(fence.includes('&lt;b&gt;'), 'code escaped');
  ok('Markdown：代码块内的 HTML 被转义');
}

/* ------------------------------ 2. Store ------------------------------ */

function testStore() {
  const s = Store.load();
  assert(s.conversations.length === 0, 'empty conversations');
  const conv = Store.createConversation();
  const msg = Store.newMessage('user', '帮我把这段需求拆成任务');
  Store.appendMessage(conv, msg);
  assert.equal(conv.title, '帮我把这段需求拆成任务');
  assert.equal(Store.current().id, conv.id);
  const long = Store.autoTitle('一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十超出长度');
  assert(long.endsWith('…'), 'long title truncated');
  ok('Store：对话创建/自动标题/当前会话');
}

/* ------------------------------ 3. 模拟 Ollama ------------------------------ */

function startMock(port) {
  const seen = [];
  const srv = http.createServer((req, res) => {
    let body = '';
    req.on('data', (d) => { body += d; });
    req.on('end', () => {
      const url = req.url.split('?')[0];
      if (url === '/api/tags') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({
          models: [
            { name: 'mock-9b', size: 7e9, details: { parameter_size: '9.2B', quantization_level: 'Q4_K_M' }, capabilities: ['completion', 'tools', 'thinking'] },
            { name: 'mock-small', size: 5e8, details: { parameter_size: '0.7B' }, capabilities: ['completion'] },
            { name: 'no-think-model', size: 1e9, details: {}, capabilities: ['completion'] }
          ]
        }));
      }
      if (url === '/api/chat') {
        const parsed = JSON.parse(body || '{}');
        seen.push(parsed);
        if (parsed.model === 'no-think-model' && parsed.think === true) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: 'model "no-think-model" does not support thinking' }));
        }
        res.writeHead(200, { 'Content-Type': 'application/x-ndjson' });
        const thinkParts = ['先看一下', '这道题的关键。'];
        const contentParts = ['答案：', '42。'];
        let i = 0;
        const timer = setInterval(() => {
          if (parsed.think === true && i < thinkParts.length) {
            res.write(JSON.stringify({ message: { role: 'assistant', thinking: thinkParts[i] }, done: false }) + '\n');
          } else {
            const k = i - (parsed.think === true ? thinkParts.length : 0);
            if (k < contentParts.length) {
              res.write(JSON.stringify({ message: { role: 'assistant', content: contentParts[k] }, done: false }) + '\n');
            } else {
              res.write(JSON.stringify({ done: true, prompt_eval_count: 12, eval_count: 20, total_duration: 3e9 }) + '\n');
              clearInterval(timer);
              res.end();
            }
          }
          i++;
        }, 12);
        return;
      }
      if (url === '/v1/models') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ data: [{ id: 'gpt-mock' }] }));
      }
      if (url === '/v1/chat/completions') {
        const parsed = JSON.parse(body || '{}');
        seen.push(parsed);
        if (parsed.reasoning_effort && parsed.model === 'gpt-mock') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: { message: 'Unrecognized request argument supplied: reasoning_effort' } }));
        }
        res.writeHead(200, { 'Content-Type': 'text/event-stream' });
        const chunks = [
          { choices: [{ delta: { reasoning_content: '嗯…' } }] },
          { choices: [{ delta: { content: '你好' } }] },
          { choices: [{ delta: { content: '，世界' } }], usage: { prompt_tokens: 9, completion_tokens: 3 } },
          '[DONE]'
        ];
        let i = 0;
        const timer = setInterval(() => {
          if (i >= chunks.length) { clearInterval(timer); return res.end(); }
          const c = chunks[i];
          res.write('data: ' + (typeof c === 'string' ? c : JSON.stringify(c)) + '\n\n');
          i++;
        }, 10);
        return;
      }
      res.writeHead(404);
      res.end('{}');
    });
  });
  return new Promise((resolve) => srv.listen(port, '127.0.0.1', () => resolve({ srv, seen })));
}

async function testProvidersMock() {
  // 交给系统分配空闲端口，避免和本机其他服务（8899 常被占用）冲突
  const { srv, seen } = await startMock(0);
  const base = 'http://127.0.0.1:' + srv.address().port;

  const models = await ChatProviders.listModels('ollama', { base });
  assert.equal(models.length, 3, '3 models');
  assert.equal(models[0].name, 'mock-9b', 'sorted by name');
  assert.equal(models[0].paramSize, '9.2B');
  const names = models.map((m) => m.name).sort();
  assert.deepEqual(names, ['mock-9b', 'mock-small', 'no-think-model']);
  ok('Ollama：模型列表 /api/tags');

  const events = [];
  const r1 = await ChatProviders.chat({
    provider: 'ollama', base, model: 'mock-9b', messages: [{ role: 'user', content: '6*7=?' }],
    temperature: 0.7, deepThink: true, stream: true, signal: new AbortController().signal,
    onThinking: (t) => events.push('think:' + t),
    onContent: (t) => events.push('text:' + t)
  });
  assert.equal(r1.content, '答案：42。');
  assert.equal(r1.thinking, '先看一下这道题的关键。');
  assert.equal(events[0], 'think:先看一下');
  assert(events.some((e) => e.startsWith('text:')));
  assert.equal(seen[seen.length - 1].think, true, 'think 参数下发');
  assert.equal(seen[seen.length - 1].options.temperature, 0.7);
  assert(r1.usage && r1.usage.completion === 20);
  ok('Ollama：NDJSON 流式 + 思考内容 + 参数下发');

  const events2 = [];
  const r2 = await ChatProviders.chat({
    provider: 'ollama', base, model: 'no-think-model', messages: [{ role: 'user', content: 'hi' }],
    deepThink: true, stream: true, signal: new AbortController().signal,
    onContent: (t) => events2.push(t)
  });
  assert.equal(r2.content, '答案：42。');
  assert.equal(seen[seen.length - 1].think, undefined, '降级后不再带 think 参数');
  ok('Ollama：不支持 thinking 时自动降级重试');

  const events3 = [];
  const r3 = await ChatProviders.chat({
    provider: 'custom', base: base + '/v1', model: 'gpt-mock', messages: [{ role: 'user', content: 'hi' }],
    deepThink: true, stream: true, signal: new AbortController().signal,
    onThinking: (t) => events3.push('think:' + t),
    onContent: (t) => events3.push('text:' + t)
  });
  assert.equal(r3.content, '你好，世界');
  assert.equal(r3.thinking, '嗯…');
  assert.equal(seen[seen.length - 1].reasoning_effort, undefined, '400 后去掉 reasoning_effort');
  ok('OpenAI 兼容：SSE 流 + reasoning_content + 400 自动降级');

  const abortCtrl = new AbortController();
  const pending = ChatProviders.chat({
    provider: 'ollama', base, model: 'mock-small', messages: [{ role: 'user', content: 'x' }],
    stream: true, signal: abortCtrl.signal, onContent: () => abortCtrl.abort()
  });
  await pending.catch((e) => { assert(e.name === 'AbortError' || e.kind === 'aborted', 'abort 错误类型'); });
  ok('中止生成：抛出 AbortError');

  srv.close();
}

/* ------------------------------ 4. 真实 Ollama ------------------------------ */

async function testRealOllama() {
  const base = 'http://127.0.0.1:11434';
  let models;
  try {
    models = await ChatProviders.listModels('ollama', { base: base }, { timeout: 6000 });
  } catch (e) {
    console.log('  ! 真实 Ollama 未运行，跳过（' + e.message + '）');
    return;
  }
  console.log('  · 本机模型：' + models.map((m) => m.name + (m.caps.includes('thinking') ? '(思考)' : '')).join(', '));
  const target = models.find((m) => m.size && m.size < 1e9) || models[0];
  if (!target) { console.log('  ! 没有可用模型，跳过'); return; }

  const t0 = Date.now();
  const r = await ChatProviders.chat({
    provider: 'ollama', base, model: target.name,
    messages: [{ role: 'user', content: '只回答两个字：你好' }],
    temperature: 0.2, deepThink: false, stream: true,
    signal: new AbortController().signal
  });
  assert(r.content.trim().length > 0, '真实模型返回非空');
  console.log('  · ' + target.name + ' 回复：' + JSON.stringify(r.content.slice(0, 60)) + ' (' + (Date.now() - t0) + 'ms, ' + (r.usage && r.usage.completion) + ' tokens)');
  ok('真实 Ollama：流式推理成功');

  const t1 = Date.now();
  const rt = await ChatProviders.chat({
    provider: 'ollama', base, model: target.name,
    messages: [{ role: 'user', content: '9.11 和 9.9 哪个大？只给结论。' }],
    temperature: 0.2, deepThink: true, stream: true,
    signal: new AbortController().signal
  });
  assert(rt.content.trim().length > 0, '深度思考模式有回复');
  console.log('  · 深度思考：thinking ' + (rt.thinking ? rt.thinking.length + ' 字' : '无') +
    ' / answer ' + JSON.stringify(rt.content.slice(0, 50)) + ' (' + (Date.now() - t1) + 'ms)');
  ok('真实 Ollama：深度思考开关生效');
}

/* ------------------------------ 运行 ------------------------------ */

(async () => {
  console.log('\n[1/4] Markdown 渲染');
  testMarkdown();
  console.log('[2/4] 状态存储');
  testStore();
  console.log('[3/4] 适配层（模拟服务）');
  await testProvidersMock();
  if (process.argv.includes('--real')) {
    console.log('[4/4] 真实 Ollama');
    await testRealOllama();
  } else {
    console.log('[4/4] 真实 Ollama  → 加 --real 参数运行');
  }
  console.log('\n全部通过：' + passed + ' 项\n');
})().catch((e) => {
  console.error('\n✗ 测试失败：', e && e.message);
  console.error(e && e.stack);
  process.exit(1);
});
