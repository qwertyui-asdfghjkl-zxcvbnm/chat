/* =========================================================================
 * update-config.js — 自更新开关（模板）
 *
 * 默认 enabled:false：设置里的「版本与更新」会盖一层遮罩，按钮不可点。
 * 自建更新服务器就绪后，把 enabled 改成 true 即可启用，无需改其它代码。
 *
 * 服务端契约见 docs/update-protocol.md
 * ========================================================================= */
window.CHAT_UPDATE = {
  enabled: false,

  // 前端请求的基地址。默认走本地启动器：/api/update
  // 启动器会用 --update-server 或环境变量 UPDATE_SERVER 转发到你的更新服务器。
  endpoint: '/api/update',

  // 版本通道，会作为 ?channel= 传给更新服务器
  channel: 'stable',

  // 清单地址（相对 endpoint）
  manifestPath: '/manifest.json',

  // 让本地启动器执行下载/校验/替换（推荐，浏览器自己做不了文件替换）
  applyEndpoint: '/api/update/apply',

  // 失败时的兜底：直接在浏览器下载 zip
  fallbackToDownload: true
};
