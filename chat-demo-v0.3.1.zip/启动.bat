@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Chat v0.2

where node >nul 2>nul
if not errorlevel 1 (
  echo   Starting local server with Node.js ...
  node server.js %*
  goto done
)

where python >nul 2>nul
if not errorlevel 1 (
  echo   Starting local server with Python ...
  python server.py %*
  goto done
)

where py >nul 2>nul
if not errorlevel 1 (
  echo   Starting local server with Python launcher ...
  py -3 server.py %*
  goto done
)

echo.
echo   Node.js or Python is required to start the local server.
echo   Install Node.js: https://nodejs.org
echo   Or open index.html directly (Ollama may be blocked by CORS).
echo.

:done
echo.
pause
