/* =========================================================================
 * updater.js — 更新检查 / 应用（模板实现）
 *
 * 设计原则：
 *  1) 浏览器不碰文件系统，真正的下载、sha256 校验、备份、替换交给本地启动器
 *  2) 启动器没接更新服务器时，前端只做「检查 + 提示」，不产生任何副作用
 *  3) enabled=false 时所有入口都不可点击（设置页用遮罩挡住）
 * ========================================================================= */
(function (global) {
  'use strict';

  var CFG = Object.assign({
    enabled: false,
    endpoint: '/api/update',
    channel: 'stable',
    manifestPath: '/manifest.json',
    applyEndpoint: '/api/update/apply',
    fallbackToDownload: true
  }, global.CHAT_UPDATE || {});

  var LOCAL = global.CHAT_VERSION || { name: 'chat-demo', version: '0.0.0', build: '' };

  function parse(v) {
    return String(v || '0').replace(/^v/i, '').split(/[.\-+]/).map(function (s) {
      var n = parseInt(s, 10);
      return isNaN(n) ? 0 : n;
    });
  }

  function compare(a, b) {
    var pa = parse(a), pb = parse(b);
    var len = Math.max(pa.length, pb.length);
    for (var i = 0; i < len; i++) {
      var x = pa[i] || 0, y = pb[i] || 0;
      if (x > y) return 1;
      if (x < y) return -1;
    }
    return 0;
  }

  var Updater = {
    config: CFG,
    local: LOCAL,
    status: 'idle',        // idle | checking | latest | available | applying | error | disabled
    manifest: null,
    error: null,

    enabled: function () { return !!CFG.enabled; },

    url: function (path) {
      return String(CFG.endpoint || '').replace(/\/+$/, '') + path;
    },

    /**
     * 检查更新
     * @returns {{ok:boolean, hasUpdate:boolean, manifest?:object, error?:string}}
     */
    check: async function (options) {
      options = options || {};
      if (!CFG.enabled) {
        this.status = 'disabled';
        return { ok: false, hasUpdate: false, error: '更新服务未启用（模板）' };
      }
      this.status = 'checking';
      this.error = null;
      try {
        var url = this.url(CFG.manifestPath) + '?channel=' + encodeURIComponent(CFG.channel) + '&t=' + Date.now();
        var res = await fetch(url, { cache: 'no-store', headers: { Accept: 'application/json' } });
        if (!res.ok) {
          var body = '';
          try { body = await res.text(); } catch (e) { }
          throw new Error('HTTP ' + res.status + (body ? '：' + body.slice(0, 160) : ''));
        }
        var m = await res.json();
        if (!m || !m.version) throw new Error('清单缺少 version 字段');
        this.manifest = m;
        this.status = compare(m.version, LOCAL.version) > 0 ? 'available' : 'latest';
        return { ok: true, hasUpdate: this.status === 'available', manifest: m };
      } catch (err) {
        this.status = 'error';
        this.error = err && err.message ? err.message : String(err);
        return { ok: false, hasUpdate: false, error: this.error };
      }
    },

    /**
     * 应用更新
     * 优先让本地启动器执行；失败且允许时退化为浏览器下载。
     * @returns {{ok:boolean, mode?:string, message?:string, url?:string}}
     */
    apply: async function (onProgress) {
      if (!CFG.enabled) throw new Error('更新服务未启用');
      if (!this.manifest) throw new Error('还没有可用的更新清单');
      this.status = 'applying';
      var m = this.manifest;

      try {
        if (onProgress) onProgress({ phase: 'request', percent: 5, message: '正在交给本地启动器…' });
        var res = await fetch(CFG.applyEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            version: m.version,
            downloadUrl: m.downloadUrl,
            sha256: m.sha256,
            channel: CFG.channel
          })
        });

        if (res.status === 404 || res.status === 501) throw new Error('启动器未实现应用接口');

        var data = null;
        try { data = await res.json(); } catch (e) { }
        if (!res.ok) throw new Error((data && (data.error || data.message)) || ('HTTP ' + res.status));

        this.status = 'latest';
        if (onProgress) onProgress({ phase: 'done', percent: 100, message: (data && data.message) || '更新完成，刷新页面后生效' });
        return { ok: true, mode: 'server', data: data };
      } catch (err) {
        // 兜底：浏览器下载
        if (CFG.fallbackToDownload && m.downloadUrl) {
          var a = document.createElement('a');
          a.href = m.downloadUrl;
          a.rel = 'noopener noreferrer';
          a.target = '_blank';
          document.body.appendChild(a);
          a.click();
          setTimeout(function () { a.remove(); }, 300);
          this.status = 'available';
          if (onProgress) onProgress({ phase: 'download', percent: 100, message: '已开始下载，解压覆盖后刷新页面即可' });
          return { ok: true, mode: 'download', url: m.downloadUrl, message: '已开始下载' };
        }
        this.status = 'error';
        this.error = err && err.message ? err.message : String(err);
        throw err;
      }
    },

    describe: function () {
      var map = {
        idle: ['', ''],
        disabled: ['', '更新服务未启用（模板）'],
        checking: ['', '正在检查…'],
        latest: ['ok', '已是最新版本'],
        available: ['ok', '发现新版本 v' + (this.manifest ? this.manifest.version : '')],
        applying: ['', '正在更新…'],
        error: ['err', '检查失败：' + (this.error || '未知原因')]
      };
      var item = map[this.status] || map.idle;
      return { kind: item[0], text: item[1] };
    }
  };

  Updater.compare = compare;
  global.ChatUpdater = Updater;
})(window);
