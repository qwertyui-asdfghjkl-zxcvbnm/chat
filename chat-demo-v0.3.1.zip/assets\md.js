/* =========================================================================
 * md.js — 轻量 Markdown 渲染器（零依赖、离线可用）
 * 先做 HTML 转义再拼装，避免注入；支持代码块高亮 / 表格 / 列表 / 引用。
 * ========================================================================= */
(function (global) {
  'use strict';

  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) { return ESC[c]; });
  }

  function safeUrl(url, allowImage) {
    var u = String(url || '').trim();
    if (/^https?:\/\//i.test(u)) return u;
    if (/^mailto:/i.test(u)) return u;
    if (allowImage && /^data:image\/[a-z0-9.+-]+;base64,/i.test(u)) return u;
    if (/^#/.test(u) || /^\/[^\/]/.test(u)) return u;
    return '';
  }

  /* ------------------------------ 代码高亮 ------------------------------ */

  var LANGS = {
    js: {
      kw: /^(?:const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|class|extends|super|this|try|catch|finally|throw|typeof|instanceof|in|of|async|await|yield|import|export|from|default|delete|void|null|undefined|true|false)\b/,
      re: /\/\/[^\n]*|\/\*[\s\S]*?\*\/|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\]|\\.)*`|\b\d+(?:\.\d+)?\b|\b(?:const|let|var|function|return|if|else|for|while|switch|case|break|continue|new|class|extends|super|this|try|catch|finally|throw|typeof|async|await|import|export|from|default|null|undefined|true|false)\b/g
    },
    ts: {
      kw: /^(?:const|let|var|function|return|if|else|for|while|switch|case|break|continue|new|class|extends|implements|interface|type|enum|namespace|public|private|protected|readonly|async|await|import|export|from|as|null|undefined|true|false|never|unknown|any|string|number|boolean)\b/,
      re: /\/\/[^\n]*|\/\*[\s\S]*?\*\/|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\]|\\.)*`|\b\d+(?:\.\d+)?\b|\b(?:const|let|var|function|return|if|else|for|while|switch|case|break|continue|new|class|extends|implements|interface|type|enum|public|private|protected|readonly|async|await|import|export|from|as|null|undefined|true|false|string|number|boolean)\b/g
    },
    py: {
      kw: /^(?:def|class|return|if|elif|else|for|while|break|continue|import|from|as|with|try|except|finally|raise|lambda|yield|global|nonlocal|assert|pass|del|and|or|not|in|is|None|True|False|async|await)\b/,
      re: /#[^\n]*|"""[\s\S]*?"""|'''[\s\S]*?'''|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|\b\d+(?:\.\d+)?\b|\b(?:def|class|return|if|elif|else|for|while|break|continue|import|from|as|with|try|except|finally|raise|lambda|yield|assert|and|or|not|in|is|None|True|False|async|await|self)\b/g
    },
    json: {
      kw: /^(?:true|false|null)\b/,
      re: /"(?:[^"\\\n]|\\.)*"(?=\s*:)|\btrue\b|\bfalse\b|\bnull\b|-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/g
    },
    bash: {
      kw: /^(?:if|then|else|elif|fi|for|while|do|done|case|esac|function|return|echo|export|local|cd|sudo|source|set|unset|trap|shift)\b/,
      re: /#[^\n]*|"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*|\b\d+\b|\b(?:if|then|else|elif|fi|for|while|do|done|case|esac|function|return|echo|export|local|cd|sudo|source|set|unset)\b/g
    },
    sql: {
      kw: /^(?:select|from|where|insert|update|delete|create|table|alter|drop|join|left|right|inner|outer|on|group|order|by|having|limit|offset|as|and|or|not|null|values|into|set|distinct|union|index|primary|key|foreign|references|default|case|when|then|else|end)\b/i,
      re: /--[^\n]*|\/\*[\s\S]*?\*\/|'(?:[^'\\\n]|\\.)*'|\b\d+(?:\.\d+)?\b|\b(?:select|from|where|insert|update|delete|create|table|join|group|order|by|limit|as|and|or|not|null|values|into|set|distinct|union|primary|key|default)\b/gi
    },
    html: {
      kw: /^<\/?[a-zA-Z][\w:-]*/,
      re: /<!--[\s\S]*?-->|<\/?[a-zA-Z][\w:-]*|\/?>|"[^"\n]*"|'[^'\n]*'/g
    },
    css: {
      kw: /^(?:@media|@import|@keyframes|important)\b/,
      re: /\/*[\s\S]*?\*\/|[.#][\w-]+|@[\w-]+|"[^"\n]*"|'[^'\n]*'|\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms|deg)?\b|\b[a-z-]+(?=\s*:)/g
    }
  };

  function langKey(name) {
    var n = String(name || '').toLowerCase();
    var alias = {
      javascript: 'js', js: 'js', jsx: 'js', mjs: 'js', cjs: 'js',
      typescript: 'ts', ts: 'ts', tsx: 'ts',
      python: 'py', py: 'py', python3: 'py',
      shell: 'bash', sh: 'bash', zsh: 'bash', bash: 'bash', console: 'bash', powershell: 'bash', ps1: 'bash',
      json: 'json', jsonc: 'json',
      sql: 'sql', mysql: 'sql', postgres: 'sql', psql: 'sql',
      html: 'html', xml: 'html', svg: 'html', vue: 'html',
      css: 'css', scss: 'css', less: 'css'
    };
    return alias[n] || (LANGS[n] ? n : '');
  }

  function highlight(code, lang) {
    var key = langKey(lang);
    var def = LANGS[key];
    if (!def) return escapeHtml(code);

    var re = def.re;
    re.lastIndex = 0;
    var out = '';
    var last = 0;
    var m;
    var guard = 0;
    while ((m = re.exec(code)) && guard++ < 50000) {
      if (m[0] === '') { re.lastIndex++; continue; }
      var tok = m[0];
      out += escapeHtml(code.slice(last, m.index));
      var cls;
      if (/^\/\//.test(tok) || /^#/.test(tok) || /^--/.test(tok) || /^<!--/.test(tok) || /^\/\*/.test(tok) || /^"""|^'''/.test(tok)) cls = 'tok-com';
      else if (/^["'`]/.test(tok)) cls = 'tok-str';
      else if (/^\d/.test(tok)) cls = 'tok-num';
      else if (def.kw.test(tok)) cls = 'tok-kw';
      else if (/^\$|^@|^[.#]/.test(tok)) cls = 'tok-var';
      else cls = 'tok-tag';
      out += '<span class="' + cls + '">' + escapeHtml(tok) + '</span>';
      last = m.index + tok.length;
    }
    out += escapeHtml(code.slice(last));
    return out;
  }

  /* ------------------------------ 行内规则 ------------------------------ */

  function inline(text) {
    var stash = [];
    var s = String(text);

    s = s.replace(/``([^`]+)``|`([^`\n]+)`/g, function (_, a, b) {
      stash.push('<code>' + escapeHtml(a || b) + '</code>');
      return '\u0000' + (stash.length - 1) + '\u0000';
    });

    s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g, function (whole, alt, url) {
      var src = safeUrl(url, true);
      if (!src) return whole;
      stash.push('<img src="' + escapeHtml(src) + '" alt="' + escapeHtml(alt) + '" loading="lazy">');
      return '\u0000' + (stash.length - 1) + '\u0000';
    });

    s = s.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/g, function (whole, txt, url) {
      var href = safeUrl(url, false);
      if (!href) return whole;
      var external = /^https?:/i.test(href) ? ' target="_blank" rel="noopener noreferrer"' : '';
      stash.push('<a href="' + escapeHtml(href) + '"' + external + '>' + escapeHtml(txt) + '</a>');
      return '\u0000' + (stash.length - 1) + '\u0000';
    });

    s = escapeHtml(s);

    s = s
      .replace(/\*\*\*([^*]+)\*\*\*/g, '<strong><em>$1</em></strong>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^\w*])\*([^*\n]+)\*/g, '$1<em>$2</em>')
      .replace(/(^|[^\w_])__([^_]+)__/g, '$1<strong>$2</strong>')
      .replace(/~~([^~]+)~~/g, '<del>$1</del>')
      .replace(/==([^=]+)==/g, '<mark>$1</mark>');

    s = s.replace(/(^|[\s(])((?:https?:\/\/)[^\s<)]+)/g, function (whole, pre, url) {
      return pre + '<a href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer">' + escapeHtml(url) + '</a>';
    });

    s = s.replace(/\u0000(\d+)\u0000/g, function (_, i) { return stash[+i] || ''; });

    return s;
  }

  /* ------------------------------ 块级规则 ------------------------------ */

  var RE_FENCE = /^\s{0,3}(?:```|~~~)\s*([^\s`]*)[^\n]*$/;
  var RE_HEADING = /^\s{0,3}(#{1,6})\s+([^\n]*)$/;
  var RE_HR = /^\s{0,3}(?:[-*_]\s*){3,}$/;
  var RE_QUOTE = /^\s{0,3}>/;
  var RE_UL = /^(\s*)([-*+])\s+([^\n]*)$/;
  var RE_OL = /^(\s*)(\d{1,9})[.)]\s+([^\n]*)$/;
  var RE_SEP_CELL = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;

  function isTableStart(lines, i) {
    var line = lines[i] || '';
    var next = lines[i + 1] || '';
    if (line.indexOf('|') < 0 || RE_FENCE.test(line)) return false;
    return RE_SEP_CELL.test(next) && next.indexOf('|') >= 0;
  }

  function isBlockStart(lines, i) {
    var line = lines[i] || '';
    return RE_FENCE.test(line) || RE_HEADING.test(line) || RE_HR.test(line) ||
      RE_QUOTE.test(line) || RE_UL.test(line) || RE_OL.test(line) || isTableStart(lines, i);
  }

  function splitRow(line) {
    var t = line.trim();
    if (t.charAt(0) === '|') t = t.slice(1);
    if (t.charAt(t.length - 1) === '|') t = t.slice(0, -1);
    return t.split('|').map(function (c) { return c.trim(); });
  }

  function renderTable(head, sep, rows) {
    var aligns = splitRow(sep).map(function (c) {
      var l = c.charAt(0) === ':';
      var r = c.charAt(c.length - 1) === ':';
      if (l && r) return 'center';
      if (r) return 'right';
      if (l) return 'left';
      return '';
    });
    function cells(arr, tag) {
      return '<tr>' + arr.map(function (c, i) {
        var a = aligns[i] ? ' style="text-align:' + aligns[i] + '"' : '';
        return '<' + tag + a + '>' + inline(c) + '</' + tag + '>';
      }).join('') + '</tr>';
    }
    var h = '<div class="table-wrap"><table><thead>' + cells(splitRow(head), 'th') + '</thead><tbody>';
    rows.forEach(function (r) { h += cells(splitRow(r), 'td'); });
    h += '</tbody></table></div>';
    return h;
  }

  function renderListTree(items, ordered) {
    if (!items.length) return '';
    var tag = ordered ? 'ol' : 'ul';
    return '<' + tag + '>' + items.map(function (it) {
      var body = inline(it.text).replace(/\n/g, '<br>');
      var sub = it.children.length ? renderListTree(it.children, it.children[0].ordered) : '';
      return '<li>' + body + sub + '</li>';
    }).join('') + '</' + tag + '>';
  }

  function renderList(lines, start) {
    var items = [];
    var baseIndent = null;
    var topOrdered = RE_OL.test(lines[start]);
    var i = start;

    while (i < lines.length) {
      var line = lines[i];
      if (!line.trim()) {
        if (RE_UL.test(lines[i + 1] || '') || RE_OL.test(lines[i + 1] || '')) { i++; continue; }
        break;
      }
      var mu = line.match(RE_UL);
      var mo = line.match(RE_OL);
      var m = mu || mo;
      if (!m) {
        if (items.length && /^\s{2,}\S/.test(line) && !isBlockStart(lines, i)) {
          items[items.length - 1].text += '\n' + line.trim();
          i++;
          continue;
        }
        break;
      }
      var indent = m[1].length;
      if (baseIndent === null) baseIndent = indent;
      if (indent < baseIndent) break;
      var node = {
        level: Math.round((indent - baseIndent) / 2) || 0,
        text: m[3] || '',
        ordered: !!mo,
        children: []
      };
      if (node.level <= 0 || !items.length) {
        node.level = 0;
        items.push(node);
      } else {
        items[items.length - 1].children.push(node);
      }
      i++;
    }

    return { html: renderListTree(items, topOrdered), next: i };
  }

  function blocks(src) {
    var lines = String(src).replace(/\r\n?/g, '\n').split('\n');
    var out = '';
    var i = 0;
    var n = lines.length;

    while (i < n) {
      var line = lines[i];

      if (!line.trim()) { i++; continue; }

      var mf = line.match(RE_FENCE);
      if (mf) {
        var ticks = line.trim().slice(0, 3);
        var lang = mf[1] || '';
        var code = [];
        i++;
        var closer = new RegExp('^\\s{0,3}' + ticks.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$');
        while (i < n && !closer.test(lines[i])) {
          code.push(lines[i]);
          i++;
        }
        i++;
        out += '<div class="code-block">' +
          '<div class="code-head"><span class="code-lang">' + escapeHtml(lang || 'text') + '</span>' +
          '<button class="code-copy" type="button" title="复制代码">复制</button></div>' +
          '<pre><code class="lang-' + escapeHtml(langKey(lang) || 'text') + '">' + highlight(code.join('\n'), lang) + '</code></pre>' +
          '</div>';
        continue;
      }

      var mh = line.match(RE_HEADING);
      if (mh) {
        var lv = mh[1].length;
        out += '<h' + lv + ' class="md-h">' + inline(mh[2]) + '</h' + lv + '>';
        i++;
        continue;
      }

      if (RE_HR.test(line) && !isTableStart(lines, i)) {
        out += '<hr class="md-hr">';
        i++;
        continue;
      }

      if (RE_QUOTE.test(line)) {
        var q = [];
        while (i < n && RE_QUOTE.test(lines[i])) {
          q.push(lines[i].replace(/^\s{0,3}>\s?/, ''));
          i++;
        }
        out += '<blockquote>' + blocks(q.join('\n')) + '</blockquote>';
        continue;
      }

      if (isTableStart(lines, i)) {
        var head = line;
        var sep = lines[i + 1];
        var rows = [];
        i += 2;
        while (i < n && lines[i].indexOf('|') >= 0 && lines[i].trim() !== '') {
          rows.push(lines[i]);
          i++;
        }
        out += renderTable(head, sep, rows);
        continue;
      }

      if (RE_UL.test(line) || RE_OL.test(line)) {
        var res = renderList(lines, i);
        out += res.html;
        i = res.next;
        continue;
      }

      var para = [];
      while (i < n && lines[i].trim() && !isBlockStart(lines, i)) {
        para.push(lines[i]);
        i++;
      }
      if (!para.length) { i++; continue; }
      out += '<p>' + inline(para.join('\n')).replace(/\n/g, '<br>') + '</p>';
    }
    return out;
  }

  var ChatMD = {
    render: function (text) { return blocks(text || ''); },
    inline: inline,
    highlight: highlight,
    escapeHtml: escapeHtml,
    langKey: langKey
  };

  global.ChatMD = ChatMD;
  if (typeof module !== 'undefined' && module.exports) module.exports = ChatMD;
})(typeof window !== 'undefined' ? window : globalThis);
