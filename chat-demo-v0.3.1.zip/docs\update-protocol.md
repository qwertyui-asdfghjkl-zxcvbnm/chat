# 自更新协议（模板）

本版只交付**模板**：前端、启动器的接口都已写好，但更新开关默认关闭
（`assets/update-config.js` 里 `enabled: false`），设置面板上盖一层遮罩，
「检查更新」按钮不可点击。等你的更新服务器就绪，改一个布尔值即可启用，不用动其它代码。

```
浏览器  ──GET  /api/update/manifest.json?channel=stable──▶  本地启动器
                                                              │
                                       （配置了 UPDATE_SERVER 时）
                                                              ▼
                                              你的更新服务器 /manifest.json
```

## 1. 参与的文件

| 文件 | 作用 |
| --- | --- |
| `assets/version.js` | 当前版本号（`CHAT_VERSION`），发布时改这里 |
| `assets/update-config.js` | 更新开关与接口地址（`CHAT_UPDATE`） |
| `assets/updater.js` | 检查 / 应用逻辑（`ChatUpdater`） |
| `docs/update-protocol.md` | 本文档，服务端契约 |

## 2. 版本清单（manifest.json）

更新服务器返回的 JSON：

```json
{
  "version": "0.3.1",
  "channel": "stable",
  "publishedAt": "2026-12-01",
  "notes": [
    "新增 markdown 表格复制",
    "修复长对话滚动跳动"
  ],
  "downloadUrl": "https://你的服务器/releases/chat-demo-v0.3.1.zip",
  "sha256": "可选，强烈建议：zip 的 sha256，启动器替换前校验",
  "minVersion": "0.2.0",
  "applyUrl": "可选，覆盖默认的应用接口"
}
```

字段说明：

- `version`（必填）：语义化版本，前端按 `0.3.0` ↔ `0.3.1` 逐段数字比较，**只看数字段**，`0.3.10 > 0.3.9`。
- `channel`：`stable` / `beta`，前端请求时会带 `?channel=`。
- `publishedAt`：`YYYY-MM-DD`，弹窗里显示。
- `notes`：字符串数组，也可以是一段用换行分隔的字符串。
- `downloadUrl`：zip 直链。启动器拒绝替身时应能直接下载，所以**必须可公开访问**。
- `sha256`：zip 的 sha256（hex），启动器下载后校验，校验失败要中止替换。
- `minVersion`：可选，低于它时前端提示「请先手动升级到 minVersion」。

## 3. 前端调用的接口

### GET `/api/update/manifest.json?channel=stable`

- 由本地启动器提供（`server.js` / `server.py`）。
- 配置了 `--update-server`（或环境变量 `UPDATE_SERVER`）时，转发到
  `<UPDATE_SERVER>/manifest.json?channel=stable`；没配置时返回：

```json
{ "error": "更新服务器未配置（模板）", "hint": "...", "version": "0.3.0" }
```

状态码 `501`。前端拿到 501 只会显示「未接入」，不产生任何副作用。

### POST `/api/update/apply`

请求体（前端 `updater.js` 发的就是这些）：

```json
{
  "version": "0.3.1",
  "downloadUrl": "https://你的服务器/releases/chat-demo-v0.3.1.zip",
  "sha256": "……",
  "channel": "stable"
}
```

本版这里是**占位**，固定返回 `501`：

```json
{ "error": "应用更新尚未实现（占位接口）", "hint": "……", "received": { … } }
```

前端收到 `404 / 501`（或网络失败）时，若 `fallbackToDownload: true`，
会退化为浏览器直接下载 `downloadUrl`，并提示「解压覆盖后刷新页面」。

## 4. 启动器要实现什么

`/api/update/apply` 建议按这个顺序做，任何一步失败都要返回非 2xx 且不改动现有文件：

1. 校验 `version` 比当前版本新（读 `assets/version.js` 或自身常量）。
2. 下载 `downloadUrl` 到临时目录（超时、限大小，防止打爆磁盘）。
3. 校验 `sha256`。
4. 备份当前程序文件（不含 `localStorage`，聊天记录在浏览器里）。
5. 解压到临时目录，确认关键文件齐全（`index.html`、`assets/app.js`）。
6. 原子替换（先改名为 `.old`，再移动新目录），失败则回滚。
7. 返回 `200 { "ok": true, "message": "更新完成，刷新页面后生效" }`。

启动器是用户本机进程，只监听 `127.0.0.1`；**不要**给它加公网监听，也不要让它执行清单里的任意命令。

## 5. 打开开关的步骤

1. 起更新服务器，放好 `manifest.json` 和 zip。
2. 启动器加参数：

```bash
node server.js --update-server https://你的服务器
# 或
python server.py --update-server https://你的服务器
# 或设环境变量 UPDATE_SERVER
```

3. 改 `assets/update-config.js`：

```js
window.CHAT_UPDATE = {
  enabled: true,          // ← 只改这里
  endpoint: '/api/update',
  channel: 'stable',
  ...
};
```

4. 刷新页面：遮罩消失，「检查更新」可点；发现新版本会弹出更新弹窗。
5. 发新版本时，先改 `assets/version.js` 的 `version` / `build`，再更新服务器上的
   `manifest.json` 与 zip。

## 6. 设计取舍

- **浏览器不做文件替换**：网页没有权限改程序目录，也没有可靠的断点续传/校验，
  所以下载、校验、替换全部交给启动器；前端只负责「发现 → 告诉用户 → 调接口」。
- **默认关闭**：没有服务器时任何点击都不该产生半成品行为，遮罩比「点了报错」更清楚。
- **可降级**：启动器没实现 apply 也不影响用户升级——下载 zip 手动覆盖即可，这条路始终保留。
