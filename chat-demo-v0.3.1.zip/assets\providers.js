/* =========================================================================
 * providers.js — 模型服务适配层
 * 支持：Ollama 原生 /api/chat、DeepSeek、任意 OpenAI 兼容 /v1/chat/completions
 * 同时兼容浏览器与 node（便于自动化测试）。
 * ========================================================================= */
(function (global) {
  'use strict';

  function trimBase(base) {
    return String(base || '').trim().replace(/\/+$/, '');
  }

  function ChatError(message, info) {
    var e = new Error(message);
    e.name = 'ChatError';
    e.kind = (info && info.kind) || 'unknown';
    e.status = (info && info.status) || 0;
    e.detail = (info && info.detail) || '';
    e.hint = (info && info.hint) || '';
    return e;
  }

  function timeoutSignal(signal, ms) {
    var ctrl = new AbortController();
    var timer = setTimeout(function () {
      try { ctrl.abort(new Error('timeout')); } catch (e) { ctrl.abort(); }
    }, ms || 30000);
    if (signal) {
      if (signal.aborted) ctrl.abort();
      else signal.addEventListener('abort', function () { try { ctrl.abort(); } catch (e) { } }, { once: true });
    }
    return {
      signal: ctrl.signal,
      clear: function () { clearTimeout(timer); }
    };
  }

  async function fetchJson(url, options, timeoutMs) {
    var t = timeoutSignal(options && options.signal, timeoutMs || 30000);
    var res;
    try {
      res = await fetch(url, Object.assign({}, options, { signal: t.signal }));
    } catch (err) {
      t.clear();
      if (options && options.signal && options.signal.aborted) {
        var ab = new Error('已停止生成');
        ab.name = 'AbortError';
        ab.kind = 'aborted';
        throw ab;
      }
      if (err && (err.message === 'timeout' || err.name === 'TimeoutError')) {
        throw ChatError('请求超时（' + Math.round((timeoutMs || 30000) / 1000) + ' 秒无响应）', {
          kind: 'timeout', hint: '本地模型首次加载较慢，可以稍后重试，或换更小的模型。'
        });
      }
      throw ChatError('无法连接到 ' + (url.split('/')[2] || url), {
        kind: 'network',
        detail: String((err && err.message) || err),
        hint: '服务没启动、地址写错，或被浏览器跨域策略拦截。用「启动.bat / node server.js」打开可自动绕过跨域。'
      });
    }
    t.clear();
    return res;
  }

  async function errorFrom(res) {
    var text = '';
    try { text = await res.text(); } catch (e) { }
    var message = text;
    var detail = text;
    try {
      var j = JSON.parse(text);
      message = j.error && (j.error.message || j.error) || j.message || j.detail || text;
      if (typeof message !== 'string') message = JSON.stringify(message);
    } catch (e) { }
    var status = res.status;
    var kind = 'http';
    var hint = '';
    if (status === 401 || status === 403) { kind = 'auth'; hint = 'API Key 无效或没有权限，去设置里检查一下。'; }
    else if (status === 404) { kind = 'notfound'; hint = '接口地址或模型名可能不对。Ollama 需要 /api 路径，OpenAI 兼容接口通常以 /v1 结尾。'; }
    else if (status === 429) { kind = 'rate'; hint = '请求过于频繁，被限流了，等一会儿再试。'; }
    else if (status >= 500) { kind = 'server'; hint = '服务端出错了，看下终端日志。'; }
    else if (status === 400) { kind = 'badrequest'; hint = '请求参数不被服务端接受（可能是该模型不支持深度思考参数）。'; }
    return ChatError('HTTP ' + status + '：' + String(message).slice(0, 300) || ('HTTP ' + status), {
      kind: kind, status: status, detail: detail, hint: hint
    });
  }

  async function readStream(res, onLine) {
    if (!res.body || !res.body.getReader) {
      // 极老环境：退化为整体读取
      var all = await res.text();
      all.split('\n').forEach(function (l) { onLine(l.replace(/\r$/, '')); });
      return;
    }
    var reader = res.body.getReader();
    var decoder = new TextDecoder('utf-8');
    var buffer = '';
    try {
      while (true) {
        var step = await reader.read();
        if (step.done) break;
        buffer += decoder.decode(step.value, { stream: true });
        var nl;
        while ((nl = buffer.indexOf('\n')) >= 0) {
          var line = buffer.slice(0, nl);
          buffer = buffer.slice(nl + 1);
          onLine(line.replace(/\r$/, ''));
        }
      }
      buffer += decoder.decode();
      if (buffer.trim()) onLine(buffer.trim());
    } finally {
      try {
        var c = reader.cancel();
        if (c && typeof c.catch === 'function') c.catch(function () { });
      } catch (e) { }
    }
  }

  function parseJsonSafe(text) {
    try { return JSON.parse(text); } catch (e) { return null; }
  }

  /* -------------------------------- Ollama -------------------------------- */

  var Ollama = {
    id: 'ollama',
    label: 'Ollama 本地',

    async listModels(base, options) {
      var res = await fetchJson(trimBase(base) + '/api/tags', options, (options && options.timeout) || 8000);
      if (!res.ok) throw await errorFrom(res);
      var j = await res.json();
      var models = (j.models || []).map(function (m) {
        var d = m.details || {};
        return {
          name: m.name || m.model,
          size: m.size || 0,
          paramSize: d.parameter_size || '',
          quant: d.quantization_level || '',
          family: d.family || '',
          ctx: d.context_length || 0,
          caps: m.capabilities || [],
          modifiedAt: m.modified_at || ''
        };
      });
      models.sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });
      return models;
    },

    async showModel(base, name, options) {
      var res = await fetchJson(trimBase(base) + '/api/show', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: name, verbose: false }),
        signal: options && options.signal
      }, 8000);
      if (!res.ok) throw await errorFrom(res);
      var j = await res.json();
      return {
        caps: j.capabilities || [],
        system: j.system || '',
        template: j.template || '',
        paramSize: (j.details && j.details.parameter_size) || '',
        ctx: (j.model_info && j.model_info['general.context_length']) || 0
      };
    },

    async chat(o) {
      var base = trimBase(o.base);
      var body = {
        model: o.model,
        messages: o.messages,
        stream: o.stream !== false,
        keep_alive: o.keepAlive || '10m'
      };
      var options = {};
      if (typeof o.temperature === 'number') options.temperature = o.temperature;
      if (o.numCtx) options.num_ctx = o.numCtx;
      if (Object.keys(options).length) body.options = options;
      if (o.thinkMode !== 'off') body.think = !!o.deepThink;

      var res = await fetchJson(base + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: o.signal
      }, o.timeout || 120000);
      if (!res.ok) throw await errorFrom(res);

      var acc = { content: '', thinking: '', usage: null };

      if (!body.stream) {
        var j = await res.json();
        if (j.error) throw ChatError(String(j.error), { kind: 'server', detail: String(j.error) });
        acc.content = (j.message && j.message.content) || '';
        acc.thinking = (j.message && j.message.thinking) || '';
        acc.usage = {
          prompt: j.prompt_eval_count || 0,
          completion: j.eval_count || 0,
          totalMs: Math.round((j.total_duration || 0) / 1e6)
        };
        if (acc.thinking && o.onThinking) o.onThinking(acc.thinking);
        if (acc.content && o.onContent) o.onContent(acc.content);
        if (o.onUsage) o.onUsage(acc.usage);
        return acc;
      }

      await readStream(res, function (line) {
        if (!line.trim()) return;
        var j = parseJsonSafe(line);
        if (!j) return;
        if (j.error) throw ChatError(String(j.error), { kind: 'server', detail: String(j.error) });
        var m = j.message || {};
        if (m.thinking) {
          acc.thinking += m.thinking;
          if (o.onThinking) o.onThinking(m.thinking);
        }
        if (m.content) {
          acc.content += m.content;
          if (o.onContent) o.onContent(m.content);
        }
        if (j.done) {
          acc.usage = {
            prompt: j.prompt_eval_count || 0,
            completion: j.eval_count || 0,
            totalMs: Math.round((j.total_duration || 0) / 1e6)
          };
          if (o.onUsage) o.onUsage(acc.usage);
        }
      });

      return acc;
    }
  };

  /* --------------------------- OpenAI 兼容 / DeepSeek --------------------------- */

  function ensureV1(base) {
    var b = trimBase(base);
    if (!b) return '';
    if (/\/v\d+(\.\d+)?$/i.test(b)) return b;
    if (b.indexOf('/') === -1) return b + '/v1';
    try {
      var u = new URL(b, 'http://placeholder.local');
      if (u.pathname === '/' || u.pathname === '') return b + '/v1';
    } catch (e) { }
    return b;
  }

  function authHeaders(cfg) {
    var h = { 'Content-Type': 'application/json' };
    if (cfg.apiKey && cfg.apiKey.trim()) h.Authorization = 'Bearer ' + cfg.apiKey.trim();
    return h;
  }

  var OpenAICompat = {
    id: 'openai',
    label: 'OpenAI 兼容',

    async listModels(cfg, options) {
      var base = ensureV1(cfg.base);
      var res = await fetchJson(base + '/models', { headers: authHeaders(cfg), signal: options && options.signal },
        (options && options.timeout) || 10000);
      if (!res.ok) throw await errorFrom(res);
      var j = await res.json();
      var list = j.data || j.models || [];
      var models = list.map(function (m) {
        var id = m.id || m.name || m.model || '';
        return {
          name: id,
          size: 0,
          paramSize: '',
          caps: [],
          family: (m.owned_by || '')
        };
      }).filter(function (m) { return m.name; });
      models.sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });
      return models;
    },

    async chat(o) {
      var base = ensureV1(o.base);
      var headers = authHeaders({ apiKey: o.apiKey });
      var body = {
        model: o.model,
        messages: o.messages,
        stream: o.stream !== false
      };
      if (typeof o.temperature === 'number') body.temperature = o.temperature;
      if (o.stream !== false) body.stream_options = { include_usage: true };

      // 深度思考参数：不同服务端字段不同，失败会自动去参数重试
      if (o.thinkMode !== 'off' && o.deepThink) {
        if (o.provider === 'deepseek' && !/reasoner|reasoning/i.test(o.model || '')) {
          body.thinking = { type: 'enabled' };
        } else if (o.provider === 'custom') {
          body.reasoning_effort = 'high';
        }
      }
      if (o.thinkMode === 'off') {
        delete body.thinking;
        delete body.reasoning_effort;
      }

      var res = await fetchJson(base + '/chat/completions', {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(body),
        signal: o.signal
      }, o.timeout || 120000);
      if (!res.ok) throw await errorFrom(res);

      var acc = { content: '', thinking: '', usage: null, model: '' };
      var lastUsage = null;

      if (o.stream === false) {
        var j = await res.json();
        var ch = (j.choices || [])[0] || {};
        var msg = ch.message || {};
        acc.content = msg.content || '';
        acc.thinking = msg.reasoning_content || msg.reasoning || msg.thinking || '';
        acc.model = j.model || o.model;
        acc.usage = usageOf(j.usage);
        if (acc.thinking && o.onThinking) o.onThinking(acc.thinking);
        if (acc.content && o.onContent) o.onContent(acc.content);
        if (o.onUsage && acc.usage) o.onUsage(acc.usage);
        return acc;
      }

      await readStream(res, function (line) {
        if (!line.trim()) return;
        if (line.charAt(0) === ':') return; // SSE 心跳
        if (line.indexOf('data:') !== 0) {
          var maybe = parseJsonSafe(line);
          if (maybe && maybe.error) throw ChatError(String(maybe.error.message || maybe.error), { kind: 'server', detail: line });
          return;
        }
        var payload = line.slice(5).trim();
        if (payload === '[DONE]') return;
        var j = parseJsonSafe(payload);
        if (!j) return;
        if (j.error) throw ChatError(String(j.error.message || j.error), { kind: 'server', detail: payload });
        var ch = (j.choices || [])[0] || {};
        var d = ch.delta || ch.message || {};
        var think = d.reasoning_content || d.reasoning || d.thinking;
        if (think) {
          acc.thinking += think;
          if (o.onThinking) o.onThinking(think);
        }
        if (d.content) {
          acc.content += d.content;
          if (o.onContent) o.onContent(d.content);
        }
        if (j.usage) lastUsage = usageOf(j.usage);
        if (j.model && !acc.model) { acc.model = j.model; if (o.onModelName) o.onModelName(j.model); }
      });

      acc.usage = lastUsage;
      if (acc.usage && o.onUsage) o.onUsage(acc.usage);
      return acc;
    }
  };

  function usageOf(u) {
    if (!u) return null;
    return {
      prompt: u.prompt_tokens || 0,
      completion: u.completion_tokens || 0,
      total: u.total_tokens || 0
    };
  }

  /* -------------------------------- 调度层 -------------------------------- */

  var META = {
    ollama: { label: 'Ollama 本地', kind: 'ollama' },
    deepseek: { label: 'DeepSeek', kind: 'openai' },
    custom: { label: 'OpenAI 兼容', kind: 'openai' }
  };

  var ChatProviders = {
    META: META,

    kindOf: function (provider) { return (META[provider] || META.custom).kind; },

    listModels: async function (provider, cfg, options) {
      if (this.kindOf(provider) === 'ollama') return Ollama.listModels(cfg.base, options);
      return OpenAICompat.listModels(cfg, options);
    },

    showOllamaModel: function (base, name, options) { return Ollama.showModel(base, name, options); },

    // 测试连接 + 拉模型列表
    test: async function (provider, cfg, options) {
      try {
        var models = await this.listModels(provider, cfg, options);
        return { ok: true, models: models };
      } catch (err) {
        return { ok: false, error: err };
      }
    },

    // 一次对话（内部处理“参数不被支持”的降级重试）
    chat: async function (o) {
      var emitted = false;
      var userOnContent = o.onContent;
      var userOnThinking = o.onThinking;

      function attempt(thinkMode) {
        var opts = Object.assign({}, o, { thinkMode: thinkMode || 'auto' });
        opts.onContent = function (t) { emitted = true; if (userOnContent) userOnContent(t); };
        opts.onThinking = function (t) { emitted = true; if (userOnThinking) userOnThinking(t); };
        return this.kindOf(o.provider) === 'ollama' ? Ollama.chat(opts) : OpenAICompat.chat(opts);
      }

      var self = this;
      try {
        return await attempt.call(self, 'auto');
      } catch (err) {
        var detail = ((err && err.detail) || '') + ' ' + ((err && err.message) || '');
        var retryable = !emitted && err && err.status === 400 &&
          /think|reasoning|thinking|unknown|unrecognized|unsupported|extra|invalid/i.test(detail);
        if (!retryable) throw err;
        return await attempt.call(self, 'off');
      }
    },

    describeError: function (err) {
      if (!err) return { title: '出错了', body: '未知错误' };
      var kind = err.kind || 'unknown';
      var map = {
        network: { title: '连不上模型服务', body: err.hint || '检查服务是否启动、地址是否正确。' },
        timeout: { title: '请求超时', body: err.hint || '本地大模型首次加载较慢，稍后重试或换小模型。' },
        auth: { title: '鉴权失败', body: err.hint || '检查 API Key。' },
        notfound: { title: '地址或模型不存在', body: err.hint || '检查接口地址与模型名。' },
        rate: { title: '被限流', body: err.hint || '稍后重试。' },
        server: { title: '服务端错误', body: err.hint || '查看服务端日志。' },
        badrequest: { title: '请求被拒绝', body: err.hint || '可能模型不支持该参数，已尝试自动降级。' },
        aborted: { title: '已停止生成', body: '已保留已生成内容。' }
      };
      var info = map[kind] || { title: '出错了', body: err.message || '未知错误' };
      return {
        title: info.title,
        body: info.body,
        detail: kind === 'aborted' ? '' : String(err.message || '').slice(0, 260)
      };
    }
  };

  global.ChatProviders = ChatProviders;
  if (typeof module !== 'undefined' && module.exports) module.exports = ChatProviders;
})(typeof window !== 'undefined' ? window : globalThis);
