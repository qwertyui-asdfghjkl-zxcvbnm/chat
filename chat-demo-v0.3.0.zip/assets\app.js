/* =========================================================================
 * app.js — 界面与交互
 * ========================================================================= */
(function () {
  'use strict';

  var S = window.ChatStore;
  var MD = window.ChatMD;
  var P = window.ChatProviders;

  var $ = function (id) { return document.getElementById(id); };
  var st = function () { return S.state; };

  var ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC_MAP[c]; }); }

  var ICON = {
    copy: '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>',
    refresh: '<svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-2.7-6.4"/><path d="M21 3.5v5.5h-5.5"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M3.5 6.5h17"/><path d="M9 6.5V4.5h6v2"/><path d="M6 6.5l1 13h10l1-13"/></svg>',
    edit: '<svg viewBox="0 0 24 24"><path d="M12 20.5h9"/><path d="M16.5 3.8a2.2 2.2 0 0 1 3.1 3.1L7.5 19l-4.2 1 1-4.2z"/></svg>',
    chev: '<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>',
    up: '<svg viewBox="0 0 24 24"><path d="M12 19.5V5"/><path d="M5 12l7-7 7 7"/></svg>',
    stop: '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2"/></svg>',
    plus: '<svg viewBox="0 0 24 24"><path d="M12 5v14"/><path d="M5 12h14"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v2.4M12 18.8v2.4M4.6 7.4l2 1.2M17.4 16.6l2 1.2M2.8 12h2.4M18.8 12h2.4M4.6 16.6l2-1.2M17.4 7.4l2-1.2"/></svg>',
    download: '<svg viewBox="0 0 24 24"><path d="M12 3.5v11"/><path d="M7.5 11l4.5 4.5 4.5-4.5"/><path d="M4.5 20.5h15"/></svg>',
    brain: '<svg viewBox="0 0 24 24"><path d="M12 5.2a3 3 0 0 0-6 0 3.4 3.4 0 0 0-1.4 6.3A3.4 3.4 0 0 0 6 17.4a2.6 2.6 0 0 0 5.9 1.4V5.2z"/><path d="M12 5.2a3 3 0 0 1 6 0 3.4 3.4 0 0 1 1.4 6.3 3.4 3.4 0 0 1-1.4 6A2.6 2.6 0 0 1 12 18.8"/></svg>',
    sun: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M18.8 5.2l-1.4 1.4M6.6 17.4L5.2 18.8"/></svg>'
  };

  var ui = {
    generating: null,     // { convId, msgId, ctrl, startedAt, thinkStart }
    stick: true,
    conn: { status: 'idle', error: null },
    popoverOpen: false,
    settingsOpen: false,
    collapsed: false,
    paintTimers: {},
    lastFocus: null,
    typeTimer: null,
    typingSet: [],
    reveal: {},
    lastPaint: {},
    heartbeat: null,
    updateOpen: false,
    reducedMotion: typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)').matches : false
  };

  /* ================================ 启动 ================================ */

  function boot() {
    S.load();
    cleanupStreamingFlags();
    applyTheme();
    ui.collapsed = !!S.state.uiCollapsed;
    $('app').classList.toggle('sidebar-collapsed', ui.collapsed);

    bindEvents();
    syncVersion();
    setupUpdate();
    renderAll();
    syncSettingsForm();
    updateConnChip();

    // 记录是否正在生成时被刷新
    window.addEventListener('beforeunload', function () { S.save(true); });

    if (st().settings.provider === 'ollama' && st().settings.providers.ollama.autoConnect !== false) {
      probeOllama({ silent: true, setProvider: false });
    }
    setTimeout(function () { $('input').focus(); }, 40);

    if (location.protocol === 'file:') {
      var hint = $('composerHint');
      hint.textContent = '本地文件方式打开：若 Ollama 连不上（跨域），请改用 启动.bat 或 node server.js 打开';
      hint.classList.add('warn');
    }
  }

  function cleanupStreamingFlags() {
    S.state.conversations.forEach(function (c) {
      c.messages.forEach(function (m) {
        if (m.streaming) { m.streaming = false; if (!m.content && !m.error && !m.thinking) m.content = '（已中断）'; }
      });
    });
  }

  function applyTheme() {
    var mode = st().settings.theme;
    var dark = mode === 'dark' || (mode === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    var btn = $('themeBtn');
    if (btn) btn.title = mode === 'system' ? '主题：跟随系统' : mode === 'dark' ? '主题：深色' : '主题：浅色';
  }

  function renderAll() {
    renderSidebar();
    renderThread();
    renderComposer();
    updateConnChip();
  }

  /* ================================ 侧边栏 ================================ */

  function renderSidebar() {
    var listEl = $('convList');
    var convs = S.state.conversations.slice().sort(function (a, b) { return b.updatedAt - a.updatedAt; });

    if (!convs.length) {
      listEl.innerHTML = '<div class="conv-empty">还没有对话<br><span>在下面输入框里开始吧</span></div>';
    } else {
      var today = startOfDay(Date.now());
      var yesterday = today - 86400000;
      var groups = [
        { label: '今天', list: [] },
        { label: '昨天', list: [] },
        { label: '更早', list: [] }
      ];
      convs.forEach(function (c) {
        var d = startOfDay(c.updatedAt);
        var idx = d >= today ? 0 : (d === yesterday ? 1 : 2);
        groups[idx].list.push(c);
      });
      listEl.innerHTML = groups.filter(function (g) { return g.list.length; }).map(function (g) {
        return '<div class="conv-group-label">' + g.label + '</div>' + g.list.map(convItemHtml).join('');
      }).join('');
    }

    var cur = S.current();
    $('topbarTitle').textContent = cur && cur.messages.length ? cur.title : '新对话';
  }

  function startOfDay(ts) {
    var d = new Date(ts);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  }

  function convItemHtml(c) {
    var active = c.id === S.state.currentId ? ' active' : '';
    var preview = '';
    for (var i = c.messages.length - 1; i >= 0; i--) {
      if (c.messages[i].content) {
        preview = c.messages[i].content
          .replace(/```[\s\S]*?```/g, ' [代码] ')
          .replace(/[*_`>#~]/g, '')
          .replace(/\s+/g, ' ')
          .slice(0, 60);
        break;
      }
    }
    return '<div class="conv-item' + active + '" data-conv="' + c.id + '">' +
      '<div class="conv-main">' +
      '<div class="conv-title">' + esc(c.title) + '</div>' +
      '<div class="conv-sub">' + esc(preview || '空对话') + '</div>' +
      '</div>' +
      '<div class="conv-meta">' + fmtTime(c.updatedAt) + '</div>' +
      '<button class="conv-del icon-btn" data-del="' + c.id + '" title="删除对话">' + ICON.trash + '</button>' +
      '</div>';
  }

  function fmtTime(ts) {
    var d = new Date(ts);
    var now = new Date();
    var sameDay = d.toDateString() === now.toDateString();
    var hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    if (sameDay) return hm;
    var y = new Date(now.getTime() - 86400000);
    if (d.toDateString() === y.toDateString()) return '昨天 ' + hm;
    return (d.getMonth() + 1) + '月' + d.getDate() + '日';
  }

  /* ================================ 欢迎页 ================================ */

  var SUGGESTS = [
    { t: '解释概念', d: '用三句话讲清量子纠缠，并给一个生活化类比', p: '用三句话讲清量子纠缠，并给一个生活化类比。' },
    { t: '写个脚本', d: 'Python 批量把文件夹里的图片重命名成日期+序号', p: '写一个 Python 脚本，批量把某个文件夹里的图片重命名为「日期-序号」，并说明怎么用。' },
    { t: '整理待办', d: '把一段会议记录提炼成 5 条可执行的待办', p: '把下面这段会议记录整理成 5 条可执行的待办，带上负责人和时间：\n\n（把会议记录粘贴在这里）' },
    { t: '对比方案', d: 'Ollama 和 vLLM 分别适合什么场景', p: 'Ollama 和 vLLM 分别适合什么场景？用表格对比部署难度、并发能力和适用规模。' }
  ];

  function renderWelcome() {
    var s = st().settings;
    var p = s.providers[s.provider];
    var connOk = ui.conn.status === 'ok';
    var hasModel = !!(p && p.model);
    var sub;
    if (s.provider === 'ollama') {
      sub = connOk ? ('本地 Ollama 已连接 · ' + (p.model || '未选模型')) : 'Ollama 还没连上，点下面的按钮自动检测本地服务';
    } else if (s.provider === 'deepseek') {
      sub = hasModel ? ('DeepSeek · ' + p.model) : '填写 API Key 后即可使用';
    } else {
      sub = hasModel ? ('自定义接口 · ' + p.model) : '填写接口地址后即可使用';
    }

    var connectCard = '';
    if (!connOk && s.provider === 'ollama') {
      connectCard =
        '<div class="connect-card">' +
        '<div class="connect-head"><span class="dot warn"></span>一键接入 Ollama</div>' +
        '<p>自动探测 <code>127.0.0.1:11434</code>、载入本地模型；如果直连失败（跨域），用 <code>启动.bat</code> 打开本页面即可自动绕过。</p>' +
        '<div class="connect-actions"><button class="primary-btn" id="welcomeConnect">检测并接入</button>' +
        '<button class="ghost-btn" id="welcomeHelp">排查方法</button></div>' +
        '</div>';
    }

    $('welcome').innerHTML =
      '<div class="welcome-inner">' +
      '<div class="hero">' +
      '<div class="hero-mark">✦</div>' +
      '<h1>有什么可以帮你？</h1>' +
      '<p class="hero-sub">' + esc(sub) + '</p>' +
      '</div>' +
      '<div class="suggest-grid">' + SUGGESTS.map(function (g, i) {
        return '<button class="suggest" data-suggest="' + i + '"><span class="suggest-t">' + esc(g.t) + '</span><span class="suggest-d">' + esc(g.d) + '</span></button>';
      }).join('') + '</div>' +
      connectCard +
      '</div>';
  }

  /* ================================ 消息渲染 ================================ */

  function renderThread(opts) {
    opts = opts || {};
    var conv = S.current();
    var thread = $('thread');
    var welcome = $('welcome');
    thread.innerHTML = '';

    if (!conv || !conv.messages.length) {
      welcome.hidden = false;
      thread.hidden = true;
      renderWelcome();
      if (opts.stick !== false) $('scroll').scrollTop = 0;
      return;
    }

    welcome.hidden = true;
    thread.hidden = false;
    conv.messages.forEach(function (m) {
      if (m.role === 'error') return;
      thread.appendChild(buildMessageEl(m));
    });
    if (opts.stick !== false) jumpToBottom();
  }

  function buildMessageEl(msg) {
    var root = document.createElement('div');
    root.className = 'msg ' + (msg.role === 'user' ? 'msg-user' : 'msg-assistant');
    root.dataset.id = msg.id;

    var refs = {};

    if (msg.role === 'user') {
      root.innerHTML =
        '<div class="bubble"><div class="bubble-text"></div></div>' +
        '<div class="msg-actions">' +
        '<button data-act="copy" title="复制">' + ICON.copy + '</button>' +
        '<button data-act="edit" title="编辑并重新发送">' + ICON.edit + '</button>' +
        '<button data-act="del" title="删除">' + ICON.trash + '</button>' +
        '</div>';
      refs.text = root.querySelector('.bubble-text');
      refs.text.textContent = msg.content;
    } else {
      root.innerHTML =
        '<div class="avatar">✦</div>' +
        '<div class="body">' +
        '<div class="think" hidden>' +
        '<button class="think-head" type="button">' +
        '<span class="think-ico">' + ICON.brain + '</span>' +
        '<span class="think-label">深度思考</span>' +
        '<span class="think-meta"></span>' +
        '<span class="think-chev">' + ICON.chev + '</span>' +
        '</button>' +
        '<div class="think-body"><div class="think-text md"></div></div>' +
        '</div>' +
        '<div class="content md"></div>' +
        '<div class="msg-error" hidden></div>' +
        '<div class="msg-meta"></div>' +
        '<div class="msg-actions">' +
        '<button data-act="copy" title="复制">' + ICON.copy + '</button>' +
        '<button data-act="regen" title="重新生成">' + ICON.refresh + '</button>' +
        '<button data-act="del" title="删除">' + ICON.trash + '</button>' +
        '</div>' +
        '</div>';

      refs.think = root.querySelector('.think');
      refs.thinkLabel = root.querySelector('.think-label');
      refs.thinkMeta = root.querySelector('.think-meta');
      refs.thinkBody = root.querySelector('.think-body');
      refs.thinkText = root.querySelector('.think-text');
      refs.content = root.querySelector('.content');
      refs.error = root.querySelector('.msg-error');
      refs.meta = root.querySelector('.msg-meta');
    }

    root.__refs = refs;
    paintMessage(msg, root);
    return root;
  }

  function paintMessage(msg, root) {
    if (!root || !root.__refs) return;
    var refs = root.__refs;

    if (msg.role === 'user') {
      if (refs.text.textContent !== msg.content) refs.text.textContent = msg.content;
      return;
    }

    var hasThink = !!(msg.thinking && msg.thinking.trim()) || (msg.streaming && msg.expectThinking);
    if (hasThink) {
      refs.think.hidden = false;
      refs.think.classList.toggle('open', !!msg.streaming);
      var label, meta = '';
      if (msg.streaming) {
        label = '深度思考中';
        var secs = msg.thinkStartedAt ? (Date.now() - msg.thinkStartedAt) / 1000 : 0;
        meta = secs ? secs.toFixed(1) + 's' : '';
      } else {
        label = '已深度思考';
        meta = msg.thinkMs ? '用时 ' + (msg.thinkMs / 1000).toFixed(1) + ' 秒' : '';
      }
      refs.thinkLabel.textContent = label;
      refs.thinkMeta.textContent = meta;
      refs.thinkText.innerHTML = MD.render(msg.thinking || '');
    } else {
      refs.think.hidden = true;
    }

    var full = msg.content || '';
    var reveal = ui.reveal[msg.id];
    var shown = (typeof reveal === 'number' && reveal < full.length) ? full.slice(0, reveal) : full;
    var revealing = msg.streaming || shown.length < full.length;

    if (shown) {
      refs.content.innerHTML = MD.render(shown) +
        (revealing ? '<span class="caret" aria-hidden="true"></span>' : '');
      refs.content.classList.remove('is-empty');
    } else if (msg.streaming) {
      refs.content.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
      refs.content.classList.add('is-empty');
    } else {
      refs.content.innerHTML = '';
      refs.content.classList.add('is-empty');
    }

    if (msg.error) {
      refs.error.hidden = false;
      refs.error.innerHTML =
        '<div class="err-title">' + esc(msg.error.title || '出错了') + '</div>' +
        '<div class="err-body">' + esc(msg.error.body || '') + '</div>' +
        (msg.error.detail ? '<div class="err-detail">' + esc(msg.error.detail) + '</div>' : '') +
        '<button class="ghost-btn small" data-act="regen">重试</button>';
    } else {
      refs.error.hidden = true;
      refs.error.innerHTML = '';
    }

    var bits = [];
    if (msg.model) bits.push(msg.model);
    if (msg.usage && (msg.usage.completion || msg.usage.prompt)) {
      bits.push((msg.usage.completion || 0) + ' tokens');
    }
    if (msg.streaming) {
      var live = msg.startedAt ? (Date.now() - msg.startedAt) / 1000 : 0;
      if (live) bits.push('生成中 ' + live.toFixed(1) + 's');
    } else {
      if (msg.genMs) bits.push('用时 ' + (msg.genMs / 1000).toFixed(1) + 's');
      if (msg.usage && msg.usage.completion && msg.genMs && msg.genMs > 400) {
        bits.push((msg.usage.completion / (msg.genMs / 1000)).toFixed(1) + ' tok/s');
      }
      if (msg.stopped) bits.push('已停止');
    }
    refs.meta.textContent = bits.join(' · ');
    refs.meta.hidden = !bits.length;
  }

  /* =============================== 打字机效果 =============================== */

  function startTypeLoop() {
    if (ui.typeTimer || ui.reducedMotion) return;
    ui.typeTimer = setInterval(typeTick, 26);
  }

  function stopTypeLoop() {
    if (ui.typeTimer) { clearInterval(ui.typeTimer); ui.typeTimer = null; }
  }

  function dropTyping(id) {
    var i = ui.typingSet.indexOf(id);
    if (i >= 0) ui.typingSet.splice(i, 1);
    if (!ui.typingSet.length) stopTypeLoop();
  }

  function queueTypewriter(msg) {
    var full = (msg.content || '').length;
    if (ui.reducedMotion) {
      ui.reveal[msg.id] = full;
      paintNow(msg);
      return;
    }
    if (ui.reveal[msg.id] == null) ui.reveal[msg.id] = 0;
    if (ui.typingSet.indexOf(msg.id) < 0) ui.typingSet.push(msg.id);
    startTypeLoop();
  }

  function typeTick() {
    var ids = ui.typingSet.slice();
    if (!ids.length) { stopTypeLoop(); return; }
    var conv = S.current();

    ids.forEach(function (id) {
      var msg = null;
      if (conv) {
        for (var i = 0; i < conv.messages.length; i++) {
          if (conv.messages[i].id === id) { msg = conv.messages[i]; break; }
        }
      }
      if (!msg) { dropTyping(id); return; }

      var total = (msg.content || '').length;
      var at = ui.reveal[id] || 0;
      if (at < total) {
        var backlog = total - at;
        var step = msg.streaming
          ? (backlog > 800 ? Math.ceil(backlog / 12)
            : backlog > 240 ? 10
            : backlog > 80 ? 5
            : 2)
          : (Math.ceil(backlog / 4) + 6);
        ui.reveal[id] = Math.min(total, at + Math.max(1, step));
        paintTyping(msg, false);
      } else if (!msg.streaming) {
        // 追平了，收尾：去掉光标，整块重绘一次
        dropTyping(id);
        paintTyping(msg, true);
      }
    });
  }

  function paintTyping(msg, force) {
    var now = Date.now();
    if (!force && now - (ui.lastPaint[msg.id] || 0) < 45) return;
    ui.lastPaint[msg.id] = now;
    var node = document.querySelector('.msg[data-id="' + msg.id + '"]');
    if (!node) return;
    paintMessage(msg, node);
    if (ui.stick) keepBottom();
  }

  // 切换 / 新建 / 删除会话时，把没打完的直接推到末尾，避免回来后停在半句
  function flushTypewriters() {
    ui.typingSet.slice().forEach(function (id) {
      S.state.conversations.forEach(function (c) {
        if (!c.messages) return;
        c.messages.forEach(function (m) {
          if (m.id === id) ui.reveal[id] = (m.content || '').length;
        });
      });
      dropTyping(id);
    });
  }

  /* --------------------------- 生成中心跳（计时） --------------------------- */

  function startHeartbeat() {
    if (ui.heartbeat) return;
    ui.heartbeat = setInterval(function () {
      if (!ui.generating) { stopHeartbeat(); return; }
      var conv = S.current();
      if (!conv) return;
      var live = null;
      for (var i = 0; i < conv.messages.length; i++) {
        if (conv.messages[i].streaming) { live = conv.messages[i]; break; }
      }
      if (!live) return;
      var node = document.querySelector('.msg[data-id="' + live.id + '"]');
      if (node) paintMessage(live, node);
    }, 500);
  }

  function stopHeartbeat() {
    if (ui.heartbeat) { clearInterval(ui.heartbeat); ui.heartbeat = null; }
  }

  function schedulePaint(msg) {
    var id = msg.id;
    if (ui.paintTimers[id]) return;
    ui.paintTimers[id] = setTimeout(function () {
      delete ui.paintTimers[id];
      var node = document.querySelector('.msg[data-id="' + id + '"]');
      if (node) {
        paintMessage(msg, node);
        if (ui.stick) keepBottom();
      }
    }, 90);
  }

  function paintNow(msg) {
    if (ui.paintTimers[msg.id]) { clearTimeout(ui.paintTimers[msg.id]); delete ui.paintTimers[msg.id]; }
    var node = document.querySelector('.msg[data-id="' + msg.id + '"]');
    if (node) paintMessage(msg, node);
  }

  /* ================================ 滚动 ================================ */

  var scrollEl = null;

  function jumpToBottom() {
    var sc = $('scroll');
    sc.scrollTop = sc.scrollHeight;
    ui.stick = true;
    $('scrollBottom').hidden = true;
  }

  function keepBottom() {
    var sc = $('scroll');
    sc.scrollTop = sc.scrollHeight;
  }

  function nearBottom() {
    var sc = $('scroll');
    return sc.scrollHeight - sc.scrollTop - sc.clientHeight < 90;
  }

  /* ================================ 输入区 ================================ */

  function renderComposer() {
    var s = st().settings;
    var p = s.providers[s.provider];
    var label = p.model || '选择模型';
    $('modelBtnLabel').textContent = label;
    $('modelBtn').title = (P.META[s.provider] || {}).label + ' · ' + label;

    var on = !!s.deepThink;
    var btn = $('thinkToggle');
    btn.dataset.on = on ? 'true' : 'false';
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');

    // 当前模型是否声明支持思考（Ollama 才有明确能力位）
    var canThink = true;
    if (s.provider === 'ollama') {
      var caps = (p.caps || {})[p.model];
      canThink = !caps || caps.indexOf('thinking') >= 0;
    }
    btn.classList.toggle('unsupported', !canThink);
    btn.title = canThink ? '深度思考：开启后模型会先推理再作答（Ctrl+Shift+D）'
      : '当前模型未声明思考能力，开启后可能无效';

    $('topbarModel').textContent = label;
    updateSendState();
  }

  function updateSendState() {
    var ta = $('input');
    var btn = $('sendBtn');
    var generating = !!ui.generating;
    btn.classList.toggle('stop', generating);
    btn.innerHTML = generating ? ICON.stop : ICON.up;
    btn.title = generating ? '停止生成 (Esc)' : '发送 (Enter)';
    btn.disabled = generating ? false : !ta.value.trim();
    var n = ta.value.length;
    $('charCount').textContent = n > 0 ? n + ' 字' : '';
    $('composer').classList.toggle('has-text', !!ta.value.trim());
  }

  function autoGrow() {
    var ta = $('input');
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 208) + 'px';
    updateSendState();
  }

  /* ================================ 发送 / 生成 ================================ */

  function currentCfg() {
    var s = st().settings;
    var p = s.providers[s.provider] || {};
    return { provider: s.provider, base: p.base, apiKey: p.apiKey, model: p.model, caps: p.caps || {} };
  }

  function buildContext(conv, uptoId) {
    var s = st().settings;
    var limit = Number(s.contextMessages) || 0;
    var history = [];
    for (var i = 0; i < conv.messages.length; i++) {
      var m = conv.messages[i];
      if (m.id === uptoId) break;
      if (m.role === 'error') continue;
      if (!m.content && m.role === 'assistant') continue;
      history.push({ role: m.role, content: m.content });
    }
    while (history.length && history[0].role !== 'user') history.shift();
    if (limit > 0) history = history.slice(-limit);
    var out = [];
    if (s.systemPrompt && s.systemPrompt.trim()) out.push({ role: 'system', content: s.systemPrompt.trim() });
    return out.concat(history);
  }

  function sendFromInput() {
    var ta = $('input');
    var text = ta.value.trim();
    if (!text || ui.generating) return;
    ta.value = '';
    autoGrow();
    startTurn(text, true);
  }

  function startTurn(text, appendUser) {
    var cfg = currentCfg();
    if (!cfg.model) {
      toast('先选一个模型', 'warn');
      openModelPicker();
      return;
    }
    var conv = S.ensureCurrent();

    if (appendUser !== false) {
      var um = S.newMessage('user', text);
      conv.messages.push(um);
      conv.updatedAt = Date.now();
      if (conv.title === '新对话') conv.title = S.autoTitle(text);
      S.save();
    } else if (conv.messages.length === 0) {
      conv.title = S.autoTitle(text);
    }

    var am = S.newMessage('assistant', '', {
      model: cfg.model,
      provider: cfg.provider,
      streaming: true,
      startedAt: Date.now(),
      thinkStartedAt: 0
    });
    am.expectThinking = !!st().settings.deepThink && (cfg.provider === 'ollama'
      ? (!cfg.caps[cfg.model] || cfg.caps[cfg.model].indexOf('thinking') >= 0)
      : true);
    conv.messages.push(am);
    conv.updatedAt = Date.now();
    S.save();

    renderSidebar();
    renderThread({ stick: true });
    $('topbarTitle').textContent = conv.title;
    jumpToBottom();

    runGeneration(conv, am, cfg);
  }

  async function runGeneration(conv, am, cfg) {
    var ctrl = new AbortController();
    var started = Date.now();
    ui.generating = { convId: conv.id, msgId: am.id, ctrl: ctrl, startedAt: started };
    startHeartbeat();
    updateSendState();
    $('input').blur();

    var msgs = buildContext(conv, am.id);

    try {
      var res = await P.chat({
        provider: cfg.provider,
        base: cfg.base,
        apiKey: cfg.apiKey,
        model: cfg.model,
        messages: msgs,
        temperature: Number(st().settings.temperature),
        deepThink: !!st().settings.deepThink,
        stream: st().settings.stream !== false,
        signal: ctrl.signal,
        onThinking: function (t) {
          if (!am.thinkStartedAt) am.thinkStartedAt = Date.now();
          am.thinking = (am.thinking || '') + t;
          schedulePaint(am);
        },
        onContent: function (t) {
          am.content = (am.content || '') + t;
          queueTypewriter(am);
        },
        onUsage: function (u) { am.usage = u; schedulePaint(am); }
      });

      am.content = res.content || am.content;
      am.thinking = res.thinking || am.thinking;
      if (res.model) am.model = res.model;
    } catch (err) {
      if (ctrl.signal.aborted) {
        am.stopped = true;
      } else {
        am.error = P.describeError(err);
        if (err && err.kind === 'network' && cfg.provider === 'ollama') ui.conn = { status: 'error', error: err };
      }
    } finally {
      am.streaming = false;
      if (am.thinkStartedAt) am.thinkMs = Date.now() - am.thinkStartedAt;
      am.genMs = Date.now() - started;
      am.expectThinking = false;
      ui.generating = null;
      stopHeartbeat();
      delete ui.paintTimers[am.id];
      S.save();

      var total = (am.content || '').length;
      var queued = ui.reveal[am.id] != null && ui.reveal[am.id] < total;
      if (am.error || am.stopped || ui.reducedMotion) {
        ui.reveal[am.id] = total;
        dropTyping(am.id);
        paintNow(am);
      } else if (queued) {
        // 网络先结束、字还没打完：让打字机继续追，追平后自己收光标
        if (ui.typingSet.indexOf(am.id) < 0) ui.typingSet.push(am.id);
        startTypeLoop();
        paintNow(am);
      } else {
        dropTyping(am.id);
        paintNow(am);
      }

      updateSendState();
      renderSidebar();
      updateConnChip();
      if (am.error) {
        toast(am.error.title, 'error');
      }
    }
  }

  function stopGeneration() {
    if (!ui.generating) return;
    ui.generating.ctrl.abort();
  }

  function regenerate(msgId) {
    if (ui.generating) return;
    var conv = S.current();
    if (!conv) return;
    var idx = -1;
    conv.messages.forEach(function (m, i) { if (m.id === msgId) idx = i; });
    if (idx < 0) idx = conv.messages.length - 1;
    // 找到要重新回答的那条用户消息
    var userIdx = -1;
    for (var i = idx - 1; i >= 0; i--) {
      if (conv.messages[i].role === 'user') { userIdx = i; break; }
    }
    if (userIdx < 0) { toast('没有可重发的用户消息', 'warn'); return; }
    conv.messages = conv.messages.slice(0, userIdx + 1);
    conv.updatedAt = Date.now();
    S.save();
    renderThread({ stick: true });
    var text = conv.messages[userIdx].content;
    // 复用该用户消息，不重复插入
    startTurnAfterUser(conv, text);
  }

  function startTurnAfterUser(conv, text) {
    var cfg = currentCfg();
    if (!cfg.model) { toast('先选一个模型', 'warn'); openModelPicker(); return; }
    var am = S.newMessage('assistant', '', {
      model: cfg.model, provider: cfg.provider, streaming: true, startedAt: Date.now(), thinkStartedAt: 0
    });
    am.expectThinking = !!st().settings.deepThink && (cfg.provider === 'ollama'
      ? (!cfg.caps[cfg.model] || cfg.caps[cfg.model].indexOf('thinking') >= 0)
      : true);
    conv.messages.push(am);
    S.save();
    renderThread({ stick: true });
    jumpToBottom();
    runGeneration(conv, am, cfg);
  }

  /* ================================ 消息操作 ================================ */

  function findMessage(id, conv) {
    conv = conv || S.current();
    if (!conv) return null;
    for (var i = 0; i < conv.messages.length; i++) if (conv.messages[i].id === id) return conv.messages[i];
    return null;
  }

  function removeMessage(conv, id) {
    conv.messages = conv.messages.filter(function (m) { return m.id !== id; });
    conv.updatedAt = Date.now();
    S.save();
    renderThread({ stick: false });
    renderSidebar();
    if (!conv.messages.length) renderThread();
  }

  function copyText(text) {
    if (!text) return;
    var done = function () { toast('已复制', 'ok'); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(fallback);
    } else fallback();

    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast('复制失败', 'error'); }
      document.body.removeChild(ta);
    }
  }

  function beginEdit(msgId) {
    var conv = S.current();
    var msg = findMessage(msgId, conv);
    if (!msg || ui.generating) return;
    var node = document.querySelector('.msg[data-id="' + msgId + '"]');
    if (!node) return;
    var bubble = node.querySelector('.bubble');
    bubble.innerHTML = '<textarea class="edit-area"></textarea><div class="edit-actions">' +
      '<button class="ghost-btn small" data-edit="cancel">取消</button>' +
      '<button class="primary-btn small" data-edit="save">保存并重发</button></div>';
    var ta = bubble.querySelector('.edit-area');
    ta.value = msg.content;
    ta.style.height = Math.min(ta.scrollHeight, 220) + 'px';
    ta.focus();
    ta.setSelectionRange(ta.value.length, ta.value.length);
    node.classList.add('editing');
  }

  function commitEdit(msgId, value) {
    var conv = S.current();
    var idx = -1;
    conv.messages.forEach(function (m, i) { if (m.id === msgId) idx = i; });
    if (idx < 0) return;
    var text = String(value || '').trim();
    if (!text) { toast('内容不能为空', 'warn'); return; }
    conv.messages = conv.messages.slice(0, idx + 1);
    conv.messages[idx].content = text;
    conv.messages[idx].ts = Date.now();
    conv.updatedAt = Date.now();
    if (idx === 0) conv.title = S.autoTitle(text);
    S.save();
    renderThread({ stick: true });
    renderSidebar();
    startTurnAfterUser(conv, text);
  }

  /* ================================ 模型选择浮层 ================================ */

  function openModelPicker() {
    var pop = $('modelPopover');
    if (ui.popoverOpen) { closeModelPicker(); return; }
    ui.popoverOpen = true;
    pop.hidden = false;
    renderModelList('');
    $('modelSearch').value = '';
    $('modelHint').textContent = (P.META[st().settings.provider] || {}).label + ' · ' +
      (st().settings.provider === 'ollama' ? 'Ollama /api/tags' : 'GET /v1/models');

    var btnRect = $('modelBtn').getBoundingClientRect();
    var popRect = pop.getBoundingClientRect();
    var left = Math.min(btnRect.left, window.innerWidth - popRect.width - 12);
    left = Math.max(12, left);
    var top = btnRect.top - popRect.height - 8;
    if (top < 12) top = btnRect.bottom + 8;
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    setTimeout(function () { $('modelSearch').focus(); }, 30);
  }

  function closeModelPicker() {
    ui.popoverOpen = false;
    $('modelPopover').hidden = true;
  }

  function renderModelList(keyword) {
    var s = st().settings;
    var p = s.providers[s.provider];
    var models = (p.models || []).slice();
    keyword = (keyword || '').trim().toLowerCase();
    if (keyword) models = models.filter(function (m) { return m.name.toLowerCase().indexOf(keyword) >= 0; });

    var box = $('modelList');
    if (!models.length) {
      box.innerHTML = '<div class="model-empty">' +
        (p.models && p.models.length ? '没有匹配的模型' : '还没有模型列表') +
        '<div class="model-empty-actions">' +
        '<button class="ghost-btn small" id="popRefresh">' + ICON.refresh + ' 刷新</button>' +
        '<button class="ghost-btn small" id="popSettings">去设置</button>' +
        '</div></div>';
    } else {
      box.innerHTML = models.map(function (m) {
        var active = m.name === p.model;
        var meta = [];
        if (m.paramSize) meta.push(m.paramSize);
        if (m.size) meta.push((m.size / 1073741824).toFixed(1) + 'GB');
        if (m.caps && m.caps.indexOf('thinking') >= 0) meta.push('思考');
        if (m.caps && m.caps.indexOf('vision') >= 0) meta.push('视觉');
        var tip = m.name;
        if (m.size > 6e9) tip += '（' + (m.size / 1073741824).toFixed(1) + 'GB，加载需要较多内存）';
        return '<button class="model-item' + (active ? ' active' : '') + '" data-model="' + esc(m.name) + '" title="' + esc(tip) + '">' +
          '<span class="model-item-name">' + esc(m.name) + '</span>' +
          '<span class="model-item-meta">' + esc(meta.join(' · ')) + '</span>' +
          '<span class="model-check">✓</span>' +
          '</button>';
      }).join('');
    }
  }

  function selectModel(name) {
    var s = st().settings;
    s.providers[s.provider].model = name;
    S.save();
    renderComposer();
    renderSidebar();
    closeModelPicker();
    toast('已切换到 ' + name, 'ok');
  }

  /* ================================ 连接状态 ================================ */

  function updateConnChip() {
    var s = st().settings;
    var p = s.providers[s.provider] || {};
    var dot = $('connDot');
    var text = $('connText');
    if (!dot || !text) return;
    dot.className = 'dot';
    if (s.provider === 'ollama') {
      if (ui.conn.status === 'ok') { dot.classList.add('ok'); text.textContent = 'Ollama · ' + (p.model || '未选模型'); }
      else if (ui.conn.status === 'error') { dot.classList.add('err'); text.textContent = 'Ollama 未连接'; }
      else { text.textContent = 'Ollama 检测中…'; }
    } else if (s.provider === 'deepseek') {
      if (p.apiKey) { dot.classList.add('ok'); text.textContent = 'DeepSeek · ' + (p.model || '未选模型'); }
      else { dot.classList.add('warn'); text.textContent = 'DeepSeek 未配置 Key'; }
    } else {
      if (p.base) { dot.classList.add('ok'); text.textContent = '自定义 · ' + (p.model || '未选模型'); }
      else { dot.classList.add('warn'); text.textContent = '自定义接口未配置'; }
    }
  }

  function ollamaCandidates() {
    var list = [];
    var cur = (st().settings.providers.ollama.base || '').trim();
    var isHttpPage = location.protocol === 'http:' || location.protocol === 'https:';
    if (isHttpPage) list.push(location.origin + '/ollama');
    if (cur) list.push(cur);
    list.push('http://127.0.0.1:11434', 'http://localhost:11434');
    var out = [];
    list.forEach(function (u) { u = u.replace(/\/+$/, ''); if (u && out.indexOf(u) < 0) out.push(u); });
    return out;
  }

  async function probeOllama(opts) {
    opts = opts || {};
    var tried = [];
    var lastErr = null;
    ui.conn = { status: 'testing', error: null };
    updateConnChip();
    if (ui.settingsOpen) setOllamaStatus('正在检测…', '');

    var candidates = ollamaCandidates();
    for (var i = 0; i < candidates.length; i++) {
      var base = candidates[i];
      tried.push(base);
      try {
        var models = await P.listModels('ollama', { base: base }, { timeout: 4000 });
        var s = st().settings;
        if (opts.setProvider === false) {
          if (s.provider !== 'ollama') return false;
        } else {
          s.provider = 'ollama';
        }
        var oll = s.providers.ollama;
        oll.base = base;
        oll.models = models;
        oll.caps = {};
        models.forEach(function (m) { if (m.caps && m.caps.length) oll.caps[m.name] = m.caps; });

        if (!oll.model || !models.some(function (m) { return m.name === oll.model; })) {
          oll.model = pickDefaultModel(models);
        }
        S.save();
        ui.conn = { status: 'ok', error: null };
        renderAll();
        syncSettingsForm();
        if (!opts.silent) toast('已接入 Ollama · 共 ' + models.length + ' 个模型', 'ok');
        if (ui.settingsOpen) {
          setOllamaStatus(models.length ? '已连接 · ' + models.length + ' 个模型' : '已连接，但本地还没有模型', 'ok');
          renderSettingsModels();
        }
        return true;
      } catch (err) {
        lastErr = err;
      }
    }

    ui.conn = { status: 'error', error: lastErr };
    updateConnChip();
    renderThread();
    if (ui.settingsOpen) {
      setOllamaStatus('连接失败：' + ((lastErr && lastErr.message) || '未知原因'), 'err');
      renderOllamaHelp(tried);
    }
    if (!opts.silent) toast('没连上 Ollama，看看排查方法', 'error');
    return false;
  }

  function pickDefaultModel(models) {
    if (!models || !models.length) return '';
    // 优先选支持思考、体积较小的模型，兼顾速度与能力
    var ranked = models.slice().sort(function (a, b) {
      var ac = (a.caps || []).indexOf('thinking') >= 0 ? 0 : 1;
      var bc = (b.caps || []).indexOf('thinking') >= 0 ? 0 : 1;
      if (ac !== bc) return ac - bc;
      return (a.size || 0) - (b.size || 0);
    });
    return ranked[0].name;
  }

  function setOllamaStatus(text, kind) {
    var el = $('ollamaStatus');
    if (!el) return;
    el.textContent = text;
    el.className = 'status-line' + (kind ? ' ' + kind : '');
  }

  function renderOllamaHelp(tried) {
    var box = $('ollamaHelp');
    if (!box) return;
    box.innerHTML =
      '<div class="help-title">没连上？按顺序排查</div>' +
      '<ol class="help-list">' +
      '<li>确认 Ollama 在运行：<code>ollama --version</code> 之后执行 <code>ollama serve</code></li>' +
      '<li>确认端口：浏览器打开 <code>http://127.0.0.1:11434</code> 应返回一段 JSON</li>' +
      '<li>跨域被拦（file:// 打开时常见）：<code>$env:OLLAMA_ORIGINS="*"</code> 后重启 <code>ollama serve</code></li>' +
      '<li>最省事：用 <code>启动.bat</code> 打开本页面，自带本地转发，无需改任何配置</li>' +
      '</ol>' +
      '<div class="help-tried">已尝试：' + esc(tried.join(' , ')) + '</div>' +
      '<button class="ghost-btn small" data-copy-cmd="ollama serve">复制启动命令</button>';

    var btn = box.querySelector('[data-copy-cmd]');
    if (btn) btn.addEventListener('click', function () { copyText(btn.getAttribute('data-copy-cmd')); });
  }

  /* ================================ 设置对话框 ================================ */

  function openSettings() {
    ui.settingsOpen = true;
    ui.lastFocus = document.activeElement;
    $('overlay').hidden = false;
    document.body.classList.add('modal-open');
    syncSettingsForm();
    renderSettingsModels();
    if (st().settings.provider === 'ollama' && ui.conn.status === 'error') {
      renderOllamaHelp(ollamaCandidates());
    }
    setTimeout(function () { $('ollamaBase').focus(); }, 60);
  }

  function closeSettings() {
    ui.settingsOpen = false;
    $('overlay').hidden = true;
    document.body.classList.remove('modal-open');
    if (ui.lastFocus && ui.lastFocus.focus) ui.lastFocus.focus();
  }

  function syncSettingsForm() {
    var s = st().settings;
    var p = s.providers;

    Array.prototype.forEach.call($('providerSeg').querySelectorAll('button'), function (b) {
      b.classList.toggle('active', b.dataset.provider === s.provider);
    });
    $('providerDesc').textContent = s.provider === 'ollama'
      ? '本机运行的 Ollama，数据不出内网，可离线使用。'
      : s.provider === 'deepseek'
        ? 'DeepSeek 官方 API，需要 API Key。'
        : '任何 OpenAI 兼容接口，例如 vLLM、LM Studio、One API、各类中转站。';

    $('ollamaBase').value = p.ollama.base || '';
    $('deepseekBase').value = p.deepseek.base || '';
    $('deepseekKey').value = p.deepseek.apiKey || '';
    $('deepseekModel').value = p.deepseek.model || '';
    $('customBase').value = p.custom.base || '';
    $('customKey').value = p.custom.apiKey || '';
    $('customModel').value = p.custom.model || '';

    $('systemPrompt').value = s.systemPrompt || '';
    $('temperature').value = s.temperature == null ? 0.7 : s.temperature;
    $('tempValue').textContent = Number($('temperature').value).toFixed(1);
    $('contextMessages').value = s.contextMessages == null ? 12 : s.contextMessages;
    $('streamToggle').checked = s.stream !== false;

    Array.prototype.forEach.call(document.querySelectorAll('.theme-seg button'), function (b) {
      b.classList.toggle('active', b.dataset.theme === s.theme);
    });

    toggleProviderPanels();
  }

  function toggleProviderPanels() {
    var cur = st().settings.provider;
    Array.prototype.forEach.call(document.querySelectorAll('.provider-panel'), function (sec) {
      sec.hidden = sec.dataset.panel !== cur;
    });
  }

  function renderSettingsModels() {
    var s = st().settings;
    ['ollama', 'deepseek', 'custom'].forEach(function (id) {
      var box = $(id + 'Models');
      if (!box) return;
      var cfg = s.providers[id];
      var models = cfg.models || [];
      if (!models.length) {
        box.innerHTML = '<div class="chips-empty">暂无模型，点上面的按钮拉取</div>';
        return;
      }
      box.innerHTML = models.map(function (m) {
        var active = m.name === cfg.model;
        var meta = [];
        if (m.paramSize) meta.push(m.paramSize);
        if (m.size) meta.push((m.size / 1073741824).toFixed(1) + 'GB');
        return '<button class="chip-model' + (active ? ' active' : '') + '" data-pick="' + esc(m.name) + '" data-provider="' + id + '"' +
          (m.size > 6e9 ? ' title="体积 ' + (m.size / 1073741824).toFixed(1) + 'GB，加载需要较多内存"' : '') + '>' +
          '<span>' + esc(m.name) + '</span>' + (meta.length ? '<em>' + esc(meta.join(' · ')) + '</em>' : '') + '</button>';
      }).join('');
    });
  }

  async function refreshProviderModels(provider, opts) {
    opts = opts || {};
    var cfg = st().settings.providers[provider];
    var statusEl = $(provider + 'Status');
    if (statusEl) { statusEl.textContent = '正在拉取…'; statusEl.className = 'status-line'; }
    try {
      var models = await P.listModels(provider, cfg, { timeout: 12000 });
      cfg.models = models;
      if (provider === 'ollama') {
        cfg.caps = cfg.caps || {};
        models.forEach(function (m) { if (m.caps && m.caps.length) cfg.caps[m.name] = m.caps; });
        ui.conn = { status: 'ok', error: null };
      }
      if (!cfg.model || !models.some(function (m) { return m.name === cfg.model; })) {
        cfg.model = pickDefaultModel(models) || models[0] && models[0].name || cfg.model;
      }
      S.save();
      renderComposer();
      renderSettingsModels();
      updateConnChip();
      renderThread();
      if (statusEl) {
        statusEl.textContent = models.length ? '已连接 · ' + models.length + ' 个模型' : '已连接，但还没有模型';
        statusEl.className = 'status-line ok';
      }
      if (!opts.silent) toast('模型列表已更新', 'ok');
      return true;
    } catch (err) {
      var info = P.describeError(err);
      if (statusEl) { statusEl.textContent = info.title + '：' + (info.body || ''); statusEl.className = 'status-line err'; }
      if (provider === 'ollama') {
        ui.conn = { status: 'error', error: err };
        renderOllamaHelp(ollamaCandidates());
      }
      updateConnChip();
      if (!opts.silent) toast(info.title, 'error');
      return false;
    }
  }

  /* ================================ 导出 ================================ */

  function conversationMarkdown(conv) {
    var lines = ['# ' + conv.title, '', '> 导出时间：' + new Date().toLocaleString('zh-CN'), ''];
    conv.messages.forEach(function (m) {
      if (m.role === 'user') {
        lines.push('## 我', '', m.content, '');
      } else {
        lines.push('## ' + (m.model || 'AI'), '');
        if (m.thinking) lines.push('> **思考过程**', '', m.thinking.split('\n').map(function (l) { return '> ' + l; }).join('\n'), '');
        lines.push(m.content || '', '');
      }
    });
    return lines.join('\n');
  }

  function exportCurrent() {
    var conv = S.current();
    if (!conv || !conv.messages.length) { toast('当前没有对话内容', 'warn'); return; }
    var name = (conv.title || '对话').replace(/[\\/:*?"<>|\s]+/g, '-').slice(0, 40) || '对话';
    var blob = new Blob([conversationMarkdown(conv)], { type: 'text/markdown;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name + '.md';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    toast('已导出 Markdown', 'ok');
  }

  /* ================================ 轻提示 ================================ */

  var toastTimer = null;
  function toast(msg, kind) {
    var host = $('toastHost');
    host.innerHTML = '';
    var d = document.createElement('div');
    d.className = 'toast' + (kind ? ' ' + kind : '');
    d.textContent = msg;
    host.appendChild(d);
    requestAnimationFrame(function () { d.classList.add('show'); });
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      d.classList.remove('show');
      setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 220);
    }, kind === 'error' ? 4200 : 2000);
  }

  /* ================================ 事件绑定 ================================ */

  function bindEvents() {
    /* ---- 输入框 ---- */
    var ta = $('input');
    ta.addEventListener('input', autoGrow);
    ta.addEventListener('keydown', function (e) {
      if (e.isComposing || e.keyCode === 229) return;
      if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        if (ui.generating) return;
        sendFromInput();
      }
    });

    $('sendBtn').addEventListener('click', function () {
      if (ui.generating) stopGeneration();
      else sendFromInput();
    });

    /* ---- 深度思考 / 模型 ---- */
    $('thinkToggle').addEventListener('click', function () {
      var s = st().settings;
      s.deepThink = !s.deepThink;
      S.save();
      renderComposer();
      toast(s.deepThink ? '深度思考已开启' : '深度思考已关闭', 'ok');
    });
    $('modelBtn').addEventListener('click', function (e) { e.stopPropagation(); openModelPicker(); });
    $('topbarModel').addEventListener('click', function (e) { e.stopPropagation(); openModelPicker(); });

    $('modelSearch').addEventListener('input', function () { renderModelList(this.value); });
    $('modelSearch').addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.stopPropagation(); closeModelPicker(); }
      if (e.key === 'Enter') {
        var first = $('modelList').querySelector('.model-item');
        if (first) selectModel(first.dataset.model);
      }
    });
    $('modelRefresh').addEventListener('click', function () {
      refreshProviderModels(st().settings.provider, { silent: false });
    });
    $('modelPopover').addEventListener('click', function (e) {
      var item = e.target.closest && e.target.closest('.model-item');
      if (item) { selectModel(item.dataset.model); return; }
      if (e.target.closest && e.target.closest('#popRefresh')) { refreshProviderModels(st().settings.provider); return; }
      if (e.target.closest && e.target.closest('#popSettings')) { closeModelPicker(); openSettings(); return; }
    });
    $('openSettingsFromPopover').addEventListener('click', function () { closeModelPicker(); openSettings(); });

    document.addEventListener('click', function (e) {
      if (!ui.popoverOpen) return;
      if (e.target.closest && (e.target.closest('#modelPopover') || e.target.closest('#modelBtn') || e.target.closest('#topbarModel'))) return;
      closeModelPicker();
    });

    /* ---- 新对话 / 侧栏 ---- */
    $('newChatBtn').addEventListener('click', newConversation);
    $('collapseBtn').addEventListener('click', function () {
      ui.collapsed = !ui.collapsed;
      S.state.uiCollapsed = ui.collapsed;
      S.save();
      $('app').classList.toggle('sidebar-collapsed', ui.collapsed);
    });
    $('menuBtn').addEventListener('click', function () {
      $('app').classList.toggle('sidebar-open');
      document.body.classList.toggle('sidebar-backdrop');
    });
    $('convList').addEventListener('click', function (e) {
      var del = e.target.closest && e.target.closest('[data-del]');
      if (del) {
        e.stopPropagation();
        var id = del.dataset.del;
        var conv = S.state.conversations.filter(function (c) { return c.id === id; })[0];
        if (conv && confirm('删除对话「' + conv.title + '」？')) {
          flushTypewriters();
          S.deleteConversation(id);
          renderAll();
        }
        return;
      }
      var item = e.target.closest && e.target.closest('[data-conv]');
      if (item) {
        flushTypewriters();
        S.selectConversation(item.dataset.conv);
        renderAll();
        jumpToBottom();
        if (window.innerWidth <= 820) { $('app').classList.remove('sidebar-open'); document.body.classList.remove('sidebar-backdrop'); }
      }
    });

    /* ---- 滚动 ---- */
    $('scroll').addEventListener('scroll', function () {
      ui.stick = nearBottom();
      $('scrollBottom').hidden = ui.stick;
    });
    $('scrollBottom').addEventListener('click', jumpToBottom);

    /* ---- 主题 / 设置 / 导出 ---- */
    $('themeBtn').addEventListener('click', cycleTheme);
    $('settingsBtn').addEventListener('click', openSettings);
    $('connChip').addEventListener('click', openSettings);
    $('exportBtn').addEventListener('click', exportCurrent);

    /* ---- 消息区域事件委托 ---- */
    $('thread').addEventListener('click', function (e) {
      var actBtn = e.target.closest && e.target.closest('[data-act]');
      var copyBtn = e.target.closest && e.target.closest('.code-copy');
      var thinkHead = e.target.closest && e.target.closest('.think-head');

      if (copyBtn) {
        var pre = copyBtn.closest('.code-block').querySelector('pre');
        copyText(pre.textContent);
        copyBtn.textContent = '已复制';
        setTimeout(function () { copyBtn.textContent = '复制'; }, 1200);
        return;
      }
      if (thinkHead) {
        var block = thinkHead.closest('.think');
        block.classList.toggle('open');
        return;
      }
      if (actBtn) {
        var msgEl = actBtn.closest('.msg');
        var msg = findMessage(msgEl.dataset.id);
        if (!msg) return;
        var act = actBtn.dataset.act;
        if (act === 'copy') copyText(msg.content + (msg.thinking ? '\n\n[思考]\n' + msg.thinking : ''));
        else if (act === 'del') removeMessage(S.current(), msg.id);
        else if (act === 'regen') regenerate(msg.id);
        else if (act === 'edit') beginEdit(msg.id);
      }
    });

    $('thread').addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-edit]');
      if (!b) return;
      var msgEl = b.closest('.msg');
      if (b.dataset.edit === 'cancel') { renderThread({ stick: false }); return; }
      var ta = msgEl.querySelector('.edit-area');
      commitEdit(msgEl.dataset.id, ta.value);
    });

    /* ---- 欢迎页 ---- */
    $('welcome').addEventListener('click', function (e) {
      var s = e.target.closest && e.target.closest('[data-suggest]');
      if (s) {
        var text = SUGGESTS[Number(s.dataset.suggest)].p;
        $('input').value = text;
        autoGrow();
        $('input').focus();
        return;
      }
      if (e.target.closest && e.target.closest('#welcomeConnect')) { probeOllama({ silent: false }); return; }
      if (e.target.closest && e.target.closest('#welcomeHelp')) { openSettings(); return; }
    });

    /* ---- 设置：服务商切换 ---- */
    $('providerSeg').addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-provider]');
      if (!b) return;
      var s = st().settings;
      s.provider = b.dataset.provider;
      S.save();
      syncSettingsForm();
      renderSettingsModels();
      renderComposer();
      renderThread();
      updateConnChip();
    });

    /* ---- 设置：Ollama ---- */
    $('ollamaBase').addEventListener('change', function () {
      st().settings.providers.ollama.base = this.value.trim().replace(/\/+$/, '');
      S.save();
      probeOllama({ silent: false });
    });
    $('ollamaConnectBtn').addEventListener('click', function () { probeOllama({ silent: false }); });
    $('ollamaRefreshBtn').addEventListener('click', function () { probeOllama({ silent: false }); });

    /* ---- 设置：DeepSeek ---- */
    $('deepseekKey').addEventListener('input', function () {
      st().settings.providers.deepseek.apiKey = this.value.trim();
      S.save();
      updateConnChip();
    });
    $('deepseekBase').addEventListener('change', function () {
      st().settings.providers.deepseek.base = this.value.trim();
      S.save();
    });
    $('deepseekModel').addEventListener('change', function () {
      st().settings.providers.deepseek.model = this.value.trim();
      S.save();
      renderComposer();
    });
    $('deepseekTestBtn').addEventListener('click', function () { refreshProviderModels('deepseek'); });

    /* ---- 设置：自定义 ---- */
    $('customBase').addEventListener('change', function () {
      st().settings.providers.custom.base = this.value.trim();
      S.save();
    });
    $('customKey').addEventListener('input', function () {
      st().settings.providers.custom.apiKey = this.value.trim();
      S.save();
    });
    $('customModel').addEventListener('change', function () {
      st().settings.providers.custom.model = this.value.trim();
      S.save();
      renderComposer();
    });
    $('customTestBtn').addEventListener('click', function () { refreshProviderModels('custom'); });

    /* ---- 设置：模型 chips ---- */
    $('overlay').addEventListener('click', function (e) {
      var chip = e.target.closest && e.target.closest('.chip-model');
      if (chip) {
        var s = st().settings;
        var provider = chip.dataset.provider;
        s.providers[provider].model = chip.dataset.pick;
        s.provider = provider;
        S.save();
        renderSettingsModels();
        renderComposer();
        updateConnChip();
        renderThread();
        toast('已选择 ' + chip.dataset.pick, 'ok');
        return;
      }
      if (e.target === $('overlay')) closeSettings();
    });
    $('closeSettings').addEventListener('click', closeSettings);
    $('doneSettings').addEventListener('click', closeSettings);

    /* ---- 设置：通用 ---- */
    $('systemPrompt').addEventListener('input', function () {
      st().settings.systemPrompt = this.value;
      S.save();
    });
    $('temperature').addEventListener('input', function () {
      st().settings.temperature = Number(this.value);
      $('tempValue').textContent = Number(this.value).toFixed(1);
      S.save();
    });
    $('contextMessages').addEventListener('change', function () {
      var v = Math.max(0, Math.min(100, parseInt(this.value, 10) || 0));
      this.value = v;
      st().settings.contextMessages = v;
      S.save();
    });
    $('streamToggle').addEventListener('change', function () {
      st().settings.stream = this.checked;
      S.save();
    });
    Array.prototype.forEach.call(document.querySelectorAll('.theme-seg button'), function (b) {
      b.addEventListener('click', function () {
        st().settings.theme = b.dataset.theme;
        S.save();
        applyTheme();
        syncSettingsForm();
      });
    });

    /* ---- 版本与更新（模板） ---- */
    $('versionBtn').addEventListener('click', function () { openSettings(); });
    $('checkUpdateBtn').addEventListener('click', doCheckUpdate);
    $('applyUpdateBtn').addEventListener('click', function () { openUpdateDialog(); });
    $('updLater').addEventListener('click', closeUpdateDialog);
    $('closeUpdate').addEventListener('click', closeUpdateDialog);
    $('updApply').addEventListener('click', applyUpdate);
    $('updateOverlay').addEventListener('click', function (e) {
      if (e.target === $('updateOverlay')) closeUpdateDialog();
    });

    /* ---- 全局快捷键 ---- */
    document.addEventListener('keydown', function (e) {
      var mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'n') { e.preventDefault(); newConversation(); return; }
      if (mod && e.key.toLowerCase() === 'k') { e.preventDefault(); $('input').focus(); return; }
      if (mod && e.shiftKey && e.key.toLowerCase() === 'd') { e.preventDefault(); $('thinkToggle').click(); return; }
      if (mod && e.key.toLowerCase() === 'b') { e.preventDefault(); $('collapseBtn').click(); return; }
      if (e.key === 'Escape') {
        if (ui.updateOpen) { closeUpdateDialog(); return; }
        if (ui.settingsOpen) { closeSettings(); return; }
        if (ui.popoverOpen) { closeModelPicker(); return; }
        if (ui.generating) { stopGeneration(); return; }
      }
    });

    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () {
      if (st().settings.theme === 'system') applyTheme();
    });
  }

  /* =============================== 版本与更新 =============================== */

  function syncVersion() {
    var V = window.CHAT_VERSION || {};
    var chip = $('versionBtn');
    if (chip && V.version) chip.textContent = 'v' + V.version;
    if (V.version) document.title = '本地大模型聊天 · v' + V.version;
  }

  function setupUpdate() {
    var V = window.CHAT_VERSION || { version: '0.0.0', build: '', channel: 'stable' };
    var U = window.ChatUpdater;
    var on = !!(U && U.enabled());

    if ($('updateChannel')) $('updateChannel').textContent = V.channel || 'stable';
    if ($('verCurrent')) $('verCurrent').textContent = 'v' + (V.version || '0.0.0');
    if ($('verBuild')) $('verBuild').textContent = 'build ' + (V.build || '');
    if ($('verState')) $('verState').textContent = on ? '可检查更新' : '本地版本';

    $('updateMask').hidden = on;
    $('checkUpdateBtn').disabled = !on;
    $('applyUpdateBtn').hidden = true;

    setUpdateStatus(on ? '点击「检查更新」，向自建更新服务器查询' : '更新服务未接入（模板）', on ? '' : 'warn');
  }

  function setUpdateStatus(text, kind) {
    var el = $('updateStatus');
    if (!el) return;
    el.textContent = text || '';
    el.className = 'status-line' + (kind ? ' ' + kind : '');
  }

  async function doCheckUpdate() {
    var U = window.ChatUpdater;
    if (!U || !U.enabled()) { toast('更新服务未接入', 'warn'); return; }
    setUpdateStatus('正在检查…', '');
    $('checkUpdateBtn').disabled = true;
    try {
      var r = await U.check();
      if (!r.ok) {
        $('applyUpdateBtn').hidden = true;
        setUpdateStatus('检查失败：' + (r.error || '未知原因'), 'err');
        return;
      }
      if (r.hasUpdate) {
        $('applyUpdateBtn').hidden = false;
        setUpdateStatus('发现新版本 v' + r.manifest.version, 'ok');
        openUpdateDialog();
      } else {
        $('applyUpdateBtn').hidden = true;
        setUpdateStatus('已是最新版本 · v' + ((window.CHAT_VERSION || {}).version || ''), 'ok');
      }
    } finally {
      $('checkUpdateBtn').disabled = !U.enabled();
    }
  }

  function openUpdateDialog() {
    var U = window.ChatUpdater;
    if (!U || !U.manifest) return;
    var V = window.CHAT_VERSION || {};
    var m = U.manifest;

    $('updFrom').textContent = 'v' + (V.version || '');
    $('updTo').textContent = 'v' + m.version;
    $('updDate').textContent = m.publishedAt ? String(m.publishedAt).slice(0, 10) : '';

    var notes = m.notes == null ? [] : (Array.isArray(m.notes) ? m.notes : String(m.notes).split('\n'));
    var items = notes.map(function (n) { return String(n).replace(/^[-*·]\s*/, '').trim(); }).filter(Boolean);
    $('updNotes').innerHTML = (items.length ? items : ['细节优化与稳定性提升']).map(function (n) {
      return '<li>' + esc(n) + '</li>';
    }).join('');

    $('updProgress').hidden = true;
    $('updBar').style.width = '0%';
    $('updStatus').textContent = '';
    $('updStatus').className = 'status-line';
    $('updApply').disabled = false;
    $('updateOverlay').hidden = false;
    ui.updateOpen = true;
  }

  function closeUpdateDialog() {
    $('updateOverlay').hidden = true;
    ui.updateOpen = false;
  }

  async function applyUpdate() {
    var U = window.ChatUpdater;
    if (!U) return;
    var btn = $('updApply');
    btn.disabled = true;
    $('updProgress').hidden = false;

    function onProgress(p) {
      if (!p) return;
      if (typeof p.percent === 'number') {
        $('updBar').style.width = Math.max(3, Math.min(100, p.percent)) + '%';
      }
      if (p.message) { $('updStatus').textContent = p.message; $('updStatus').className = 'status-line'; }
    }

    try {
      var r = await U.apply(onProgress);
      if (r.mode === 'download') {
        $('updStatus').textContent = '已开始下载，解压覆盖后刷新页面即可';
        $('updStatus').className = 'status-line ok';
      } else {
        $('updStatus').textContent = (r.data && r.data.message) || '更新完成，刷新页面后生效';
        $('updStatus').className = 'status-line ok';
      }
    } catch (err) {
      $('updStatus').textContent = '更新失败：' + ((err && err.message) || err);
      $('updStatus').className = 'status-line err';
    } finally {
      btn.disabled = false;
    }
  }

  function cycleTheme() {
    var order = ['light', 'dark', 'system'];
    var cur = st().settings.theme;
    var next = order[(order.indexOf(cur) + 1) % order.length];
    st().settings.theme = next;
    S.save();
    applyTheme();
    syncSettingsForm();
    toast(next === 'light' ? '浅色主题' : next === 'dark' ? '深色主题' : '跟随系统', 'ok');
  }

  function newConversation() {
    if (ui.generating) stopGeneration();
    flushTypewriters();
    var cur = S.current();
    if (cur && !cur.messages.length) {
      $('input').focus();
      return;
    }
    S.createConversation();
    renderAll();
    $('input').value = '';
    autoGrow();
    $('input').focus();
    jumpToBottom();
  }

  /* ================================ 启动 ================================ */

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
