# Chat v0.3 — 更顺手的本地大模型对话前端

> 基于 `chat-demo-v0.1.3` 重写。原包只有编译后的压缩产物（`main.*.js` 477KB / `index.html`），没有源码，无法在其上继续加功能，所以按原版风格重做成可维护的源码工程，并补上「一键接入 Ollama、深度思考开关、模型切换」。
>
> v0.3 在 v0.2 上继续打磨：回复**打字机效果**、界面细节优化、可发布版本号，以及一套**自更新模板**（更新服务器由你自己接，默认带遮罩不可点）。

![浅色](docs/preview-light.png)

![深色](docs/preview-dark.png)

## 三步用起来

1. 双击 **`启动.bat`**（macOS 用 `启动.command`）。
2. 浏览器自动打开 `http://127.0.0.1:8787`。
3. 首次进入自动探测 Ollama，直接选好本地模型就能聊。

启动脚本会做四件事：

- 起一个本地静态服务 + 转发服务（`server.js`，无 Node 时回退 `server.py`）
- 检测 Ollama；**没在运行就自动 `ollama serve`**
- 用 `/ollama/*` 把请求转发到 `127.0.0.1:11434`，**彻底绕开浏览器跨域 / 私有网络限制**
- 自动打开浏览器

> 直接双击 `index.html` 也能打开，但浏览器会对 `file://` → `localhost` 的请求做跨域拦截，此时页面会提示你改用启动脚本。

## v0.3 新增什么

| 能力 | 说明 |
| --- | --- |
| **打字机效果** | 回复按字符逐步显现（约 26ms 一帧，按积压长度自适应步长），带闪烁光标；流结束后自动加速追平，追平才去掉光标并整块重排 Markdown。系统开启「减少动态效果」时自动关闭，直接整段显示。正文始终保存完整文本，打字只是显示层，复制/导出/刷新都不受影响 |
| **界面优化** | 会话列表按「今天 / 昨天 / 更早」分组，当前会话左侧加色条；生成中实时显示耗时、结束后显示 `用时 x.xs · tok/s`；版本号可点开设置；代码块、标题、列表排版收紧，圆角/描边/过渡统一 |
| **可发布版本** | 版本号集中在 `assets/version.js`（页面、设置面板、启动器 `/api/health` 三处一致），补了 favicon 与 `description`，方便挂到自己的站点或打包分发 |
| **自更新模板** | 前端、启动器接口、协议文档全部写好，默认 `enabled: false`：设置里「版本与更新」盖一层遮罩，按钮禁用，不会产生半成品行为 |
| 一键接入 Ollama | 自动按 `页面代理 → 已存地址 → 127.0.0.1:11434 → localhost:11434` 依次探测，成功后载入全部本地模型并选好默认模型 |
| 深度思考一键开关 | 输入框左侧常驻开关，`Ctrl/Cmd+Shift+D` 也能切；思考过程以可折叠块实时流式展示，结束自动收起 |
| 模型随时切换 | 模型胶囊 → 浮层支持搜索、刷新、能力标签（思考 / 视觉 / 参数量 / 体积），点一下立即生效 |
| 三种服务商 | Ollama 本地、DeepSeek 官方、任意 OpenAI 兼容接口（vLLM / LM Studio / One API / 中转站） |
| Markdown 渲染 | 标题、表格、列表、引用、链接、代码高亮（js/ts/py/json/bash/sql/html/css）+ 一键复制代码 |
| 会话管理 | 侧边栏历史、自动标题、预览、删除、导出 Markdown |
| 消息操作 | 复制、重新生成、编辑用户消息并重发、删除 |
| 流式体验 | 停止生成（保留已生成内容）、自动贴底、手动上滑后不打断阅读、回到底部按钮 |

### 快捷键

| 快捷键 | 作用 |
| --- | --- |
| `Enter` / `Shift+Enter` | 发送 / 换行 |
| `Ctrl/Cmd+N` | 新建对话 |
| `Ctrl/Cmd+K` | 聚焦输入框 |
| `Ctrl/Cmd+Shift+D` | 开关深度思考 |
| `Ctrl/Cmd+B` | 收起 / 展开侧边栏 |
| `Esc` | 关闭更新弹窗 / 设置 / 浮层，或停止生成 |

## 自更新（模板，默认关闭）

```
浏览器 ──GET /api/update/manifest.json?channel=stable──▶ 本地启动器 ──▶ 你的更新服务器
```

- 版本号：`assets/version.js` → `CHAT_VERSION = { version: '0.3.0', build: '2026-11-21', channel: 'stable' }`
- 开关：`assets/update-config.js` → `CHAT_UPDATE.enabled`（现在是 `false`）
- 逻辑：`assets/updater.js` → `ChatUpdater`（版本比较、拉清单、应用、文案）
- 接口契约：**[`docs/update-protocol.md`](docs/update-protocol.md)**（清单字段、`apply` 请求体、启动器要做哪几步、怎么打开开关）

现在的状态：

- 设置面板「版本与更新」能看到当前版本 / build / 通道；
- 上面盖着一层半透明 + 模糊的遮罩，写着「模板 · 更新服务待接入 · 暂不可点击」；
- 「检查更新」按钮同时 `disabled`，点不动；
- 更新弹窗（版本对比、更新内容、进度条）已写好，服务器接好后直接复用。

启动器已预留两个接口，未配置时都会返回 `501` 且不改动任何文件：

```bash
node server.js --update-server https://你的服务器
python server.py --update-server https://你的服务器
# 或环境变量 UPDATE_SERVER
```

配置后把 `enabled` 改成 `true`，遮罩自动消失、按钮可用；发现新版本弹窗会自己出来。

![更新面板（模板遮罩）](docs/preview-update.png)

> 设计取舍：浏览器没有权限替换程序文件，所以下载 / `sha256` 校验 / 备份 / 替换都交给本地启动器；启动器没实现 apply 时，前端会退化为浏览器直接下载 zip，手动解压覆盖即可。

## 深度思考在各服务商上的行为

- **Ollama**：直接下发 `think: true/false`，思考内容从 `message.thinking` 流式返回。
- **Ollama 模型不支持思考**：服务端返回 400 时自动去掉 `think` 重试一次，不会卡住对话；模型胶囊上会标注是否声明了 `thinking` 能力。
- **DeepSeek**：`deepseek-reasoner` 天然输出 `reasoning_content`；用 `deepseek-chat` 时按开关尝试 `thinking: {type: enabled}`。
- **其他 OpenAI 兼容接口**：开启时带 `reasoning_effort: high`，被拒绝（400）会自动降级重试。
- 思考内容只用于展示，不进入后续上下文。

## 模型默认选择策略

自动选模型时按「**优先支持思考 + 体积最小**」排序。大模型首次加载会吃掉大量内存/显存：

- `qwen3_0.6b:latest`（0.55GB）→ 默认首选
- `dsqwen3.5-9b:latest`（7.6GB）、`qwen3.6:latest`（14.5GB）→ 需要足够内存才能跑，列表里标了体积，按需手动切换

## 文件结构

```
chat-demo-v0.2.0/
├─ index.html            页面骨架
├─ assets/
│  ├─ app.css            全部样式（浅色 / 深色 / 移动端）
│  ├─ app.js             界面与交互（发送、流式、打字机、浮层、设置、快捷键）
│  ├─ providers.js       服务适配层（Ollama / OpenAI 兼容 + 降级重试）
│  ├─ md.js              零依赖 Markdown 渲染 + 代码高亮
│  ├─ store.js           状态与 localStorage 持久化
│  ├─ version.js         版本号（发布时改这里）
│  ├─ update-config.js   自更新开关与接口地址
│  └─ updater.js         自更新逻辑（ChatUpdater）
├─ server.js             启动器：静态服务 + /ollama 转发 + /proxy + /api/update
├─ server.py             同上，Python 标准库版（无 Node 时使用）
├─ 启动.bat / 启动.command
├─ docs/update-protocol.md   自更新契约
├─ tests/                冒烟 / 代理 / 界面链路测试
└─ README.md
```

## 设置面板

- **服务商**：Ollama / DeepSeek / OpenAI 兼容，配置各自独立保存。
- **Ollama**：地址可改（默认 `http://127.0.0.1:11434`），「一键连接」重新探测，模型 chips 点一下即切换。
- **对话设置**：系统提示词、温度（0–1.5）、上下文条数（0 = 全部）、流式开关、主题。
- **版本与更新**：当前版本、build、通道；更新入口（默认遮罩）。

配置和对话都存在浏览器 `localStorage`（键名 `chat-demo.v0.2`），不上传任何服务器。

## 常见问题

| 现象 | 处理 |
| --- | --- |
| 提示「连不上模型服务」 | 先确认 `ollama --version` 可用，再执行 `ollama serve`；或直接用 `启动.bat` 打开 |
| 提示跨域 / `Failed to fetch` | 你可能是双击 `index.html` 打开的，改用启动脚本；或设置 `$env:OLLAMA_ORIGINS="*"` 后重启 `ollama serve` |
| 连上但模型列表为空 | 终端执行 `ollama list`，没有模型就先 `ollama pull qwen3:0.6b` |
| DeepSeek 返回 401 | API Key 无效，设置里重新填 |
| 端口被占用 | 启动器会自动顺延端口（8787 → 8788 …）；也可 `node server.js --port 8899` |
| 点「检查更新」没反应 | 正常：模板默认关闭，按钮被遮罩挡住；接好服务器再改 `update-config.js` 的 `enabled` |
| 27B 模型很慢 / 内存报警 | 换成小模型，模型列表里标着体积 |

## 自测

```bash
# 适配层 + Markdown + 存储（模拟服务，约 1 秒）
node tests/smoke.js

# 再加一轮真实 Ollama 推理（用最小的模型，别用大家伙）
node tests/smoke.js --real

# 启动器：静态服务 / Ollama 转发 / 流式不被缓冲 / 通用转发 / 更新接口 501
node server.js --no-open --port 8788 &
node tests/proxy.js 8788

# 界面链路：jsdom 驱动真实点击 + 真实推理 + 更新遮罩断言
npm i jsdom --prefix %TEMP%\jsdomtest
set NODE_PATH=%TEMP%\jsdomtest\node_modules
node tests/ui.js http://127.0.0.1:8788/ qwen3_0.6b:latest
```

已验证：Markdown 渲染与注入拦截、NDJSON/SSE 流式、不支持思考时降级、中止生成、模型列表、深度思考开关、模型切换、重新生成、localStorage 持久化、启动器流式转发（首段 92–203ms）、更新接口在未配置时返回 501、遮罩下按钮确实不可点。

## 说明

- `server.js` / `server.py` 只监听 `127.0.0.1`，转发服务仅本机可用。
- `/proxy?url=` 只转发 `http(s)` 地址，是为浏览器跨域兜底用的，不需要可以不管。
- API Key 存在浏览器本地，公共电脑上请用完清理。
- 自更新默认关闭：不配置更新服务器时，页面不会发起任何更新请求。
- 本项目为独立重写实现，遵循 MIT 许可。
